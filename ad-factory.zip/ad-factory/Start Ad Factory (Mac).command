#!/bin/bash
# Double-click to start Ad Factory. First run installs everything it needs (5-10 min).
cd "$(dirname "$0")" || exit 1
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v uv >/dev/null 2>&1; then
  echo "Installing uv (Python manager)..."
  curl -LsSf https://astral.sh/uv/install.sh | sh || { echo "Install failed. Check your internet connection."; read -r; exit 1; }
  export PATH="$HOME/.local/bin:$PATH"
fi
echo "Starting Ad Factory (first launch downloads ~400 MB of components)..."
uv run --python 3.12 python -m adfactory
echo
echo "Ad Factory stopped. Press Enter to close this window."
read -r
