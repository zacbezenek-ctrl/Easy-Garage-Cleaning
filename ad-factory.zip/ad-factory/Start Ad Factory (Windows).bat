@echo off
REM Double-click to start Ad Factory. First run installs everything it needs (5-10 min).
cd /d "%~dp0"
set "PATH=%USERPROFILE%\.local\bin;%PATH%"
where uv >nul 2>nul
if errorlevel 1 (
  echo Installing uv ^(Python manager^)...
  powershell -NoProfile -ExecutionPolicy ByPass -Command "irm https://astral.sh/uv/install.ps1 | iex"
  set "PATH=%USERPROFILE%\.local\bin;%PATH%"
)
echo Starting Ad Factory (first launch downloads ~400 MB of components)...
uv run --python 3.12 python -m adfactory
echo.
echo Ad Factory stopped.
pause
