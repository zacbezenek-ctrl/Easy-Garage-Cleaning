# Ad Factory

Turns a set of **hooks** and **bodies** into every ad combination, captioned and on-brand, in one batch.
Every hook is joined to every body (18 hooks × 2 bodies = 36 ads), in every format you pick.

**No sign-up, no account.** Everything runs on your own computer, and your videos never leave it.

### ⬇ [Download Ad Factory (zip)](https://github.com/zacbezenek-ctrl/Easy-Garage-Cleaning/raw/ad-factory-download/ad-factory.zip)

Unzip it somewhere permanent (e.g. Documents), then follow **Start it** below.

---

## Start it

**Mac:** double-click `Start Ad Factory (Mac).command`.
If macOS blocks it the first time ("can't be opened" / "Apple could not verify…"):
- **macOS 15 Sequoia or newer:** click *Done*, open **System Settings → Privacy & Security**, scroll down and click **Open Anyway** next to the Ad Factory message, then double-click the file again.
- **Older macOS:** right-click the file → **Open** → **Open**.

You only need to do this once. Another way that always works: open **Terminal**, type `bash ` (with a space), drag the file into the window and press Enter.

**Windows:** double-click `Start Ad Factory (Windows).bat`.
If SmartScreen appears, click **More info → Run anyway**.

The first launch installs what it needs (about 5-10 minutes, one time only). After that it starts in seconds.
The editor opens in your browser at `http://127.0.0.1:8765`. Chrome is recommended.
**Keep the small terminal window open while you work.** Closing it stops the app.

While it's open for the first time, Ad Factory also downloads the speech model used for captions (about 500 MB).
A chip in the top bar shows the progress, and you can keep working meanwhile.

## First run

You'll see a welcome screen, name your first project, and a short tour points at each part of the screen.
It continues automatically once your first clip is ready.
Replay it anytime from **?** in the top bar, which also has the full feature guide and keyboard shortcuts.

---

## Making a batch, step by step

1. **Create a project** for the product or campaign. Its name starts every file name.
   Later projects can copy the last one's captions, logo, end card, music and export settings.
2. **Drop hooks into "Hooks" and bodies into "Bodies"**, or click **+ Add**.
   They're numbered H01, H02… and B01, B02… in file-name order, so name files `hook01`, `hook02`, …
3. **Check the captions.** Click a clip; in the **Clip** tab, fix any yellow-underlined words in the transcript.
4. **Style it.** Pick a caption style in **Captions**. Add a logo, end card or music in **Brand**.
5. **Choose formats** in **Export**, and which combos in **Matrix** (all of them by default).
6. Click **Exact preview** to check one finished ad, then **Render**. When it's done, use **Open folder** or **Download .zip**.

Projects and exports are saved in the `AdFactory` folder in your home folder.

---

## What every feature does

### Getting clips in
| Feature | What it does |
|---|---|
| Hooks & bodies | Drop videos into each list. MP4, MOV and iPhone HDR footage all work; HDR colours are converted automatically. |
| Automatic prep | Each clip gets a fast preview copy, word-by-word captions, dead air cut from the start and end, and its loudness measured. |
| Projects | One project per batch. Switch projects from the menu at the top left; everything saves automatically. |

### Preview & timeline
| Feature | What it does |
|---|---|
| Live preview | Plays the selected hook → body → end card exactly as it will export, with captions, logo, text and progress bar. The preview and the exported file were compared pixel-for-pixel in testing. |
| Formats | 9:16 (Reels, TikTok, Stories), 4:5 (Feed), 1:1 and 16:9. Caption position is saved separately for each. |
| Safe zones | Shades the parts of the screen covered by Reels, TikTok or Stories buttons. |
| Timeline | Waveform of the whole ad. Click or drag to scrub. Ticks mark words and lines mark jump cuts. |
| Exact preview | Renders the ad on screen in a few seconds, so you can check the real file before rendering the whole batch. |

### Clip tab (the selected hook or body)
| Feature | What it does |
|---|---|
| Trim | Drag the purple handles on the waveform, type exact times, or press **I** / **O** at the playhead. *Auto-tighten* cuts dead air; *Reset* restores the full clip. |
| Cut pauses | Turns pauses longer than the slider value (0.4 s by default) into quick jump cuts. Captions follow the cuts. *Apply to all clips* does every clip at once. |
| Framing | Zoom and pan so faces stay in frame when a clip is cropped to a different shape. |
| Volume trim | Make one clip a bit louder or quieter, on top of the automatic levelling. |
| Text overlay | On-screen text such as "POV: you finally fixed your ads" for any time range. *Use spoken first line* fills it from the transcript. |
| Transcript | Click a word to jump to it and fix it. ★ colours a key word, *Hide* drops a word from the captions (it's still heard). *Edit as text* lets you rewrite freely; the timing re-aligns. Yellow-underlined words are the ones the speech model was unsure about. *Redo* re-transcribes. |

### Captions tab
| Feature | What it does |
|---|---|
| Styles | Bold Pop, Word Box, Karaoke, One Word, Clean Box, Minimal, Comic. Pick one, then adjust anything. |
| Look | 13 bold fonts; size, position, words per caption, 1 or 2 lines, uppercase; text/outline/highlight/emphasis colours; outline, shadow, background box; active-word highlight (colour or box); pop or fade animation. |
| Clean-up | Remove filler words (um, uh), strip periods and commas, and **find & replace** across every clip (brand names, "fifty thousand dollars" → "$50K"). |
| Text overlay style | Font, size, colours and box for the on-screen text. |
| Speech recognition | Runs on this computer. Choose speed vs accuracy, set the language, and list brand or product names so they're spelled correctly. |

### Brand tab
| Feature | What it does |
|---|---|
| Logo | Watermark in any corner; size, opacity and margin. Not shown on the end card. |
| End card | An image or short video added to the end of every ad. Images that don't match a format get a blurred background. |
| Music | Loops under every ad, dips automatically while someone talks, and fades out at the end. Use licensed tracks only. |
| Progress bar | A thin bar that fills as the ad plays; top or bottom, any colour. |
| Clean up voice | Removes rumble and background hiss and evens out levels. Made for phone-recorded footage. |
| Loudness | Every clip and every finished ad is levelled to the same loudness (-14 LUFS, the standard for social), so nothing is quieter or louder than the rest. |

### Export, matrix & rendering
| Feature | What it does |
|---|---|
| Matrix | Grid of every hook × body. Click cells, whole rows or columns, or "All hooks × one body". ▶ previews that combo. |
| Export settings | Formats; crop to fill or fit with a blurred background; quality; speed; parallel jobs; file-name pattern (default `Project_H03_B01_9x16.mp4`). |
| Fast batches | Each clip is rendered once per format and then joined, so 36 ads take roughly the time of 20. Unchanged clips are reused on the next render. |
| Output | One MP4 per ad plus `manifest.csv` listing every ad and its hook script. *Open folder*, *Download .zip*, or watch any file in the app. Cancel anytime. |

### Everywhere
| Feature | What it does |
|---|---|
| Auto-save | Every change is saved instantly. |
| Undo / redo | **Ctrl/⌘+Z** and **Shift+Ctrl/⌘+Z**, or the arrows in the top bar. |
| Help | **?** in the top bar: the tour, this feature guide, and shortcuts. |

## Keyboard shortcuts
| Key | Action |
|---|---|
| Space | Play / pause |
| I / O | Set the clip's in / out point at the playhead |
| ← / → | Step one frame (Shift: one second) |
| ↑ / ↓ | Previous / next hook |
| B | Switch to the next body |
| M | Open the matrix |
| Ctrl/⌘ Z | Undo (add Shift to redo) |
| Esc | Close a window or the tour |

## Troubleshooting
- **"Speech model didn't download" chip.** Check the internet connection and click the chip to retry. Captions need this one-time download.
- **Captions say "failed" on a clip.** Click **Redo** in that clip's transcript. For hard-to-hear audio, set *Captions → Speech recognition → Model* to "Accurate" or "Best".
- **"ffmpeg problem" banner.** On a Mac, install Homebrew and run `brew install ffmpeg`. On Windows, run `winget install ffmpeg`. Then restart Ad Factory.
- **Port already in use.** Ad Factory picks the next free port; use the address printed in the terminal window.
