"""HTTP API + static UI."""
from __future__ import annotations

import mimetypes
import os
import shutil
import zipfile
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response, StreamingResponse

from . import captions, fonts, media, pipeline, state, timeline, transcribe

STATIC = Path(__file__).parent / "static"
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mts"}
IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}

app = FastAPI(title="Ad Factory")


def _p(pid: str) -> dict:
    try:
        return state.get(pid)
    except KeyError:
        raise HTTPException(404, "Project not found")


def _c(pid: str, cid: str) -> dict:
    try:
        return state.clip(pid, cid)
    except KeyError:
        raise HTTPException(404, "Clip not found")


def _project_out(p: dict) -> dict:
    out = dict(p)
    live = {bid: r["batch"] for bid, r in pipeline.RUNNING.items()}
    out["batches"] = [live.get(b["id"], b) for b in p["batches"]]
    return out


# ---------------------------------------------------------------- meta

@app.get("/api/meta")
def meta():
    try:
        b = media.bins()
        ff = {"ok": True, "hdr_tonemap": b["zscale"]}
    except Exception as e:
        ff = {"ok": False, "error": str(e)}
    return {
        "fonts": list(fonts.fonts().values()),
        "presets": {k: {**captions.preset_style(k), "label": v["label"]} for k, v in captions.PRESETS.items()},
        "formats": {k: {"w": w, "h": h} for k, (w, h) in captions.FORMATS.items()},
        "models": transcribe.MODELS,
        "speech": transcribe.warm_state,
        "ffmpeg": ff,
        "home": str(state.HOME),
    }


@app.post("/api/speech/warm")
async def speech_warm(req: Request):
    model = (await req.json()).get("model") or "small"
    transcribe.warm(model)
    return transcribe.warm_state


# ---------------------------------------------------------------- projects

@app.get("/api/projects")
def projects():
    return state.list_projects()


@app.post("/api/projects")
async def create_project(req: Request):
    body = await req.json()
    src = body.get("copy_from")
    if src:
        _p(src)
    return state.create(body.get("name") or "New project", copy_from=src)


@app.get("/api/projects/{pid}")
def get_project(pid: str):
    return _project_out(_p(pid))


@app.patch("/api/projects/{pid}")
async def patch_project(pid: str, req: Request):
    _p(pid)
    return _project_out(state.patch_project(pid, await req.json()))


@app.get("/api/projects/{pid}/status")
def status(pid: str):
    p = _p(pid)
    running = [r["batch"] for r in pipeline.RUNNING.values()
               if r["batch"]["status"] == "running" or r["batch"].get("finished", 0) > 0]
    return {"rev": p.get("rev", 0), "clips": {c["id"]: c.get("rev", 0) for c in p["clips"]},
            "speech": transcribe.warm_state,
            "batches": [b for b in running if not b.get("preview")]}


@app.delete("/api/projects/{pid}")
def delete_project(pid: str):
    _p(pid)
    with state.lock:
        shutil.rmtree(state.pdir(pid), ignore_errors=True)
        state._cache.pop(pid, None)
    return {"ok": True}


# ---------------------------------------------------------------- clips

@app.post("/api/projects/{pid}/clips")
async def upload_clip(pid: str, role: str = Form(...), file: UploadFile = File(...)):
    _p(pid)
    if role not in ("hook", "body"):
        raise HTTPException(400, "role must be hook or body")
    ext = Path(file.filename or "clip.mp4").suffix.lower()
    if ext not in VIDEO_EXT:
        raise HTTPException(400, f"Unsupported file type {ext}")
    c = state.new_clip(pid, role, file.filename or "clip", ext)
    dst = state.pdir(pid) / c["file"]
    dst.parent.mkdir(parents=True, exist_ok=True)
    with open(dst, "wb") as fh:
        while chunk := await file.read(4 * 1024 * 1024):
            fh.write(chunk)
    pipeline.process_clip(pid, c["id"])
    return c


@app.patch("/api/projects/{pid}/clips/{cid}")
async def patch_clip(pid: str, cid: str, req: Request):
    _c(pid, cid)
    return state.patch_clip(pid, cid, await req.json())


@app.delete("/api/projects/{pid}/clips/{cid}")
def delete_clip(pid: str, cid: str):
    _c(pid, cid)
    state.delete_clip(pid, cid)
    return {"ok": True}


@app.post("/api/projects/{pid}/clips/{cid}/transcribe")
def retranscribe(pid: str, cid: str):
    c = _c(pid, cid)
    if c["status"] != "ready":
        raise HTTPException(400, "Clip is still processing")
    pipeline.queue_transcription(pid, cid)
    return state.clip(pid, cid)


@app.post("/api/projects/{pid}/clips/{cid}/realign")
async def realign(pid: str, cid: str, req: Request):
    c = _c(pid, cid)
    text = (await req.json()).get("text", "")
    old = (c.get("transcript") or {}).get("words") or []
    with state.lock:
        c["transcript"] = {**(c.get("transcript") or {}), "words": transcribe.realign(old, text)}
        state.bump(pid, c)
    return c


@app.post("/api/projects/{pid}/clips/{cid}/autotrim")
def autotrim(pid: str, cid: str):
    c = _c(pid, cid)
    if not c.get("meta"):
        raise HTTPException(400, "Clip is still processing")
    env = pipeline.load_env(pid, cid)
    s, e = transcribe.auto_trim((c.get("transcript") or {}).get("words") or [], env["env"], env["env_fps"],
                                c["meta"]["duration"])
    return state.patch_clip(pid, cid, {"trim": {"in": s, "out": e}})


@app.get("/api/projects/{pid}/clips/{cid}/envelope")
def envelope(pid: str, cid: str):
    _c(pid, cid)
    return pipeline.load_env(pid, cid)


@app.post("/api/projects/{pid}/layout")
async def layout(pid: str, req: Request):
    """Caption chunks for the live preview (same code path as the burn-in)."""
    p = _p(pid)
    body = await req.json()
    style = body.get("style") or p["style"]
    edits = body.get("clips") or {}  # unsaved trim / pause settings from the editor
    caps, keep = {}, {}
    for c in p["clips"]:
        words = (c.get("transcript") or {}).get("words")
        if words:
            caps[c["id"]] = captions.layout(words, style)
        if c.get("meta"):
            cc = {**c, **{k: v for k, v in (edits.get(c["id"]) or {}).items() if k in ("trim", "pauses")}}
            keep[c["id"]] = timeline.keep_ranges(cc, pipeline.load_env(pid, c["id"]))
    return {"captions": caps, "keep": keep}


# ---------------------------------------------------------------- brand assets

@app.post("/api/projects/{pid}/assets")
async def upload_asset(pid: str, kind: str = Form(...), file: UploadFile = File(...)):
    p = _p(pid)
    ext = Path(file.filename or "").suffix.lower()
    allowed = {"logo": IMAGE_EXT, "endcard": IMAGE_EXT | VIDEO_EXT, "music": AUDIO_EXT | {".mp4", ".mov"}}
    if kind not in allowed or ext not in allowed[kind]:
        raise HTTPException(400, f"Unsupported file for {kind}: {ext}")
    import uuid
    rel = f"assets/{kind}-{uuid.uuid4().hex[:6]}{ext}"
    dst = state.pdir(pid) / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    with open(dst, "wb") as fh:
        while chunk := await file.read(4 * 1024 * 1024):
            fh.write(chunk)
    try:
        info = pipeline.process_asset(pid, kind, rel)
    except Exception as e:
        dst.unlink(missing_ok=True)
        raise HTTPException(400, f"Could not read that file: {e}")
    info["name"] = file.filename
    brand = dict(p["brand"])
    brand[kind] = info
    return _project_out(state.patch_project(pid, {"brand": brand}))


# ---------------------------------------------------------------- render

@app.post("/api/projects/{pid}/render")
async def render(pid: str, req: Request):
    _p(pid)
    body = await req.json()
    try:
        return pipeline.start_batch(pid, body.get("combos") or [], body.get("formats") or [],
                                    preview=bool(body.get("preview")))
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.get("/api/batches/{bid}")
def batch(bid: str):
    r = pipeline.RUNNING.get(bid)
    if not r:
        raise HTTPException(404, "Batch not running")
    return r["batch"]


@app.post("/api/batches/{bid}/cancel")
def cancel(bid: str):
    r = pipeline.RUNNING.get(bid)
    if r:
        r["cancel"].set()
    return {"ok": True}


@app.post("/api/projects/{pid}/open")
async def open_folder(pid: str, req: Request):
    rel = (await req.json()).get("path", "")
    target = _safe(pid, rel)
    if not target.exists():
        raise HTTPException(404, "Folder not found")
    try:
        media.open_in_os(target)
        return {"ok": True, "path": str(target)}
    except Exception:
        return {"ok": False, "path": str(target)}  # no file browser available: show the path instead


@app.get("/api/projects/{pid}/zip")
def zip_batch(pid: str, path: str):
    folder = _safe(pid, path)
    if not folder.is_dir():
        raise HTTPException(404, "Folder not found")
    files = sorted(f for f in folder.iterdir() if f.is_file() and not f.name.endswith(".part.mp4"))

    def gen():
        import io

        class Sink(io.RawIOBase):
            def __init__(self):
                self.buf = bytearray()

            def writable(self):
                return True

            def write(self, b):
                self.buf += b
                return len(b)

        sink = Sink()
        with zipfile.ZipFile(sink, "w", zipfile.ZIP_STORED) as z:
            for f in files:
                with z.open(f.name, "w", force_zip64=True) as dst, open(f, "rb") as src:
                    while chunk := src.read(1 << 20):
                        dst.write(chunk)
                        if len(sink.buf) > (4 << 20):
                            yield bytes(sink.buf)
                            sink.buf.clear()
        yield bytes(sink.buf)

    return StreamingResponse(gen(), media_type="application/zip",
                             headers={"Content-Disposition": f'attachment; filename="{folder.name}.zip"'})


# ---------------------------------------------------------------- files

def _safe(pid: str, rel: str) -> Path:
    base = state.pdir(pid).resolve()
    target = (base / rel).resolve()
    if base != target and base not in target.parents:
        raise HTTPException(403, "Bad path")
    return target


def _ranged(path: Path, request: Request, media_type: str | None = None):
    if not path.is_file():
        raise HTTPException(404, "Not found")
    size = path.stat().st_size
    mt = media_type or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    rng = request.headers.get("range")
    if not rng or not rng.startswith("bytes="):
        return FileResponse(path, media_type=mt, headers={"Accept-Ranges": "bytes", "Cache-Control": "no-cache"})
    start_s, _, end_s = rng[6:].split(",")[0].partition("-")
    if start_s:
        start = int(start_s)
        end = min(int(end_s), size - 1) if end_s else size - 1
    else:
        start, end = max(0, size - int(end_s)), size - 1
    if start >= size:
        return Response(status_code=416, headers={"Content-Range": f"bytes */{size}"})
    length = end - start + 1

    def gen():
        with open(path, "rb") as fh:
            fh.seek(start)
            left = length
            while left > 0:
                chunk = fh.read(min(1 << 20, left))
                if not chunk:
                    break
                left -= len(chunk)
                yield chunk

    return StreamingResponse(gen(), status_code=206, media_type=mt, headers={
        "Content-Range": f"bytes {start}-{end}/{size}", "Accept-Ranges": "bytes",
        "Content-Length": str(length), "Cache-Control": "no-cache"})


@app.get("/files/{pid}/{rel:path}")
def files(pid: str, rel: str, request: Request):
    return _ranged(_safe(pid, rel), request)


@app.get("/fonts/{name}")
def font_file(name: str, request: Request):
    p = (fonts.FONT_DIR / name).resolve()
    if p.parent != fonts.FONT_DIR.resolve():
        raise HTTPException(403)
    return _ranged(p, request, "font/ttf")


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


@app.get("/static/{name}")
def static(name: str, request: Request):
    p = (STATIC / name).resolve()
    if p.parent != STATIC.resolve():
        raise HTTPException(403)
    return FileResponse(p, headers={"Cache-Control": "no-cache"})


@app.exception_handler(Exception)
async def errors(_req, exc):
    return JSONResponse({"detail": str(exc)}, status_code=500)
