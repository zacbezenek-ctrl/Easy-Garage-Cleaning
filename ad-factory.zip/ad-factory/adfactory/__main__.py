"""Start Ad Factory: python -m adfactory"""
import os
import socket
import threading
import webbrowser


def _free_port(start: int) -> int:
    for port in range(start, start + 30):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    return start


def main() -> None:
    import uvicorn

    from . import media, render, state

    port = _free_port(int(os.environ.get("ADF_PORT", "8765")))
    url = f"http://127.0.0.1:{port}"
    print("\n  Ad Factory")
    print(f"  Projects folder: {state.HOME}")
    print("  Checking ffmpeg (first run may download it)...")
    try:
        b = media.bins()
        print(f"  ffmpeg: {b['ffmpeg']}")
    except Exception as e:
        print(f"  !! {e}")
    render.fonts_dir()
    from . import transcribe
    recent = state.list_projects()
    model = state.get(recent[0]["id"])["transcription"]["model"] if recent else "small"
    transcribe.warm(model)  # fetch the speech model in the background (first launch only)
    print(f"\n  Open {url} in your browser (Chrome recommended). Keep this window open.\n")
    if not os.environ.get("ADF_NO_BROWSER"):
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    uvicorn.run("adfactory.server:app", host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    main()
