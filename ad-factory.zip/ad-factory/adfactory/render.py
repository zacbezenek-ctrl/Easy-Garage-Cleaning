"""ffmpeg render steps.

Stage 1 renders every clip once per format (framing, logo, captions, loudness) into an
intermediate .mov. Stage 2 joins hook + body (+ end card) per ad: video is stream-copied,
audio is mixed with music once. 18 hooks x 2 bodies = 20 heavy renders, not 36.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import tempfile
import threading
from pathlib import Path

from . import captions, media, state, timeline

FPS = 30
VERSION = 6  # bump to invalidate cached segments when the render recipe changes
CRF = {"standard": 21, "high": 18, "max": 16}
# rumble cut, adaptive hiss/room-noise reduction, gentle levelling; makeup offsets the compressor
# Runs after per-clip normalisation, so the gate threshold means the same thing on every clip.
VOICE_CLEANUP = ("highpass=f=85,afftdn=nr=24:nf=-40:tn=1,"
                 "agate=threshold=0.02:ratio=3:range=0.25:attack=5:release=180,"
                 "acompressor=threshold=0.1:ratio=2.5:attack=8:release=160:makeup=1.6,")
PRESET = {"fast": "veryfast", "balanced": "fast", "best": "medium", "preview": "ultrafast"}


class Cancelled(Exception):
    pass


def _even(x: float) -> int:
    return max(2, int(round(x / 2)) * 2)


def frame_dur(d: float) -> float:
    return max(1, int(d * FPS + 0.5)) / FPS


def run_ffmpeg(args: list[str], duration: float, on_progress=None, cancel: threading.Event | None = None,
               cwd: str | None = None) -> None:
    b = media.bins()
    if cancel is not None and cancel.is_set():
        raise Cancelled()
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8", errors="replace") as err:
        proc = subprocess.Popen([b["ffmpeg"], "-hide_banner", "-y", "-nostats", "-progress", "pipe:1", *args],
                                stdout=subprocess.PIPE, stderr=err, text=True, cwd=cwd,
                                creationflags=media.NO_WINDOW, encoding="utf-8", errors="replace")
        try:
            for line in proc.stdout:  # type: ignore[union-attr]
                if cancel is not None and cancel.is_set():
                    proc.terminate()
                    raise Cancelled()
                if line.startswith(("out_time_us=", "out_time_ms=")) and on_progress and duration > 0:
                    try:
                        on_progress(min(1.0, int(line.split("=")[1]) / 1e6 / duration))
                    except ValueError:
                        pass
            proc.wait()
        finally:
            if proc.poll() is None:
                proc.kill()
        if proc.returncode != 0:
            err.seek(0)
            raise RuntimeError("ffmpeg: " + err.read()[-1200:].strip())


def _fit_chain(sw: int, sh: int, W: int, H: int, crop: dict, fit: str) -> str:
    """Video framing. Same math as the browser preview (see positionMedia in app.js)."""
    zoom = max(1.0, float(crop.get("zoom") or 1))
    fx, fy = float(crop.get("x", 0.5)), float(crop.get("y", 0.5))
    if fit == "blur":
        cs = max(W / sw, H / sh)
        bw, bh = _even(sw * cs), _even(sh * cs)
        s = min(W / sw, H / sh) * zoom
        fw, fh = _even(sw * s), _even(sh * s)
        x, y = round((W - fw) * fx), round((H - fh) * fy)
        return (f"split=2[bga][fga];[bga]scale={bw}:{bh},crop={W}:{H},boxblur=30:3,eq=brightness=-0.06[bgb];"
                f"[fga]scale={fw}:{fh}:flags=lanczos[fgb];[bgb][fgb]overlay={x}:{y}")
    s = max(W / sw, H / sh) * zoom
    cw, ch = max(W, _even(sw * s)), max(H, _even(sh * s))
    x, y = round((cw - W) * fx), round((ch - H) * fy)
    return f"scale={cw}:{ch}:flags=lanczos,crop={W}:{H}:{x}:{y}"


def _logo_xy(brand: dict, W: int, H: int, lw: int) -> tuple[str, str]:
    m = round(brand.get("logo_margin", 0.045) * min(W, H))
    pos = brand.get("logo_pos", "tr")
    x = str(m) if pos in ("tl", "bl") else f"{W}-w-{m}"
    y = str(m) if pos in ("tl", "tr") else f"{H}-h-{m}"
    return x, y


def _hash(obj) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _file_sig(p: Path) -> list:
    st = p.stat()
    return [str(p), st.st_size, int(st.st_mtime)]


def clip_gain(clip: dict, brand: dict) -> float:
    g = float(clip.get("gain_db") or 0)
    if brand.get("normalize", True) and clip.get("lufs") is not None:
        g += float(brand.get("lufs_target", -14)) - float(clip["lufs"])
    return max(-24.0, min(24.0, g))


def segment_job(project: dict, clip: dict, fmt: str, opts: dict) -> dict:
    """Describe one stage-1 render (cache key + everything needed to run it)."""
    pd = state.pdir(project["id"])
    src = pd / clip["file"]
    meta = clip["meta"]
    keep = timeline.keep_ranges(clip, load_env(project["id"], clip["id"]))
    t_in = keep[0][0]
    dur = timeline.out_duration(keep)
    brand = project["brand"]
    logo = brand.get("logo")
    words = (clip.get("transcript") or {}).get("words") or []
    key_src = {
        "v": VERSION, "src": _file_sig(src), "keep": keep, "crop": clip.get("crop"), "fmt": fmt,
        "scale": opts["scale"], "q": opts["quality"], "sp": opts["speed"], "fit": opts["fit"],
        "gain": clip_gain(clip, brand), "style": project["style"], "ost": project["overlay_style"],
        "words": words, "ov": clip.get("overlays"), "enh": bool(brand.get("voice_enhance")),
        "logo": [_file_sig(pd / logo["file"]), brand["logo_pos"], brand["logo_size"], brand["logo_opacity"],
                 brand["logo_margin"]] if logo else None,
    }
    key = _hash(key_src)
    return {"key": key, "kind": "clip", "clip": clip, "fmt": fmt, "t_in": t_in, "dur": dur, "keep": keep,
            "out": pd / "cache" / "seg" / f"{key}.mov", "words": words}


def load_env(pid: str, cid: str) -> dict:
    p = state.pdir(pid) / "cache" / "env" / f"{cid}.json"
    return json.loads(p.read_text()) if p.exists() else {"env": [], "env_fps": 100}


def endcard_job(project: dict, fmt: str, opts: dict) -> dict | None:
    brand = project["brand"]
    ec = brand.get("endcard")
    if not ec:
        return None
    pd = state.pdir(project["id"])
    src = pd / ec["file"]
    dur = frame_dur(float(brand.get("endcard_duration") or 2.5) if ec["kind"] == "image"
                    else float(ec["meta"]["duration"]))
    key = _hash({"v": VERSION, "ec": _file_sig(src), "dur": dur, "fmt": fmt, "scale": opts["scale"],
                 "q": opts["quality"], "sp": opts["speed"], "norm": brand.get("lufs_target")})
    return {"key": key, "kind": "endcard", "endcard": ec, "fmt": fmt, "t_in": 0.0, "dur": dur,
            "out": pd / "cache" / "seg" / f"{key}.mov"}


def _encode_args(opts: dict) -> list[str]:
    return ["-c:v", "libx264", "-preset", PRESET[opts["speed"]], "-crf", str(CRF[opts["quality"]]),
            "-pix_fmt", "yuv420p", "-profile:v", "high", "-r", str(FPS), "-g", str(FPS * 2),
            "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709"]


def render_segment(project: dict, job: dict, opts: dict, on_progress=None, cancel=None) -> Path:
    out: Path = job["out"]
    if out.exists() and out.stat().st_size > 0:
        return out
    out.parent.mkdir(parents=True, exist_ok=True)
    pd = state.pdir(project["id"])
    brand = project["brand"]
    W0, H0 = captions.FORMATS[job["fmt"]]
    W, H = _even(W0 * opts["scale"]), _even(H0 * opts["scale"])
    dur = job["dur"]
    args: list[str] = []
    fc: list[str] = []

    if job["kind"] == "endcard":
        ec = job["endcard"]
        src = pd / ec["file"]
        if ec["kind"] == "image":
            args += ["-loop", "1", "-framerate", str(FPS), "-t", f"{dur:.3f}", "-i", str(src)]
            sw, sh = ec["meta"]["width"], ec["meta"]["height"]
            has_audio, info, gain = False, ec["meta"], 0.0
        else:
            args += ["-t", f"{dur:.3f}", "-i", str(src)]
            info = ec["meta"]
            sw, sh, has_audio = info["width"], info["height"], info["has_audio"]
            gain = (float(brand.get("lufs_target", -14)) - ec["lufs"]) if (brand.get("normalize") and ec.get("lufs") is not None) else 0.0
        fit = "fill" if abs(sw / sh - W / H) < 0.02 else "blur"
        fc.append(f"[0:v]{media.sdr_filter(info)}setsar=1,{_fit_chain(sw, sh, W, H, {}, fit)},fps={FPS},format=yuv420p[vout]")
    else:
        c = job["clip"]
        info = c["meta"]
        src = pd / c["file"]
        keep = job["keep"]
        span = keep[-1][1] - job["t_in"]
        args += ["-ss", f"{job['t_in']:.3f}", "-t", f"{span:.3f}", "-i", str(src)]
        sw, sh, has_audio = info["width"], info["height"], info["has_audio"]
        gain = clip_gain(c, brand)
        fc.append(f"[0:v]{media.sdr_filter(info)}setsar=1,{_fit_chain(sw, sh, W, H, c.get('crop') or {}, opts['fit'])},fps={FPS},format=yuv420p[vfit]")
        if has_audio:
            fc.append("[0:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo[afit]")
        if len(keep) > 1:
            # jump cuts: trim each kept piece (frame-aligned) and butt them together
            k = len(keep)
            fc.append(f"[vfit]split={k}" + "".join(f"[vs{i}]" for i in range(k)))
            if has_audio:
                fc.append(f"[afit]asplit={k}" + "".join(f"[as{i}]" for i in range(k)))
            pairs = []
            for i, (a0, a1) in enumerate(keep):
                r0, r1 = a0 - job["t_in"], a1 - job["t_in"]
                fc.append(f"[vs{i}]trim=start={r0:.4f}:end={r1:.4f},setpts=PTS-STARTPTS[vp{i}]")
                pairs.append(f"[vp{i}]")
                if has_audio:
                    ln = r1 - r0
                    fc.append(f"[as{i}]atrim=start={r0:.4f}:end={r1:.4f},asetpts=PTS-STARTPTS,"
                              f"afade=t=in:d=0.006,afade=t=out:st={max(0, ln - 0.006):.4f}:d=0.006[ap{i}]")
                    pairs.append(f"[ap{i}]")
            fc.append("".join(pairs) + f"concat=n={k}:v=1:a={1 if has_audio else 0}[vcat]" + ("[acat]" if has_audio else ""))
            vin, ain = "[vcat]", "[acat]"
        else:
            vin, ain = "[vfit]", "[afit]"
        chain = f"{vin}null"
        logo = brand.get("logo")
        if logo:
            args += ["-loop", "1", "-i", str(pd / logo["file"])]
            lw = _even(W * float(brand["logo_size"]))
            x, y = _logo_xy(brand, W, H, lw)
            fc.append(f"[1:v]format=rgba,scale={lw}:-2,colorchannelmixer=aa={float(brand['logo_opacity']):.2f}[lg]")
            fc.append(f"{vin}[lg]overlay={x}:{y}:shortest=1[vc]")
            chain = "[vc]null"
        ass = captions.build_ass(words=job["words"], style=project["style"], overlay_style=project["overlay_style"],
                                 overlays=c.get("overlays") or [], fmt=job["fmt"], tmap=timeline.mapper(keep),
                                 duration=dur, scale=opts["scale"])
        ass_path = pd / "cache" / "ass" / f"{job['key']}.ass"
        ass_path.parent.mkdir(parents=True, exist_ok=True)
        ass_path.write_text(ass, encoding="utf-8")
        # relative paths from HOME keep Windows drive letters out of the filter string
        rel_ass = Path(os.path.relpath(ass_path, state.HOME)).as_posix()
        rel_fonts = Path(os.path.relpath(fonts_dir(), state.HOME)).as_posix()
        fc.append(f"{chain},ass='{rel_ass}':fontsdir='{rel_fonts}'[vout]")

    if has_audio:
        src_a = ain if job["kind"] == "clip" else "[0:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
        enh = VOICE_CLEANUP if (job["kind"] == "clip" and brand.get("voice_enhance")) else ""
        fc.append(f"{src_a}volume={gain:.2f}dB,{enh}"
                  f"alimiter=limit=0.97:level=0:attack=5:release=60,"
                  f"afade=t=in:d=0.012,afade=t=out:st={max(0, dur - 0.025):.3f}:d=0.025,apad,atrim=0:{dur:.3f}[aout]")
    else:
        fc.append(f"anullsrc=r=48000:cl=stereo,atrim=0:{dur:.3f}[aout]")

    tmp = out.with_suffix(".part.mov")
    args += ["-filter_complex", ";".join(fc), "-map", "[vout]", "-map", "[aout]", *_encode_args(opts),
             "-c:a", "pcm_s16le", "-t", f"{dur:.3f}", str(tmp)]
    try:
        run_ffmpeg(args, dur, on_progress, cancel, cwd=str(state.HOME))
        os.replace(tmp, out)
    finally:
        tmp.unlink(missing_ok=True)
    return out


def render_combo(project: dict, segs: list[Path], durs: list[float], fmt: str, out: Path, opts: dict,
                 on_progress=None, cancel=None) -> float:
    pd = state.pdir(project["id"])
    brand = project["brand"]
    total = sum(durs)
    W0, H0 = captions.FORMATS[fmt]
    W, H = _even(W0 * opts["scale"]), _even(H0 * opts["scale"])
    lst = pd / "cache" / "concat" / f"{out.stem}.txt"
    lst.parent.mkdir(parents=True, exist_ok=True)
    lst.write_text("".join("file '" + s.as_posix().replace("'", "'\\''") + "'\n" for s in segs), encoding="utf-8")
    args = ["-f", "concat", "-safe", "0", "-i", str(lst)]
    fc = []
    music = brand.get("music")
    if music:
        args += ["-stream_loop", "-1", "-i", str(pd / music["file"])]
    prog = brand.get("progress") or {}
    if prog.get("enabled"):
        bh = max(2, round(float(prog.get("height", 10)) * opts["scale"]))
        by = 0 if prog.get("position", "top") == "top" else H - bh
        col = prog.get("color", "#FFE600").lstrip("#")
        fc.append(f"color=c=0x{col}:s={W}x{bh}:r={FPS}:d={total:.3f}[bar]")
        fc.append(f"[0:v]drawbox=x=0:y={by}:w=iw:h={bh}:color=black@0.35:t=fill[vbg]")
        fc.append(f"[vbg][bar]overlay=x='-w+w*t/{total:.3f}':y={by}:shortest=1[vout]")
        vmap, vcodec = "[vout]", _encode_args(opts)
    else:
        vmap, vcodec = "0:v", ["-c:v", "copy"]
    afc = []
    if music:
        fade = min(1.5, total / 3)
        afc.append(f"[1:a]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
                   f"volume={float(brand.get('music_volume', -20)):.1f}dB,atrim=0:{total:.3f},"
                   f"afade=t=out:st={total - fade:.3f}:d={fade:.3f}[m]")
        if brand.get("music_duck", True):
            afc.append("[0:a]asplit=2[va][vsc]")
            afc.append("[m][vsc]sidechaincompress=threshold=0.04:ratio=5:attack=20:release=450[md]")
            afc.append("[va][md]amix=inputs=2:duration=first:normalize=0[mix]")
        else:
            afc.append("[0:a][m]amix=inputs=2:duration=first:normalize=0[mix]")
    else:
        afc.append("[0:a]anull[mix]")
    gain = 0.0
    if brand.get("normalize", True):
        # measure the finished mix (voice + music) so every ad lands on the target loudness
        lufs = _measure_lufs(args, afc, total, cancel)
        if lufs is not None:
            gain = max(-12.0, min(12.0, float(brand.get("lufs_target", -14)) - lufs))
    afc.append(f"[mix]volume={gain:.2f}dB,alimiter=limit=0.89:level=0:attack=4:release=80[aout]")
    fc += afc
    tmp = out.with_name(out.stem + ".part.mp4")
    args += ["-filter_complex", ";".join(fc), "-map", vmap, "-map", "[aout]", *vcodec,
             "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-movflags", "+faststart", "-t", f"{total:.3f}", str(tmp)]
    try:
        run_ffmpeg(args, total, on_progress, cancel)
        os.replace(tmp, out)
    finally:
        tmp.unlink(missing_ok=True)
    return total


def _measure_lufs(input_args: list[str], afc: list[str], total: float, cancel=None) -> float | None:
    if cancel is not None and cancel.is_set():
        raise Cancelled()
    b = media.bins()
    graph = ";".join(afc + ["[mix]loudnorm=print_format=json[meas]"])
    p = subprocess.run([b["ffmpeg"], "-hide_banner", "-nostats", *input_args, "-filter_complex", graph,
                        "-map", "[meas]", "-t", f"{total:.3f}", "-f", "null", "-"],
                       capture_output=True, text=True, creationflags=media.NO_WINDOW, encoding="utf-8", errors="replace")
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", p.stderr, re.S)
    try:
        v = float(json.loads(m.group(0))["input_i"]) if m else None
    except (ValueError, KeyError):
        return None
    return v if v is not None and v > -70 else None


_fonts_ready = False


def fonts_dir() -> Path:
    """libass reads fonts from a folder under HOME so the filter path stays relative."""
    global _fonts_ready
    from . import fonts as fontreg
    d = state.HOME / "fonts"
    if not _fonts_ready:
        d.mkdir(parents=True, exist_ok=True)
        for f in fontreg.FONT_DIR.glob("*.ttf"):
            dst = d / f.name
            if not dst.exists() or dst.stat().st_size != f.stat().st_size:
                dst.write_bytes(f.read_bytes())
        _fonts_ready = True
    return d
