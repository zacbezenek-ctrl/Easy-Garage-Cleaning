/* Ad Factory editor UI (no build step, no dependencies). */
'use strict';

// ------------------------------------------------------------------ utils
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'html') e.innerHTML = v;
    else if (v === true) e.setAttribute(k, '');
    else e.setAttribute(k, v);
  }
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    e.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
  return e;
}

async function api(method, path, body) {
  const opt = { method, headers: {} };
  if (body !== undefined) { opt.headers['content-type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const r = await fetch(path, opt);
  let data = null;
  try { data = await r.json(); } catch { /* empty */ }
  if (!r.ok) throw new Error((data && data.detail) || `${r.status} ${r.statusText}`);
  return data;
}

function toast(msg, err = false, ms = 3500) {
  const t = h('div', { class: 'toast' + (err ? ' err' : '') }, msg);
  $('#toasts').append(t);
  setTimeout(() => t.remove(), ms);
}
const fail = (e) => { console.error(e); toast(e.message || String(e), true, 6000); };

function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmtT = (t) => { t = Math.max(0, t || 0); const m = Math.floor(t / 60); return `${m}:${(t - m * 60).toFixed(1).padStart(4, '0')}`; };
const natSort = (a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
const db2gain = (db) => Math.pow(10, db / 20);
function rgba(hex, a = 1) {
  let x = (hex || '#ffffff').replace('#', '');
  if (x.length === 3) x = [...x].map((c) => c + c).join('');
  const n = parseInt(x, 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fileUrl = (rel) => `/files/${S.p.id}/${rel}`;

// ------------------------------------------------------------------ state
const S = {
  meta: null, projects: [], p: null, rev: -1,
  sel: { hook: null, body: null, clip: null },
  fmt: localStorage.getItem('adf.fmt') || '9x16',
  safe: localStorage.getItem('adf.safe') || 'reels',
  tab: 'clip', layout: {}, keep: {}, env: {}, capVer: 0,
  uploads: [], wordSel: null, textMode: false, panelDirty: false,
  batch: null, previewBusy: false,
};
const FMT_LABEL = { '9x16': '9:16', '4x5': '4:5', '1x1': '1:1', '16x9': '16:9' };
const FMT_USE = { '9x16': 'Reels · TikTok · Stories', '4x5': 'Feed', '1x1': 'Feed (square)', '16x9': 'YouTube · in-stream' };

const clips = (role) => (S.p ? S.p.clips.filter((c) => !role || c.role === role) : []);
const clipById = (id) => S.p && S.p.clips.find((c) => c.id === id);
const trimOf = (c) => c.trim || { in: 0, out: (c.meta && c.meta.duration) || 0 };
const fontOf = (id) => S.meta.fonts.find((f) => f.id === id) || S.meta.fonts[0];
const fmtDims = (f) => S.meta.formats[f || S.fmt];

// ------------------------------------------------------------------ saving
const pendingProject = {};
const pendingClips = {};
let saving = 0;
function setSaveState() { $('#saveState').textContent = saving || Object.keys(pendingProject).length || Object.keys(pendingClips).length ? 'Saving…' : 'Saved'; }

// pendingProject holds section names; values are read at send time so a newer local value always wins
async function sendProject() {
  const keys = Object.keys(pendingProject);
  for (const k of keys) delete pendingProject[k];
  if (!keys.length || !S.p) return;
  const body = Object.fromEntries(keys.map((k) => [k, S.p[k]]));
  saving++; setSaveState();
  try { await api('PATCH', `/api/projects/${S.p.id}`, body); } catch (e) { fail(e); }
  saving--; setSaveState();
}
const flushProject = debounce(sendProject, 400);
function saveProject(section) { markDirty(); pendingProject[section] = true; setSaveState(); flushProject(); }

const clipFlushers = {};
async function sendClip(cid) {
  const body = pendingClips[cid];
  delete pendingClips[cid];
  if (!body || !S.p) return;
  saving++; setSaveState();
  try {
    const c = await api('PATCH', `/api/projects/${S.p.id}/clips/${cid}`, body);
    const local = clipById(cid);
    if (local) { local.rev = c.rev; if (body.words) requestLayout(); }
  } catch (e) { fail(e); }
  saving--; setSaveState();
}
function saveClip(cid, fields) {
  markDirty();
  pendingClips[cid] = { ...(pendingClips[cid] || {}), ...fields };
  setSaveState();
  if (!clipFlushers[cid]) clipFlushers[cid] = debounce(() => sendClip(cid), 350);
  clipFlushers[cid]();
}
async function flushAll() {
  await Promise.all([sendProject(), ...Object.keys(pendingClips).map(sendClip)]);
}
window.addEventListener('beforeunload', () => {
  if (!S.p) return;
  const send = (url, body) => fetch(url, { method: 'PATCH', keepalive: true, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const keys = Object.keys(pendingProject);
  if (keys.length) send(`/api/projects/${S.p.id}`, Object.fromEntries(keys.map((k) => [k, S.p[k]])));
  for (const [cid, body] of Object.entries(pendingClips)) send(`/api/projects/${S.p.id}/clips/${cid}`, body);
});

// ------------------------------------------------------------------ undo / redo
// Each burst of edits (until 700 ms of quiet) is one step. Snapshots hold only user-editable state.
const U = { base: null, undo: [], redo: [], pending: false, restoring: false };
const PROJECT_KEYS = ['name', 'style', 'overlay_style', 'brand', 'export', 'matrix', 'transcription'];
const CLIP_KEYS = ['name', 'trim', 'crop', 'gain_db', 'overlays', 'pauses'];
function snap() {
  return JSON.stringify({
    project: Object.fromEntries(PROJECT_KEYS.map((k) => [k, S.p[k]])),
    clips: Object.fromEntries(S.p.clips.map((c) => [c.id, { ...Object.fromEntries(CLIP_KEYS.map((k) => [k, c[k] ?? null])), words: c.transcript ? c.transcript.words : null }])),
  });
}
function resetHistory() { U.base = S.p ? snap() : null; U.undo = []; U.redo = []; U.pending = false; renderUndoButtons(); }
const commitHistory = debounce(() => { if (!S.p) return; U.base = snap(); U.pending = false; }, 700);
function markDirty() {
  if (U.restoring || !S.p || U.base == null) return;
  if (!U.pending) { U.undo.push(U.base); if (U.undo.length > 80) U.undo.shift(); U.redo = []; U.pending = true; renderUndoButtons(); }
  commitHistory();
}
async function applySnapshot(target) {
  const cur = JSON.parse(snap()), tgt = JSON.parse(target);
  U.restoring = true;
  try {
    const projPatch = {};
    for (const k of PROJECT_KEYS) {
      if (JSON.stringify(cur.project[k]) !== JSON.stringify(tgt.project[k])) { S.p[k] = tgt.project[k]; projPatch[k] = tgt.project[k]; }
    }
    const calls = [];
    if (Object.keys(projPatch).length) calls.push(api('PATCH', `/api/projects/${S.p.id}`, projPatch));
    for (const c of S.p.clips) {
      const t = tgt.clips[c.id], now = cur.clips[c.id];
      if (!t || JSON.stringify(t) === JSON.stringify(now)) continue;
      const patch = {};
      for (const k of CLIP_KEYS) if (JSON.stringify(t[k]) !== JSON.stringify(now[k])) { c[k] = t[k]; patch[k] = t[k]; }
      if (t.words && c.transcript && JSON.stringify(t.words) !== JSON.stringify(now.words)) { c.transcript.words = t.words; patch.words = t.words; }
      if (Object.keys(patch).length) calls.push(api('PATCH', `/api/projects/${S.p.id}/clips/${c.id}`, patch).then((r) => { c.rev = r.rev; }));
    }
    await Promise.all(calls);
  } catch (e) { fail(e); }
  U.restoring = false;
  $('#projName').value = S.p.name;
  logoKey = null; ovKey = ''; S.capVer++;
  renderAll(); requestLayout();
}
async function undo() {
  if (U.pending) { U.base = snap(); U.pending = false; }
  const prev = U.undo.pop();
  if (!prev) { toast('Nothing to undo'); return; }
  U.redo.push(snap());
  U.base = prev;
  await applySnapshot(prev);
  renderUndoButtons();
}
async function redo() {
  const next = U.redo.pop();
  if (!next) { toast('Nothing to redo'); return; }
  U.undo.push(snap());
  U.base = next;
  await applySnapshot(next);
  renderUndoButtons();
}
function renderUndoButtons() {
  const u = $('#btnUndo'), r = $('#btnRedo');
  if (u) u.disabled = !U.undo.length && !U.pending;
  if (r) r.disabled = !U.redo.length;
}

// ------------------------------------------------------------------ boot
async function boot() {
  try {
    S.meta = await api('GET', '/api/meta');
  } catch (e) { fail(e); return; }
  if (!S.meta.ffmpeg.ok) showBanner('ffmpeg problem: ' + S.meta.ffmpeg.error);
  renderSpeech(S.meta.speech);
  $('#fontFaces').textContent = S.meta.fonts.map((f) => `@font-face{font-family:'adf-${f.id}';src:url('/fonts/${f.file}') format('truetype');font-display:block}`).join('\n');
  S.meta.fonts.forEach((f) => document.fonts.load(`40px 'adf-${f.id}'`).then(() => { S.capVer++; }));
  bindStatic();
  await refreshProjects();
  const last = localStorage.getItem('adf.last');
  const pick = S.projects.find((p) => p.id === last) || S.projects[0];
  if (pick) await loadProject(pick.id); else openNewProject(true);
  requestAnimationFrame(tick);
  setInterval(poll, 1500);
}

function renderSpeech(sp) {
  const chip = $('#speechChip');
  if (!sp || sp.state === 'ready' || sp.state === 'idle') { chip.classList.add('hidden'); return; }
  chip.classList.remove('hidden');
  chip.classList.toggle('err', sp.state === 'error');
  chip.innerHTML = '';
  if (sp.state === 'downloading') {
    chip.append(h('span', { class: 'spin' }), `Downloading speech model ${Math.round((sp.progress || 0) * 100)}%`);
    chip.title = 'One-time download so captions can be transcribed on this computer. You can keep working.';
  } else if (sp.state === 'loading') {
    chip.append(h('span', { class: 'spin' }), 'Loading speech model…');
    chip.title = '';
  } else {
    chip.append('⚠ Speech model didn\'t download. Click to retry');
    chip.title = (sp.error || '') + '\nCheck the internet connection. Captions need this one-time download.';
  }
}

function showBanner(msg) { const b = $('#banner'); b.textContent = msg; b.classList.remove('hidden'); }

async function refreshProjects() {
  S.projects = await api('GET', '/api/projects');
  const sel = $('#projSel');
  sel.innerHTML = '';
  for (const p of S.projects) sel.append(h('option', { value: p.id }, p.name));
  sel.append(h('option', { value: '__new' }, '+ New project…'));
  if (S.p) sel.value = S.p.id;
}

async function loadProject(pid) {
  try {
    pause();
    await flushAll();
    S.p = await api('GET', `/api/projects/${pid}`);
  } catch (e) { fail(e); return; }
  S.rev = S.p.rev; S.layout = {}; S.env = {}; S.wordSel = null; S.textMode = false;
  localStorage.setItem('adf.last', pid);
  resetHistory();
  $('#projSel').value = pid;
  $('#projName').value = S.p.name;
  const h0 = clips('hook')[0], b0 = clips('body')[0];
  S.sel = { hook: h0 && h0.id, body: b0 && b0.id, clip: (h0 || b0 || {}).id || null };
  if (!S.p.export.formats.includes(S.fmt)) S.fmt = S.p.export.formats[0] || '9x16';
  renderAll();
  requestLayout();
  setSaveState();
  setTimeout(maybeAutoTour, 1200);
}

function renderAll() { renderFmtTabs(); renderBin(); buildSequence(); renderPanel(); renderMatrixCount(); }

function openNewProject(force = false) {
  const m = $('#welcome');
  m.classList.remove('hidden');
  $('#btnCancelNew').classList.toggle('hidden', force);
  const first = !S.projects.length;
  $('#welcomeIntro').classList.toggle('hidden', !first);
  $('#newProjTitle').textContent = first ? 'Name your first project' : 'New project';
  $('#newProjName').value = '';
  const sel = $('#copyFrom');
  sel.innerHTML = '';
  sel.append(h('option', { value: '' }, 'Start fresh (defaults)'));
  for (const p of S.projects) sel.append(h('option', { value: p.id }, `Copy from "${p.name}"`));
  sel.value = (S.p && S.p.id) || (S.projects[0] && S.projects[0].id) || '';
  $('#copyFromRow').classList.toggle('hidden', !S.projects.length);
  setTimeout(() => $('#newProjName').focus(), 30);
}

async function createProject() {
  const name = $('#newProjName').value.trim() || 'Untitled';
  try {
    const p = await api('POST', '/api/projects', { name, copy_from: $('#copyFrom').value || null });
    $('#welcome').classList.add('hidden');
    await refreshProjects();
    await loadProject(p.id);
    if (!tourSeen(1)) setTimeout(() => startTour(1), 300);
  } catch (e) { fail(e); }
}

// ------------------------------------------------------------------ polling
async function poll() {
  if (!S.p) return;
  let st;
  try { st = await api('GET', `/api/projects/${S.p.id}/status`); } catch { return; }
  renderSpeech(st.speech);
  if (st.rev === S.rev) return;
  let fresh;
  try { fresh = await api('GET', `/api/projects/${S.p.id}`); } catch { return; }
  if (fresh.id !== S.p.id) return;
  S.rev = fresh.rev;
  const localById = Object.fromEntries(S.p.clips.map((c) => [c.id, c]));
  let needLayout = false, needSeq = false, inspectedChanged = false;
  S.p.clips = fresh.clips.map((sc) => {
    const lc = localById[sc.id];
    if (lc && (lc.rev || 0) >= (sc.rev || 0)) return lc;
    if (pendingClips[sc.id]) Object.assign(sc, pendingClips[sc.id]);
    if (!lc || JSON.stringify((lc.transcript || {}).words) !== JSON.stringify((sc.transcript || {}).words)) needLayout = true;
    if (!lc || lc.proxy !== sc.proxy || JSON.stringify(lc.trim) !== JSON.stringify(sc.trim)) needSeq = true;
    if (sc.id === S.sel.clip) inspectedChanged = true;
    return sc;
  });
  S.p.batches = fresh.batches;
  if (!S.sel.hook && clips('hook')[0]) { S.sel.hook = clips('hook')[0].id; needSeq = true; }
  if (!S.sel.body && clips('body')[0]) { S.sel.body = clips('body')[0].id; needSeq = true; }
  if (!S.sel.clip) S.sel.clip = S.sel.hook || S.sel.body;
  renderBin(); renderMatrixCount();
  setTimeout(maybeAutoTour, 600);
  if (needLayout) requestLayout();
  if (needSeq) buildSequence();
  if (inspectedChanged || S.tab === 'export') {
    if ($('#panel').contains(document.activeElement)) S.panelDirty = true; else renderPanel();
  }
}

// ------------------------------------------------------------------ captions layout
const requestLayout = debounce(async () => {
  if (!S.p) return;
  const edits = Object.fromEntries(S.p.clips.map((c) => [c.id, { trim: c.trim, pauses: c.pauses }]));
  try {
    const r = await api('POST', `/api/projects/${S.p.id}/layout`, { style: S.p.style, clips: edits });
    S.layout = r.captions;
    const changed = P.segs.some((sg) => sg.clip && JSON.stringify(r.keep[sg.clip.id]) !== JSON.stringify(S.keep[sg.clip.id]));
    S.keep = r.keep;
    S.capVer++;
    if (changed) buildSequence(); else drawTimeline();
    drawTrim();
    if (S.tab === 'clip' && S.pauseInfo) S.pauseInfo();
  } catch (e) { console.warn(e); }
}, 220);

// --- which source ranges of a clip play (trim + jump cuts); server is the source of truth
function piecesOf(c) {
  const tr = trimOf(c);
  const base = [[tr.in, Math.max(tr.in + 0.1, tr.out)]];
  if (!(c.pauses && c.pauses.enabled)) return base;
  const k = (S.keep[c.id] || base).map(([a, b]) => [Math.max(a, tr.in), Math.min(b, tr.out)]).filter(([a, b]) => b - a > 0.02);
  return k.length ? k : base;
}
function u2src(seg, u) {
  let acc = 0;
  for (const [a, b] of seg.pieces) { if (u < acc + (b - a)) return a + (u - acc); acc += b - a; }
  return seg.pieces[seg.pieces.length - 1][1];
}
function src2u(seg, t) {
  let acc = 0;
  for (const [a, b] of seg.pieces) { if (t < a) return acc; if (t < b) return acc + (t - a); acc += b - a; }
  return acc;
}

// ------------------------------------------------------------------ bin
function clipStatus(c) {
  if (c.status === 'processing') return h('span', {}, h('span', { class: 'spin' }), ' Preparing…');
  if (c.status === 'error') return h('span', { class: 'err' }, '⚠ ' + (c.error || 'Failed'));
  const tr = trimOf(c);
  const dur = `${(tr.out - tr.in).toFixed(1)}s`;
  if (c.tstatus === 'queued') return h('span', {}, dur, ' · captions queued');
  if (c.tstatus === 'running') return h('span', {}, dur, ' · ', h('span', { class: 'spin' }), ' transcribing');
  if (c.tstatus === 'error') return h('span', {}, dur, ' · ', h('span', { class: 'err' }, 'captions failed'));
  if (c.tstatus === 'none') return h('span', {}, dur, ' · no audio');
  if (c.tstatus === 'done') {
    const low = ((c.transcript || {}).words || []).filter((w) => w.p < 0.6 && !w.hide && w.s >= tr.in && w.s <= tr.out).length;
    return h('span', {}, dur, ' · ', low ? h('span', { class: 'warn' }, `${low} word${low > 1 ? 's' : ''} to check`) : h('span', { class: 'ok' }, '✓ captions'));
  }
  return h('span', {}, dur);
}

function renderBin() {
  for (const role of ['hook', 'body']) {
    const list = $(role === 'hook' ? '#hookList' : '#bodyList');
    list.innerHTML = '';
    const cs = clips(role);
    $(role === 'hook' ? '#hookCount' : '#bodyCount').textContent = cs.length;
    for (const c of cs) {
      const selected = S.sel[role] === c.id;
      list.append(h('div', {
        class: 'clip' + (selected ? ' sel' : '') + (S.sel.clip === c.id ? ' inspect' : ''), 'data-role': role,
        onclick: () => selectClip(c.id),
      },
      h('div', { class: 'thumb', style: c.thumb ? { backgroundImage: `url(${fileUrl(c.thumb)}?v=${c.rev})` } : {} }),
      h('div', { class: 'info' },
        h('div', { class: 'top' }, h('span', { class: 'lab' }, c.label), h('span', { class: 'nm' }, c.name)),
        h('div', { class: 'sub' }, clipStatus(c)))));
    }
    for (const u of S.uploads.filter((x) => x.role === role)) {
      list.append(h('div', { class: 'clip' },
        h('div', { class: 'thumb' }),
        h('div', { class: 'info' }, h('div', { class: 'nm' }, u.name), h('div', { class: 'sub' }, u.waiting ? 'Waiting…' : `Uploading ${Math.round(u.pct * 100)}%`)),
        h('div', { class: 'bar' }, h('i', { style: { width: `${u.pct * 100}%` } }))));
    }
  }
  const empty = !clips().length;
  $('#stageEmpty').classList.toggle('hidden', !empty && !!(S.sel.hook || S.sel.body));
}

function selectClip(id) {
  const c = clipById(id);
  if (!c) return;
  const changedCombo = S.sel[c.role] !== id;
  S.sel[c.role] = id;
  S.sel.clip = id;
  S.wordSel = null; S.textMode = false;
  if (S.tab !== 'clip') setTab('clip'); else renderPanel();
  renderBin();
  if (changedCombo) buildSequence();
  // jump to the start of the selected clip in the sequence
  const i = P.segs.findIndex((s) => s.clip && s.clip.id === id);
  if (i >= 0) seek(P.starts[i]);
}

async function uploadFiles(role, files) {
  const list = [...files].filter((f) => /^video\//.test(f.type) || /\.(mov|mp4|m4v|mkv|webm|mts|avi)$/i.test(f.name)).sort((a, b) => natSort(a.name, b.name));
  if (!list.length) { toast('Drop video files (mp4, mov…)', true); return; }
  const items = list.map((f) => ({ role, name: f.name, pct: 0, file: f, waiting: true }));
  S.uploads.push(...items);
  renderBin();
  // one global queue: files are numbered in the order they were added, even across drops
  const pid = S.p.id;
  uploadChain = uploadChain.then(() => runUploads(pid, role, items));
  return uploadChain;
}

let uploadChain = Promise.resolve();
async function runUploads(pid, role, items) {
  for (const u of items) {
    u.waiting = false;
    try {
      const c = await new Promise((resolve, reject) => {
        const fd = new FormData();
        fd.append('role', role); fd.append('file', u.file);
        const x = new XMLHttpRequest();
        x.open('POST', `/api/projects/${pid}/clips`);
        x.upload.onprogress = (e) => { if (e.lengthComputable) { u.pct = e.loaded / e.total; renderBin(); } };
        x.onload = () => { let d = {}; try { d = JSON.parse(x.responseText); } catch { /* */ } x.status < 300 ? resolve(d) : reject(new Error(d.detail || x.statusText)); };
        x.onerror = () => reject(new Error('Upload failed'));
        x.send(fd);
      });
      if (S.p.id === pid) { // if the user switched project meanwhile, the clip is still saved in its own
        if (!clipById(c.id)) S.p.clips.push(c);
        if (!S.sel[role]) { S.sel[role] = c.id; if (!S.sel.clip) S.sel.clip = c.id; buildSequence(); renderPanel(); }
      }
    } catch (e) { fail(e); }
    S.uploads.splice(S.uploads.indexOf(u), 1);
    renderBin(); renderMatrixCount();
  }
}

async function deleteClip(c) {
  if (!confirm(`Delete ${c.label} "${c.name}"? Its label won't be reused.`)) return;
  try { await api('DELETE', `/api/projects/${S.p.id}/clips/${c.id}`); } catch (e) { fail(e); return; }
  S.p.clips = S.p.clips.filter((x) => x.id !== c.id);
  if (S.sel[c.role] === c.id) S.sel[c.role] = (clips(c.role)[0] || {}).id || null;
  if (S.sel.clip === c.id) S.sel.clip = S.sel.hook || S.sel.body;
  renderAll();
}

// ------------------------------------------------------------------ player
const P = { segs: [], starts: [], total: 0, idx: 0, T: 0, playing: false, els: new Map(), imgT0: 0, actx: null, gains: new Map(), loop: true };
const music = new Audio();
music.loop = true;

function stageDims() {
  const wrap = $('#stageWrap');
  const { w, h: hh } = fmtDims();
  const aw = Math.max(80, wrap.clientWidth - 28), ah = Math.max(80, wrap.clientHeight - 28);
  const s = Math.min(aw / w, ah / hh);
  return { W: Math.round(w * s), H: Math.round(hh * s), scale: s, ow: w, oh: hh };
}

function layoutStage() {
  const d = stageDims();
  const st = $('#stage');
  st.style.width = d.W + 'px'; st.style.height = d.H + 'px';
  const bg = $('#bgCanvas');
  bg.width = Math.max(2, Math.round(d.W / 4)); bg.height = Math.max(2, Math.round(d.H / 4));
  P.dims = d;
  for (const s of P.segs) if (s.el) positionMedia(s);
  renderSafe();
  S.capVer++;
}

function positionMedia(seg) {
  // must match render._fit_chain
  const { W, H } = P.dims;
  const m = seg.clip ? seg.clip.meta : seg.meta;
  if (!m) return;
  const sw = m.width, sh = m.height;
  const crop = seg.crop || {};
  const zoom = Math.max(1, crop.zoom || 1), fx = crop.x ?? 0.5, fy = crop.y ?? 0.5;
  let fw, fh, x, y;
  if (seg.fit === 'blur') {
    const s = Math.min(W / sw, H / sh) * zoom;
    fw = sw * s; fh = sh * s; x = (W - fw) * fx; y = (H - fh) * fy;
  } else {
    const s = Math.max(W / sw, H / sh) * zoom;
    fw = Math.max(W, sw * s); fh = Math.max(H, sh * s); x = -(fw - W) * fx; y = -(fh - H) * fy;
  }
  Object.assign(seg.el.style, { left: x + 'px', top: y + 'px', width: fw + 'px', height: fh + 'px', objectFit: 'fill' });
}

function videoFor(key, src) {
  let v = P.els.get(key);
  if (v && v.dataset.src !== src) { v.remove(); P.els.delete(key); v = null; }
  if (!v) {
    v = h('video', { preload: 'auto', playsinline: true });
    v.dataset.src = src; v.src = src;
    $('#vids').append(v);
    P.els.set(key, v);
  }
  return v;
}

function clipGain(c) {
  const b = S.p.brand;
  let g = c.gain_db || 0;
  if (b.normalize && c.lufs != null) g += b.lufs_target - c.lufs;
  return db2gain(clamp(g, -24, 24));
}

function routeAudio(v, gain) {
  if (!P.actx) return;
  let node = P.gains.get(v);
  if (!node) {
    try {
      const src = P.actx.createMediaElementSource(v);
      node = P.actx.createGain();
      src.connect(node).connect(P.actx.destination);
      P.gains.set(v, node);
    } catch { return; }
  }
  node.gain.value = gain;
}

function buildSequence() {
  if (!S.p) return;
  const keepT = P.T;
  const segs = [];
  const fit = S.p.export.fit;
  for (const id of [S.sel.hook, S.sel.body]) {
    const c = clipById(id);
    if (!c || !c.proxy || !c.meta) continue;
    const pieces = piecesOf(c);
    segs.push({ kind: 'clip', clip: c, pieces, tin: pieces[0][0], tout: pieces[pieces.length - 1][1], crop: c.crop, fit,
      el: videoFor(c.id, fileUrl(c.proxy)) });
  }
  const ec = S.p.brand.endcard;
  if (segs.length && ec) {
    if (ec.kind === 'image') segs.push({ kind: 'image', src: fileUrl(ec.file), dur: S.p.brand.endcard_duration || 2.5, meta: ec.meta });
    else {
      const { w, h: hh } = fmtDims();
      const efit = Math.abs(ec.meta.width / ec.meta.height - w / hh) < 0.02 ? 'fill' : 'blur';
      segs.push({ kind: 'endvideo', meta: ec.meta, pieces: [[0, ec.meta.duration]], tin: 0, tout: ec.meta.duration, fit: efit, crop: {}, el: videoFor('endcard', fileUrl(ec.file)) });
    }
  }
  // drop video elements no longer used
  const used = new Set(segs.filter((s) => s.el).map((s) => s.el));
  for (const [k, v] of P.els) if (!used.has(v)) { v.pause(); v.remove(); P.els.delete(k); }
  P.segs = segs;
  P.starts = [];
  let t = 0;
  for (const s of segs) { P.starts.push(t); s.dur = s.kind === 'image' ? s.dur : s.pieces.reduce((acc, [a, b]) => acc + b - a, 0); t += s.dur; }
  P.total = t;
  layoutStage();
  const img = $('#endImg');
  const imgSeg = segs.find((s) => s.kind === 'image');
  if (imgSeg) {
    img.src = imgSeg.src;
    const { w, h: hh } = fmtDims();
    img.style.objectFit = Math.abs(imgSeg.meta.width / imgSeg.meta.height - w / hh) < 0.02 ? 'cover' : 'contain';
  }
  const m = S.p.brand.music;
  const msrc = m ? fileUrl(m.file) : '';
  if (music.dataset.src !== msrc) { music.dataset.src = msrc; if (msrc) music.src = msrc; else music.removeAttribute('src'); }
  seek(Math.min(keepT, Math.max(0, P.total - 0.05)));
  renderComboLabel();
  drawTimeline();
  $('#stageEmpty').classList.toggle('hidden', segs.length > 0);
}

function segAt(T) {
  for (let i = P.segs.length - 1; i >= 0; i--) if (T >= P.starts[i] - 1e-6) return i;
  return 0;
}

function showSeg(i) {
  P.segs.forEach((s, j) => { if (s.el) s.el.classList.toggle('on', j === i); });
  const s = P.segs[i];
  $('#endImg').style.display = s && s.kind === 'image' ? 'block' : 'none';
}

function seek(T) {
  if (!P.segs.length) { P.T = 0; return; }
  T = clamp(T, 0, Math.max(0, P.total - 0.001));
  const i = segAt(T);
  const prev = P.segs[P.idx];
  if (prev && prev.el && i !== P.idx) prev.el.pause();
  P.idx = i; P.T = T;
  const s = P.segs[i];
  if (s.el) {
    s.el.currentTime = u2src(s, T - P.starts[i]);
    if (P.playing) s.el.play().catch(() => {});
  } else P.imgT0 = performance.now() - (T - P.starts[i]) * 1000;
  // pre-roll the other segments to their in points
  P.segs.forEach((o, j) => { if (j !== i && o.el && Math.abs(o.el.currentTime - o.tin) > 0.05) o.el.currentTime = o.tin; });
  showSeg(i);
  if (P.playing && S.p.brand.music) music.currentTime = T % (music.duration || 1e9);
}

function play() {
  if (!P.segs.length) return;
  if (!P.actx) { try { P.actx = new (window.AudioContext || window.webkitAudioContext)(); } catch { /* */ } }
  if (P.actx && P.actx.state === 'suspended') P.actx.resume();
  if (P.T >= P.total - 0.05) seek(0);
  P.playing = true;
  for (const s of P.segs) if (s.el) routeAudio(s.el, s.clip ? clipGain(s.clip) : 1);
  const s = P.segs[P.idx];
  if (s.el) s.el.play().catch(() => {}); else P.imgT0 = performance.now() - (P.T - P.starts[P.idx]) * 1000;
  if (S.p.brand.music) {
    music.volume = clamp(db2gain(S.p.brand.music_volume) * (S.p.brand.music_duck ? 0.75 : 1), 0, 1);
    music.currentTime = P.T % (music.duration || 1e9);
    music.play().catch(() => {});
  }
  $('#btnPlay').innerHTML = '&#10073;&#10073;';
}

function pause() {
  P.playing = false;
  for (const s of P.segs) if (s.el) s.el.pause();
  music.pause();
  $('#btnPlay').innerHTML = '&#9654;';
}

function advance() {
  const cur = P.segs[P.idx];
  if (cur && cur.el) cur.el.pause();
  if (P.idx + 1 >= P.segs.length) {
    if (P.loop) { seek(0); return; }
    pause(); P.T = P.total; return;
  }
  P.idx++;
  P.T = P.starts[P.idx];
  const s = P.segs[P.idx];
  showSeg(P.idx);
  if (s.el) { if (Math.abs(s.el.currentTime - s.tin) > 0.04) s.el.currentTime = s.tin; s.el.play().catch(() => {}); } else P.imgT0 = performance.now();
}

function tick() {
  requestAnimationFrame(tick);
  if (!S.p || !P.segs.length || !P.dims) { renderOverlays(null); return; }
  const s = P.segs[P.idx];
  if (P.playing) {
    if (s.el) {
      const ct = s.el.currentTime;
      const pi = s.pieces.findIndex(([, b]) => ct < b - 0.017);
      if (pi === -1 || s.el.ended) advance();
      else if (ct < s.pieces[pi][0] - 0.03) s.el.currentTime = s.pieces[pi][0]; // jump over a cut pause
      else P.T = P.starts[P.idx] + clamp(src2u(s, ct), 0, s.dur);
    } else {
      P.T = P.starts[P.idx] + (performance.now() - P.imgT0) / 1000;
      if (P.T >= P.starts[P.idx] + s.dur) advance();
    }
  }
  renderOverlays(s);
  drawBg(s);
  $('#timeLabel').textContent = `${fmtT(P.T)} / ${fmtT(P.total)}`;
  drawTimeline(true);
  if (S.tab === 'clip') markNowWord();
}

function drawBg(s) {
  const cv = $('#bgCanvas');
  const ctx = cv.getContext('2d');
  if (!s || !s.el || s.fit !== 'blur' || s.el.readyState < 2) {
    if (cv.dataset.on) { ctx.clearRect(0, 0, cv.width, cv.height); delete cv.dataset.on; }
    return;
  }
  cv.dataset.on = '1';
  const v = s.el, sw = v.videoWidth, sh = v.videoHeight;
  if (!sw) return;
  const k = Math.max(cv.width / sw, cv.height / sh);
  ctx.filter = 'blur(8px) brightness(0.92)';
  ctx.drawImage(v, (cv.width - sw * k) / 2, (cv.height - sh * k) / 2, sw * k, sh * k);
  ctx.filter = 'none';
}

// --- overlays: captions, headline text, logo, progress bar
let capKey = '', chunkKey = '', ovKey = '', logoKey = null;
function renderOverlays(seg) {
  const cap = $('#capLayer'), ov = $('#ovLayer'), logo = $('#logoEl');
  if (!seg || !S.p) { cap.innerHTML = ''; ov.innerHTML = ''; logo.style.display = 'none'; return; }
  const { scale, W, H, ow, oh } = P.dims;
  const isClip = seg.kind === 'clip';
  const local = P.T - P.starts[P.idx];
  const t = isClip ? u2src(seg, local) : 0;

  // captions
  const st = S.p.style;
  let key = 'none';
  let chunk = null, ci = -1, ai = -1;
  if (isClip && st.enabled) {
    const chunks = S.layout[seg.clip.id] || [];
    for (let i = 0; i < chunks.length; i++) { if (t >= chunks[i].s && t < Math.min(chunks[i].e, seg.tout + 0.01)) { ci = i; chunk = chunks[i]; break; } }
    if (chunk) {
      const flat = chunk.lines.flat();
      if (st.highlight !== 'none') { ai = 0; flat.forEach((w, i) => { if (w.s <= t) ai = i; }); }
      key = `${seg.clip.id}:${ci}:${ai}:${S.capVer}:${S.fmt}:${W}`;
    }
  }
  if (key !== capKey) {
    capKey = key;
    if (!chunk) { cap.innerHTML = ''; chunkKey = ''; } else {
      const ck = `${seg.clip.id}:${ci}`;
      const anim = ck !== chunkKey ? st.animation : '';
      chunkKey = ck;
      cap.innerHTML = '';
      const el = captionEl(st, chunk, ai, scale, H, anim);
      cap.append(el);
      if (st.highlight === 'box') placeHlBox(el, st, scale);
    }
  }

  // headline overlays
  const ovs = isClip ? (seg.clip.overlays || []).filter((o) => (o.text || '').trim() && local >= (+o.start || 0) && local < ((+o.end || 0) > 0 ? +o.end : 1e9)) : [];
  const ok = ovs.map((o) => o.text + o.y).join('|') + ':' + S.capVer + ':' + W;
  if (ok !== ovKey) {
    ovKey = ok;
    ov.innerHTML = '';
    const os = S.p.overlay_style, f = fontOf(os.font);
    for (const o of ovs) {
      const pad = os.pad * scale;
      ov.append(h('div', { class: 'ov', style: {
        top: (o.y ?? 0.16) * H + 'px', maxWidth: (os.max_width || 0.84) * W + 'px', width: 'max-content',
        fontFamily: `'adf-${f.id}'`, fontSize: os.size * f.css_scale * scale + 'px', lineHeight: os.size * scale + 'px', color: os.color,
      } }, h('span', { style: { background: rgba(os.bg_color, os.bg_opacity), boxShadow: `0 0 0 ${pad}px ${rgba(os.bg_color, os.bg_opacity)}`, padding: `${boxExtra(f, os.size * scale)}px 0` } },
        h('span', { style: { position: 'relative', top: baselineShift(f) * os.size * scale + 'px' } }, os.uppercase ? o.text.toUpperCase() : o.text))));
    }
  }

  // logo
  const b = S.p.brand;
  const lk = isClip && b.logo ? `${b.logo.file}:${b.logo_pos}:${b.logo_size}:${b.logo_opacity}:${b.logo_margin}:${W}` : '';
  if (lk !== logoKey) {
    logoKey = lk;
    if (!lk) logo.style.display = 'none'; else {
      const src = fileUrl(b.logo.file);
      if (logo.dataset.src !== src) { logo.src = src; logo.dataset.src = src; }
      const m = b.logo_margin * Math.min(ow, oh) * scale;
      Object.assign(logo.style, { display: 'block', width: b.logo_size * W + 'px', opacity: b.logo_opacity,
        left: b.logo_pos.includes('l') ? m + 'px' : 'auto', right: b.logo_pos.includes('r') ? m + 'px' : 'auto',
        top: b.logo_pos.includes('t') ? m + 'px' : 'auto', bottom: b.logo_pos.includes('b') ? m + 'px' : 'auto' });
    }
  }

  // progress bar
  const pr = b.progress, track = $('#progTrack');
  if (pr.enabled) {
    track.style.display = 'block';
    track.style.height = Math.max(2, pr.height * scale) + 'px';
    track.style.top = pr.position === 'top' ? '0' : 'auto';
    track.style.bottom = pr.position === 'top' ? 'auto' : '0';
    const fill = $('#progFill');
    fill.style.background = pr.color;
    fill.style.width = (P.total ? (P.T / P.total) * 100 : 0) + '%';
  } else track.style.display = 'none';
}

// libass boxes are exactly one line (Fontsize) tall plus padding; a CSS inline background only covers
// the font's content area, whose height depends on the font and platform. Measure it and pad the rest.
const contentRatio = {};
function boxExtra(f, sizePx) {
  if (!(f.id in contentRatio)) {
    const sp = h('span', { style: { fontFamily: `'adf-${f.id}'`, fontSize: '100px', lineHeight: 'normal', position: 'absolute', visibility: 'hidden', whiteSpace: 'nowrap' } }, 'Hg');
    document.body.append(sp);
    const r = sp.getBoundingClientRect().height / 100;
    sp.remove();
    if (!document.fonts.check(`100px 'adf-${f.id}'`)) return Math.max(0, (sizePx - sizePx * f.css_scale * r) / 2);
    contentRatio[f.id] = r;
  }
  return Math.max(0, (sizePx - sizePx * f.css_scale * contentRatio[f.id]) / 2);
}

// Where the browser puts the baseline inside a line box differs per font from libass
// (baseline = winAscent share of the line). Returns the shift, as a fraction of Fontsize.
const baseDelta = {};
function baselineShift(f) {
  if (f.id in baseDelta) return baseDelta[f.id];
  const L = 200;
  const mark = h('span', { style: { display: 'inline-block', width: '1px', height: '0px' } });
  const box = h('div', { style: { position: 'absolute', visibility: 'hidden', fontFamily: `'adf-${f.id}'`, fontSize: L * f.css_scale + 'px', lineHeight: L + 'px', whiteSpace: 'nowrap', top: '0', left: '0' } }, 'H', mark);
  document.body.append(box);
  const d = (f.ascent_ratio * L - mark.offsetTop) / L;
  box.remove();
  if (document.fonts.check(`100px 'adf-${f.id}'`)) baseDelta[f.id] = d;
  return d;
}

function captionEl(st, chunk, ai, scale, H, anim) {
  const f = fontOf(st.font);
  const boxMode = st.highlight === 'box';
  const bg = st.bg && !boxMode;
  const style = {
    top: (st.pos[S.fmt] ?? 0.6) * H + 'px', fontFamily: `'adf-${f.id}'`,
    fontSize: st.size * f.css_scale * scale + 'px', lineHeight: st.size * scale + 'px', color: st.color,
  };
  if (!bg && st.outline > 0) style.webkitTextStroke = `${st.outline * 2 * scale}px ${st.outline_color}`;
  if (st.shadow > 0) style.filter = `drop-shadow(${st.shadow * scale}px ${st.shadow * scale}px 0 ${rgba(st.shadow_color, st.shadow_opacity)})`;
  const el = h('div', { class: 'cap' + (anim === 'pop' ? ' pop' : anim === 'fade' ? ' fade' : ''), style });
  let idx = 0;
  for (const line of chunk.lines) {
    const box = h('span', { class: 'lnbox' });
    if (bg) {
      const c = rgba(st.bg_color, st.bg_opacity), pad = st.bg_pad * scale;
      Object.assign(box.style, { background: c, boxShadow: `0 0 0 ${pad}px ${c}`, padding: `${boxExtra(f, st.size * scale)}px 0` });
    }
    const shift = baselineShift(f) * st.size * scale;
    line.forEach((w, j) => {
      if (j) box.append(' ');
      const sp = h('span', { style: { position: 'relative', top: shift + 'px' } }, w.t);
      if (idx === ai) {
        if (boxMode) { sp.className = 'hl'; sp.style.color = st.highlight_text; } else sp.style.color = st.highlight_color;
        if (st.word_pop && !boxMode) { sp.style.display = 'inline-block'; sp.style.transform = 'scale(1.12)'; }
      } else if (w.emph) sp.style.color = st.emphasis_color;
      box.append(sp);
      idx++;
    });
    el.append(h('div', { class: 'ln' }, box));
  }
  return el;
}

function placeHlBox(capEl, st, scale) {
  // same geometry as captions.box_metrics / _word_boxes
  const sp = capEl.querySelector('.hl');
  if (!sp) return;
  const f = fontOf(st.font), size = st.size * scale;
  const padX = size * 0.14 + st.outline * scale * 0.5, padY = size * 0.1;
  const below = size * 0.1 + (st.uppercase ? 0 : 0.2 * size * f.css_scale);
  const base = sp.closest('.ln').offsetTop + f.ascent_ratio * size;
  const top = base - f.cap_ratio * size - padY, hh = base + below - top;
  capEl.prepend(h('div', { class: 'hlbox', style: {
    left: sp.offsetLeft - padX + 'px', top: top + 'px', width: sp.offsetWidth + 2 * padX + 'px', height: hh + 'px',
    borderRadius: Math.min(size * 0.12, hh / 2) + 'px', background: st.highlight_color } }));
}

const SAFE = {
  reels: { top: 0.14, bottom: 0.35, left: 0.06, right: 0.06, label: 'Reels UI' },
  tiktok: { top: 0.08, bottom: 0.25, left: 0.06, right: 0.14, label: 'TikTok UI' },
  stories: { top: 0.14, bottom: 0.2, left: 0.06, right: 0.06, label: 'Stories UI' },
};
function renderSafe() {
  const L = $('#safeLayer');
  L.innerHTML = '';
  const z = SAFE[S.safe];
  if (!z || S.fmt !== '9x16' || !P.dims) return;
  const { W, H } = P.dims;
  const box = (l, t, w, hh, lab) => L.append(h('div', { class: 'safe', style: { left: l + 'px', top: t + 'px', width: w + 'px', height: hh + 'px' } }, lab ? h('span', { class: 'safe-label' }, lab) : null));
  box(0, 0, W, z.top * H, z.label + ' (approx.)');
  box(0, H * (1 - z.bottom), W, z.bottom * H);
  box(0, z.top * H, z.left * W, H * (1 - z.top - z.bottom));
  box(W * (1 - z.right), z.top * H, z.right * W, H * (1 - z.top - z.bottom));
}

function renderComboLabel() {
  const hk = clipById(S.sel.hook), bd = clipById(S.sel.body);
  const el = $('#comboLabel');
  el.innerHTML = '';
  if (hk) el.append(h('span', { class: 'h' }, hk.label));
  if (hk && bd) el.append(' × ');
  if (bd) el.append(h('span', { class: 'b' }, bd.label));
  if (P.total) el.append(h('span', { class: 'muted' }, `  ·  ${P.total.toFixed(1)}s`));
}

function renderFmtTabs() {
  const el = $('#fmtTabs');
  el.innerHTML = '';
  for (const f of Object.keys(S.meta.formats)) {
    el.append(h('button', { class: f === S.fmt ? 'on' : '', title: FMT_USE[f], onclick: () => { S.fmt = f; localStorage.setItem('adf.fmt', f); renderFmtTabs(); buildSequence(); if (S.tab === 'captions') renderPanel(); } }, FMT_LABEL[f]));
  }
}

// --- timeline
async function ensureEnv(c) {
  if (S.env[c.id] || c.status !== 'ready') return;
  S.env[c.id] = { env: [], env_fps: 100, loading: true };
  try { S.env[c.id] = await api('GET', `/api/projects/${S.p.id}/clips/${c.id}/envelope`); drawTimeline(); drawTrim(); } catch { delete S.env[c.id]; }
}

let tlLast = '';
function drawTimeline(fromTick = false) {
  const cv = $('#tl');
  if (!cv) return;
  const dpr = window.devicePixelRatio || 1;
  const w = Math.round(cv.clientWidth * dpr), hh = Math.round(cv.clientHeight * dpr);
  const key = `${w}:${hh}:${P.T.toFixed(3)}:${P.total}:${S.capVer}:${P.segs.length}`;
  if (fromTick && key === tlLast) return;
  tlLast = key;
  if (cv.width !== w) cv.width = w;
  if (cv.height !== hh) cv.height = hh;
  const ctx = cv.getContext('2d');
  ctx.clearRect(0, 0, w, hh);
  if (!P.total) return;
  const X = (t) => (t / P.total) * w;
  P.segs.forEach((s, i) => {
    const x0 = X(P.starts[i]), x1 = X(P.starts[i] + s.dur);
    const col = s.kind === 'clip' ? (s.clip.role === 'hook' ? [245, 158, 11] : [34, 211, 238]) : [139, 92, 246];
    ctx.fillStyle = `rgba(${col},.13)`;
    ctx.fillRect(x0, 0, x1 - x0, hh);
    if (s.kind === 'clip') {
      const e = S.env[s.clip.id];
      if (!e) ensureEnv(s.clip);
      else if (e.env.length) {
        ctx.fillStyle = `rgba(${col},.55)`;
        const mid = hh * 0.58, amp = hh * 0.34;
        for (let x = Math.floor(x0); x < x1; x += dpr) {
          const ta = u2src(s, ((x - x0) / (x1 - x0)) * s.dur), tb = u2src(s, ((x + dpr - x0) / (x1 - x0)) * s.dur);
          let m = 0;
          for (let k = Math.floor(ta * e.env_fps); k <= Math.ceil(tb * e.env_fps) && k < e.env.length; k++) m = Math.max(m, e.env[k] || 0);
          const a = Math.sqrt(m) * amp;
          ctx.fillRect(x, mid - a, dpr, a * 2 || 1);
        }
      }
      const chunks = S.layout[s.clip.id] || [];
      ctx.fillStyle = 'rgba(255,255,255,.35)';
      for (const ch of chunks) for (const ln of ch.lines) for (const wd of ln) {
        if (wd.s < s.tin || wd.s > s.tout) continue;
        ctx.fillRect(x0 + (src2u(s, wd.s) / s.dur) * (x1 - x0), hh - 5 * dpr, dpr, 4 * dpr);
      }
    }
    if (s.pieces && s.pieces.length > 1) {
      ctx.fillStyle = 'rgba(255,255,255,.55)';
      let acc = 0;
      for (const [a, b] of s.pieces.slice(0, -1)) { acc += b - a; ctx.fillRect(x0 + (acc / s.dur) * (x1 - x0) - dpr / 2, hh * 0.3, dpr, hh * 0.56); }
    }
    ctx.fillStyle = `rgb(${col})`;
    ctx.font = `600 ${11 * dpr}px -apple-system, Segoe UI, sans-serif`;
    const label = s.kind === 'clip' ? `${s.clip.label}  ${s.clip.name}` : 'END CARD';
    ctx.save(); ctx.beginPath(); ctx.rect(x0, 0, x1 - x0 - 4, hh); ctx.clip();
    ctx.fillText(label, x0 + 6 * dpr, 14 * dpr);
    ctx.restore();
    if (i) { ctx.fillStyle = '#0d0e12'; ctx.fillRect(x0 - dpr, 0, 2 * dpr, hh); }
  });
  const px = X(P.T);
  ctx.fillStyle = '#fff';
  ctx.fillRect(px - dpr / 2, 0, dpr * 1.5, hh);
}

function bindTimeline() {
  const cv = $('#tl');
  let down = false;
  const go = (e) => { const r = cv.getBoundingClientRect(); seek(((e.clientX - r.left) / r.width) * P.total); };
  cv.addEventListener('pointerdown', (e) => { down = true; cv.setPointerCapture(e.pointerId); go(e); });
  cv.addEventListener('pointermove', (e) => { if (down) go(e); });
  cv.addEventListener('pointerup', () => { down = false; });
}

// ------------------------------------------------------------------ inspector widgets
function field(label, ctrl, col = false) { return h('div', { class: 'field' + (col ? ' col' : '') }, h('label', {}, label), ctrl); }
function slider(label, val, min, max, step, onInput, fmt = (v) => v) {
  const out = h('output', {}, fmt(val));
  const inp = h('input', { type: 'range', min, max, step, value: val, oninput: (e) => { const v = +e.target.value; out.textContent = fmt(v); onInput(v); } });
  return field(label, h('div', { class: 'slider' }, inp, out));
}
function colorIn(label, val, onInput) {
  return h('label', { class: 'color' }, h('input', { type: 'color', value: val, oninput: (e) => onInput(e.target.value) }), label);
}
function toggle(label, val, onChange) {
  return h('label', { class: 'toggle' }, h('input', { type: 'checkbox', checked: !!val, onchange: (e) => onChange(e.target.checked) }), label);
}
function segmented(opts, val, onChange) {
  const el = h('div', { class: 'seg full' });
  for (const [v, l] of opts) {
    el.append(h('button', { class: v === val ? 'on' : '', onclick: () => { $$('button', el).forEach((b) => b.classList.remove('on')); el.children[opts.findIndex((o) => o[0] === v)].classList.add('on'); onChange(v); } }, l));
  }
  return el;
}
function selectIn(opts, val, onChange) {
  const s = h('select', { onchange: (e) => onChange(e.target.value) });
  for (const [v, l] of opts) s.append(h('option', { value: v, selected: v === val }, l));
  return s;
}
const grp = (title, ...kids) => h('div', { class: 'grp' }, h('h4', {}, title), ...kids);

function setTab(t) {
  S.tab = t;
  $$('#tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
  renderPanel();
}

function renderPanel() {
  const panel = $('#panel');
  const scroll = panel.scrollTop;
  panel.innerHTML = '';
  panel.className = 'panel';
  S.panelDirty = false;
  if (!S.p) return;
  const fn = { clip: panelClip, captions: panelCaptions, brand: panelBrand, export: panelExport }[S.tab];
  panel.append(...[].concat(fn()));
  panel.scrollTop = scroll;
}

// ------------------------------------------------------------------ Clip tab
function panelClip() {
  const c = clipById(S.sel.clip);
  if (!c) return [h('p', { class: 'muted', style: { marginTop: '16px' } }, 'Select a hook or body on the left.')];
  const out = [];
  out.push(h('div', { class: 'clip-head' },
    h('span', { class: 'badge ' + c.role }, c.label),
    h('input', { type: 'text', value: c.name, title: 'Clip name (shows in the manifest)', oninput: (e) => { c.name = e.target.value; saveClip(c.id, { name: c.name }); renderBin(); } }),
    h('button', { class: 'btn ghost danger sm', title: 'Delete clip', onclick: () => deleteClip(c) }, 'Delete')));
  if (c.status === 'processing') out.push(h('div', { class: 'status-line' }, h('span', { class: 'spin' }), ' Preparing preview & analysing audio…'));
  if (c.status === 'error') out.push(h('div', { class: 'status-line err' }, c.error || 'Could not process this file'));
  if (c.status !== 'ready') return out;

  // trim
  const tr = trimOf(c), dur = c.meta.duration;
  const inIn = h('input', { type: 'number', step: 0.01, min: 0, max: dur, value: tr.in.toFixed(2) });
  const outIn = h('input', { type: 'number', step: 0.01, min: 0, max: dur, value: tr.out.toFixed(2) });
  const lenEl = h('div', { class: 'mono', style: { paddingTop: '6px' } }, `${(tr.out - tr.in).toFixed(2)}s`);
  const applyNums = () => setTrim(c, +inIn.value, +outIn.value);
  inIn.onchange = applyNums; outIn.onchange = applyNums;
  S.trimInputs = { inIn, outIn, lenEl };
  out.push(grp('Trim',
    h('canvas', { id: 'trimCanvas' }),
    h('div', { class: 'trim-nums' },
      h('div', {}, h('label', {}, 'In (s)'), inIn), h('div', {}, h('label', {}, 'Out (s)'), outIn), h('div', {}, h('label', {}, 'Length'), lenEl)),
    h('div', { class: 'btn-row' },
      h('button', { class: 'btn sm', onclick: () => setInOut('in') }, 'Set in (I)'),
      h('button', { class: 'btn sm', onclick: () => setInOut('out') }, 'Set out (O)'),
      h('button', { class: 'btn sm', title: 'Cut silence at the start and end', onclick: () => autoTrim(c) }, 'Auto-tighten'),
      h('button', { class: 'btn sm ghost', onclick: () => setTrim(c, 0, dur) }, 'Reset')),
    pauseControls(c)));
  setTimeout(() => { bindTrimCanvas(c); drawTrim(); ensureEnv(c); }, 0);

  // framing
  const crop = c.crop || { zoom: 1, x: 0.5, y: 0.5 };
  const setCrop = (k, v) => { c.crop = { ...crop, ...(c.crop || {}), [k]: v }; saveClip(c.id, { crop: c.crop }); const s = P.segs.find((x) => x.clip === c); if (s) { s.crop = c.crop; positionMedia(s); } };
  out.push(grp('Framing',
    h('p', { class: 'hint' }, `Source ${c.meta.width}×${c.meta.height}${c.meta.hdr ? ' · HDR (auto tone-mapped)' : ''}. Pan to keep the face in frame in every format.`),
    slider('Zoom', crop.zoom ?? 1, 1, 2.5, 0.01, (v) => setCrop('zoom', v), (v) => v.toFixed(2) + '×'),
    slider('Pan X', crop.x ?? 0.5, 0, 1, 0.01, (v) => setCrop('x', v), (v) => Math.round(v * 100) + '%'),
    slider('Pan Y', crop.y ?? 0.5, 0, 1, 0.01, (v) => setCrop('y', v), (v) => Math.round(v * 100) + '%')));

  // audio
  out.push(grp('Audio',
    h('p', { class: 'hint' }, c.lufs != null ? `Measured ${c.lufs.toFixed(1)} LUFS → normalised to ${S.p.brand.lufs_target} LUFS so every hook and body plays at the same volume.` : 'No audio measured.'),
    slider('Volume trim', c.gain_db || 0, -12, 12, 0.5, (v) => { c.gain_db = v; saveClip(c.id, { gain_db: v }); const s = P.segs.find((x) => x.clip === c); if (s && s.el) routeAudio(s.el, clipGain(c)); }, (v) => (v > 0 ? '+' : '') + v + ' dB')));

  // overlays
  const ovWrap = h('div', {});
  const renderOvs = () => {
    ovWrap.innerHTML = '';
    (c.overlays || []).forEach((o, i) => {
      const upd = (k, v) => { o[k] = v; saveClip(c.id, { overlays: c.overlays }); ovKey = ''; };
      ovWrap.append(h('div', { class: 'ov-item' },
        h('textarea', { rows: 2, placeholder: 'e.g. POV: you finally fixed your ads', oninput: (e) => upd('text', e.target.value) }, o.text || ''),
        h('div', { class: 'ov-grid' },
          h('div', {}, h('label', {}, 'From (s)'), h('input', { type: 'number', step: 0.1, min: 0, value: o.start || 0, onchange: (e) => upd('start', +e.target.value) })),
          h('div', {}, h('label', {}, 'To (0 = end)'), h('input', { type: 'number', step: 0.1, min: 0, value: o.end || 0, onchange: (e) => upd('end', +e.target.value) })),
          h('div', {}, h('label', {}, 'Height'), h('input', { type: 'range', min: 0.03, max: 0.9, step: 0.01, value: o.y ?? 0.16, oninput: (e) => upd('y', +e.target.value) })),
          h('button', { class: 'btn sm ghost danger', onclick: () => { c.overlays.splice(i, 1); saveClip(c.id, { overlays: c.overlays }); ovKey = ''; renderOvs(); } }, '✕')),
        c.transcript ? h('button', { class: 'btn sm ghost', style: { marginTop: '6px' }, title: 'Fill with the first sentence that is spoken', onclick: () => { upd('text', firstLine(c)); renderOvs(); } }, 'Use spoken first line') : null));
    });
  };
  renderOvs();
  out.push(grp('Text overlay',
    h('p', { class: 'hint' }, c.role === 'hook' ? 'A text hook on screen during the spoken hook boosts thumb-stop for sound-off viewers.' : 'Use for a CTA line near the end, e.g. "Tap Learn More".'),
    ovWrap,
    h('button', { class: 'btn sm', onclick: () => { c.overlays = [...(c.overlays || []), { text: '', start: 0, end: 0, y: c.role === 'hook' ? 0.16 : 0.2 }]; saveClip(c.id, { overlays: c.overlays }); renderOvs(); } }, '+ Add text')));

  out.push(transcriptGroup(c));
  return out;
}

function firstLine(c) {
  const tr = trimOf(c);
  const ws = ((c.transcript || {}).words || []).filter((w) => !w.hide && w.s >= tr.in - 0.05 && w.s <= tr.out);
  const out = [];
  for (const w of ws) { out.push(w.w); if (/[.!?]$/.test(w.w) || out.length >= 9) break; }
  return out.join(' ').replace(/[.,]$/, '');
}

function pauseControls(c) {
  const pz = () => c.pauses || { enabled: false, max: 0.4 };
  const info = h('span', { class: 'muted', style: { fontSize: '11.5px' } });
  S.pauseInfo = () => {
    if (!pz().enabled) { info.textContent = ''; return; }
    const tr = trimOf(c), pcs = piecesOf(c);
    const cut = tr.out - tr.in - pcs.reduce((a, [x, y]) => a + y - x, 0);
    info.textContent = cut > 0.05 ? `Cuts ${cut.toFixed(1)}s of dead air (${pcs.length - 1} jump cut${pcs.length > 2 ? 's' : ''})` : 'No pauses that long in this clip';
  };
  const set = (patch) => { c.pauses = { ...pz(), ...patch }; saveClip(c.id, { pauses: c.pauses }); requestLayout(); };
  const wrap = h('div', { style: { marginTop: '12px' } },
    toggle('Cut pauses inside the clip (jump cuts)', pz().enabled, (v) => { set({ enabled: v }); renderPanel(); }),
    pz().enabled ? h('div', {},
      slider('Longer than', pz().max, 0.2, 1.5, 0.05, (v) => set({ max: v }), (v) => v.toFixed(2) + 's'),
      h('div', { class: 'row between' }, info,
        h('button', { class: 'btn sm', title: 'Use this setting on every hook and body', onclick: () => {
          for (const x of S.p.clips) { x.pauses = { ...pz() }; saveClip(x.id, { pauses: x.pauses }); }
          requestLayout(); renderBin(); toast(`Pause cutting set on all ${S.p.clips.length} clips`);
        } }, 'Apply to all clips'))) : null);
  setTimeout(() => S.pauseInfo && S.pauseInfo(), 0);
  return wrap;
}

function transcriptGroup(c) {
  const g = h('div', { class: 'grp' });
  const words = (c.transcript || {}).words || [];
  const head = h('h4', {}, 'Captions transcript',
    h('span', { class: 'row' },
      c.transcript ? h('button', { class: 'btn sm', onclick: () => { S.textMode = !S.textMode; S.wordSel = null; renderPanel(); } }, S.textMode ? 'Word view' : 'Edit as text') : null,
      h('button', { class: 'btn sm', onclick: () => retranscribe(c) }, c.transcript ? 'Redo' : 'Transcribe')));
  g.append(head);
  if (c.tstatus === 'queued' || c.tstatus === 'running') {
    g.append(h('div', { class: 'status-line' }, h('span', { class: 'spin' }), c.tstatus === 'queued' ? ' Waiting for transcription…' : ' Transcribing (the first run downloads the speech model)…'));
    return g;
  }
  if (c.tstatus === 'error') g.append(h('div', { class: 'status-line err' }, 'Transcription failed: ' + (c.terror || '')));
  if (c.tstatus === 'none') { g.append(h('p', { class: 'hint' }, 'This clip has no audio track, so there is nothing to caption.')); return g; }
  if (!c.transcript) return g;
  if (S.textMode) {
    const ta = h('textarea', { rows: 8 }, words.map((w) => w.w).join(' '));
    g.append(h('p', { class: 'hint' }, 'Fix wording freely; timing is kept for unchanged words and re-spread for edited ones.'), ta,
      h('div', { class: 'row end' }, h('button', { class: 'btn primary sm', onclick: async () => {
        try {
          const nc = await api('POST', `/api/projects/${S.p.id}/clips/${c.id}/realign`, { text: ta.value });
          markDirty();
          Object.assign(c, nc); S.textMode = false; requestLayout(); renderPanel(); renderBin();
        } catch (e) { fail(e); }
      } }, 'Apply')));
    return g;
  }
  const low = words.filter((w) => w.p < 0.6).length;
  g.append(h('p', { class: 'hint' }, 'Click a word to jump to it and edit it. ', low ? h('span', { style: { color: 'var(--warn)' } }, `${low} low-confidence word${low > 1 ? 's' : ''} underlined. `) : '', 'Mark key words as ★ to colour them.'));
  const tr = trimOf(c);
  if (S.wordSel != null && words[S.wordSel]) {
    const w = words[S.wordSel];
    const inp = h('input', { type: 'text', value: w.w });
    const commit = () => {
      const parts = inp.value.trim().split(/\s+/).filter(Boolean);
      if (!parts.length) return;
      const span = (w.e - w.s) / parts.length;
      const repl = parts.map((t, k) => ({ ...w, w: t, p: 1, s: +(w.s + k * span).toFixed(3), e: +(w.s + (k + 1) * span).toFixed(3) }));
      words.splice(S.wordSel, 1, ...repl);
      saveClip(c.id, { words }); renderPanel(); renderBin();
    };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') { S.wordSel = null; renderPanel(); } });
    g.append(h('div', { class: 'word-edit' }, inp,
      h('button', { class: 'btn sm', onclick: commit }, 'Save'),
      h('button', { class: 'btn sm' + (w.emph ? ' primary' : ''), title: 'Emphasis colour', onclick: () => { w.emph = !w.emph; saveClip(c.id, { words }); renderPanel(); } }, '★'),
      h('button', { class: 'btn sm', title: 'Hide from captions (still audible)', onclick: () => { w.hide = !w.hide; saveClip(c.id, { words }); renderPanel(); renderBin(); } }, w.hide ? 'Show' : 'Hide')));
    setTimeout(() => inp.focus(), 0);
  }
  const box = h('div', { class: 'words', id: 'wordBox' });
  words.forEach((w, i) => {
    const cls = ['w'];
    if (w.p < 0.6) cls.push('low');
    if (w.emph) cls.push('emph');
    if (w.hide) cls.push('hide');
    if (w.e < tr.in || w.s > tr.out) cls.push('out');
    if (i === S.wordSel) cls.push('sel');
    box.append(h('span', { class: cls.join(' '), 'data-i': i, title: `${w.s.toFixed(2)}s`, onclick: () => {
      S.wordSel = i; renderPanel();
      const si = P.segs.findIndex((s) => s.clip === c);
      if (si >= 0) seek(P.starts[si] + clamp(src2u(P.segs[si], w.s), 0, P.segs[si].dur - 0.01));
    } }, w.w));
  });
  g.append(box);
  return g;
}

let nowWordKey = '';
function markNowWord() {
  const box = $('#wordBox');
  if (!box) return;
  const s = P.segs[P.idx];
  let idx = -1;
  if (s && s.clip && s.clip.id === S.sel.clip) {
    const t = u2src(s, P.T - P.starts[P.idx]);
    const words = (s.clip.transcript || {}).words || [];
    for (let i = 0; i < words.length; i++) if (words[i].s <= t) idx = i;
  }
  const k = `${S.sel.clip}:${idx}`;
  if (k === nowWordKey) return;
  nowWordKey = k;
  $$('.w.now', box).forEach((e) => e.classList.remove('now'));
  const el = box.querySelector(`[data-i="${idx}"]`);
  if (el) el.classList.add('now');
}

async function retranscribe(c) {
  if (c.transcript && !confirm('Re-run speech recognition? Your caption edits for this clip will be replaced.')) return;
  try { Object.assign(c, await api('POST', `/api/projects/${S.p.id}/clips/${c.id}/transcribe`)); renderPanel(); renderBin(); } catch (e) { fail(e); }
}

function setTrim(c, a, b) {
  const dur = c.meta.duration;
  a = clamp(+a || 0, 0, dur - 0.2); b = clamp(+b || dur, a + 0.2, dur);
  c.trim = { in: +a.toFixed(3), out: +b.toFixed(3) };
  saveClip(c.id, { trim: c.trim });
  const ti = S.trimInputs;
  if (ti) { ti.inIn.value = c.trim.in.toFixed(2); ti.outIn.value = c.trim.out.toFixed(2); ti.lenEl.textContent = `${(c.trim.out - c.trim.in).toFixed(2)}s`; }
  drawTrim();
  renderBin();
  rebuildKeepingClip(c);
  if (c.pauses && c.pauses.enabled) requestLayout();
}

function rebuildKeepingClip(c, at = 'in') {
  const wasPlaying = P.playing;
  pause();
  buildSequence();
  const i = P.segs.findIndex((s) => s.clip === c);
  if (i >= 0) seek(at === 'out' ? P.starts[i] + P.segs[i].dur - 0.5 : P.starts[i]);
  if (wasPlaying) play();
}

function setInOut(which) {
  const s = P.segs[P.idx];
  if (!s || !s.clip) return;
  const t = u2src(s, P.T - P.starts[P.idx]);
  const tr = trimOf(s.clip);
  if (which === 'in') setTrim(s.clip, t, tr.out); else setTrim(s.clip, tr.in, t);
  toast(`${s.clip.label} ${which} point set to ${t.toFixed(2)}s`);
}

async function autoTrim(c) {
  try {
    const nc = await api('POST', `/api/projects/${S.p.id}/clips/${c.id}/autotrim`);
    markDirty();
    c.trim = nc.trim; c.rev = nc.rev;
    renderPanel(); renderBin(); rebuildKeepingClip(c);
    if (c.pauses && c.pauses.enabled) requestLayout();
  } catch (e) { fail(e); }
}

function drawTrim() {
  const cv = $('#trimCanvas');
  const c = clipById(S.sel.clip);
  if (!cv || !c || !c.meta) return;
  const dpr = window.devicePixelRatio || 1;
  cv.width = Math.round(cv.clientWidth * dpr); cv.height = Math.round(cv.clientHeight * dpr);
  const ctx = cv.getContext('2d'), w = cv.width, hh = cv.height, dur = c.meta.duration;
  const X = (t) => (t / dur) * w;
  const e = S.env[c.id];
  const col = c.role === 'hook' ? '245,158,11' : '34,211,238';
  if (e && e.env.length) {
    ctx.fillStyle = `rgba(${col},.6)`;
    for (let x = 0; x < w; x += dpr) {
      let m = 0;
      const a = Math.floor((x / w) * dur * e.env_fps), b = Math.ceil(((x + dpr) / w) * dur * e.env_fps);
      for (let k = a; k <= b && k < e.env.length; k++) m = Math.max(m, e.env[k]);
      const amp = Math.sqrt(m) * hh * 0.42;
      ctx.fillRect(x, hh / 2 - amp, dpr, amp * 2 || 1);
    }
  }
  ctx.fillStyle = 'rgba(255,255,255,.4)';
  for (const wd of (c.transcript || {}).words || []) ctx.fillRect(X(wd.s), hh - 4 * dpr, dpr, 3 * dpr);
  const tr = trimOf(c);
  ctx.fillStyle = 'rgba(13,14,18,.72)';
  ctx.fillRect(0, 0, X(tr.in), hh);
  ctx.fillRect(X(tr.out), 0, w - X(tr.out), hh);
  const pcs = piecesOf(c);
  ctx.fillStyle = 'rgba(248,113,113,.35)';
  for (let i = 0; i + 1 < pcs.length; i++) ctx.fillRect(X(pcs[i][1]), 0, X(pcs[i + 1][0]) - X(pcs[i][1]), hh);
  ctx.fillStyle = '#a78bfa';
  ctx.fillRect(X(tr.in) - dpr, 0, 3 * dpr, hh);
  ctx.fillRect(X(tr.out) - 2 * dpr, 0, 3 * dpr, hh);
}

function bindTrimCanvas(c) {
  const cv = $('#trimCanvas');
  if (!cv) return;
  let drag = null;
  const tAt = (e) => { const r = cv.getBoundingClientRect(); return clamp(((e.clientX - r.left) / r.width) * c.meta.duration, 0, c.meta.duration); };
  cv.addEventListener('pointerdown', (e) => {
    const t = tAt(e), tr = trimOf(c), r = cv.getBoundingClientRect();
    const px = (x) => (x / c.meta.duration) * r.width;
    const dIn = Math.abs(px(t) - px(tr.in)), dOut = Math.abs(px(t) - px(tr.out));
    drag = dIn < 10 || dOut < 10 ? (dIn <= dOut ? 'in' : 'out') : (t < tr.in ? 'in' : t > tr.out ? 'out' : null);
    cv.setPointerCapture(e.pointerId);
    if (!drag) {
      const i = P.segs.findIndex((s) => s.clip === c);
      if (i >= 0) seek(P.starts[i] + src2u(P.segs[i], t));
    } else move(e);
  });
  const move = (e) => {
    if (!drag) return;
    const t = tAt(e), tr = trimOf(c);
    c.trim = drag === 'in' ? { in: clamp(t, 0, tr.out - 0.2), out: tr.out } : { in: tr.in, out: clamp(t, tr.in + 0.2, c.meta.duration) };
    const ti = S.trimInputs;
    if (ti) { ti.inIn.value = c.trim.in.toFixed(2); ti.outIn.value = c.trim.out.toFixed(2); ti.lenEl.textContent = `${(c.trim.out - c.trim.in).toFixed(2)}s`; }
    drawTrim();
  };
  cv.addEventListener('pointermove', move);
  cv.addEventListener('pointerup', () => { if (drag) { const d = drag; drag = null; setTrim(c, c.trim.in, c.trim.out); rebuildKeepingClip(c, d); } });
}

// ------------------------------------------------------------------ Captions tab
const LAYOUT_KEYS = new Set(['words', 'max_chars', 'lines', 'uppercase', 'strip_punct', 'remove_fillers', 'replacements']);
function setStyle(k, v) {
  S.p.style[k] = v;
  S.capVer++;
  saveProject('style');
  if (LAYOUT_KEYS.has(k)) requestLayout();
}

function presetCard(id, ps) {
  const f = fontOf(ps.font);
  const pv = h('span', { class: 'pv', style: { fontFamily: `'adf-${f.id}'`, fontSize: Math.min(26, ps.size * f.css_scale * 0.2) + 'px', color: ps.color } });
  if (!ps.bg && ps.outline) pv.style.webkitTextStroke = `${Math.max(1.5, ps.outline * 0.35)}px ${ps.outline_color}`;
  const words = ps.words === 1 ? ['WIN'] : ['THIS', 'WORKS'];
  words.forEach((w, i) => {
    const t = ps.uppercase ? w : w[0] + w.slice(1).toLowerCase();
    const sp = h('span', {}, (i ? ' ' : '') + t);
    if (i === words.length - 1 && ps.highlight === 'color') sp.style.color = ps.highlight_color;
    if (i === words.length - 1 && ps.highlight === 'box') Object.assign(sp.style, { background: ps.highlight_color, color: ps.highlight_text, padding: '0 3px', borderRadius: '3px', webkitTextStroke: '0' });
    pv.append(sp);
  });
  if (ps.bg) Object.assign(pv.style, { background: rgba(ps.bg_color, ps.bg_opacity), padding: '2px 6px' });
  return h('button', { class: 'preset' + (S.p.style.preset === id ? ' on' : ''), onclick: () => {
    const keep = { pos: S.p.style.pos, replacements: S.p.style.replacements, enabled: true };
    S.p.style = { ...JSON.parse(JSON.stringify(ps)), ...keep, preset: id };
    delete S.p.style.label;
    S.capVer++; saveProject('style'); requestLayout(); renderPanel();
  } }, pv, h('span', { class: 'pn' }, ps.label));
}

function panelCaptions() {
  const st = S.p.style;
  const out = [];
  const presets = h('div', { class: 'presets' });
  for (const [id, ps] of Object.entries(S.meta.presets)) presets.append(presetCard(id, ps));
  out.push(grp('Style', toggle('Burn captions into the ads', st.enabled, (v) => { setStyle('enabled', v); }), presets));

  const fonts = S.meta.fonts.map((f) => [f.id, f.label]);
  out.push(grp('Text',
    field('Font', selectIn(fonts, st.font, (v) => { setStyle('font', v); })),
    slider('Size', st.size, 40, 240, 1, (v) => setStyle('size', v)),
    slider('Position', st.pos[S.fmt] ?? 0.6, 0.1, 0.92, 0.005, (v) => { st.pos = { ...st.pos, [S.fmt]: v }; setStyle('pos', st.pos); }, (v) => Math.round(v * 100) + '%'),
    h('p', { class: 'hint' }, `Position is saved per format (now editing ${FMT_LABEL[S.fmt]}). Keep captions out of the red safe zones.`),
    slider('Words / caption', st.words, 1, 8, 1, (v) => setStyle('words', v)),
    slider('Max chars / line', st.max_chars, 6, 32, 1, (v) => setStyle('max_chars', v)),
    field('Lines', segmented([[1, '1 line'], [2, 'Up to 2']], st.lines, (v) => setStyle('lines', v))),
    toggle('UPPERCASE', st.uppercase, (v) => setStyle('uppercase', v))));

  const colors = h('div', { class: 'colors' },
    colorIn('Text', st.color, (v) => setStyle('color', v)),
    colorIn('Outline', st.outline_color, (v) => setStyle('outline_color', v)),
    colorIn('Active word', st.highlight_color, (v) => setStyle('highlight_color', v)),
    colorIn('★ Emphasis', st.emphasis_color, (v) => setStyle('emphasis_color', v)),
    st.highlight === 'box' ? colorIn('Text on box', st.highlight_text, (v) => setStyle('highlight_text', v)) : null,
    colorIn('Shadow', st.shadow_color, (v) => setStyle('shadow_color', v)));
  out.push(grp('Look',
    field('Highlight', segmented([['color', 'Colour'], ['box', 'Box'], ['none', 'None']], st.highlight, (v) => { setStyle('highlight', v); renderPanel(); })),
    field('Animation', segmented([['pop', 'Pop'], ['fade', 'Fade'], ['none', 'None']], st.animation, (v) => setStyle('animation', v))),
    toggle('Pop the active word', st.word_pop, (v) => setStyle('word_pop', v)),
    colors,
    h('div', { style: { height: '10px' } }),
    slider('Outline', st.outline, 0, 16, 0.5, (v) => setStyle('outline', v)),
    slider('Shadow', st.shadow, 0, 14, 0.5, (v) => setStyle('shadow', v)),
    slider('Shadow opacity', st.shadow_opacity, 0, 1, 0.05, (v) => setStyle('shadow_opacity', v), (v) => Math.round(v * 100) + '%'),
    toggle('Background box behind captions', st.bg, (v) => { setStyle('bg', v); renderPanel(); }),
    st.bg ? h('div', {},
      h('div', { class: 'colors' }, colorIn('Box colour', st.bg_color, (v) => setStyle('bg_color', v))),
      slider('Box opacity', st.bg_opacity, 0.1, 1, 0.05, (v) => setStyle('bg_opacity', v), (v) => Math.round(v * 100) + '%'),
      slider('Box padding', st.bg_pad, 2, 40, 1, (v) => setStyle('bg_pad', v))) : null));

  const reps = h('div', {});
  const renderReps = () => {
    reps.innerHTML = '';
    (st.replacements || []).forEach((r, i) => {
      reps.append(h('div', { class: 'rep' },
        h('input', { type: 'text', value: r.from, placeholder: 'heard as…', oninput: (e) => { r.from = e.target.value; setStyle('replacements', st.replacements); } }),
        h('span', { class: 'muted' }, '→'),
        h('input', { type: 'text', value: r.to, placeholder: 'show as…', oninput: (e) => { r.to = e.target.value; setStyle('replacements', st.replacements); } }),
        h('button', { class: 'btn sm ghost danger', onclick: () => { st.replacements.splice(i, 1); setStyle('replacements', st.replacements); renderReps(); } }, '✕')));
    });
  };
  renderReps();
  out.push(grp('Clean-up (all clips)',
    toggle('Remove filler words (um, uh)', st.remove_fillers, (v) => setStyle('remove_fillers', v)),
    toggle('Strip periods & commas', st.strip_punct, (v) => setStyle('strip_punct', v)),
    h('p', { class: 'hint' }, 'Find & replace fixes brand names everywhere, e.g. "acme" → "ACME™", "30 day" → "30-day".'),
    reps,
    h('button', { class: 'btn sm', onclick: () => { st.replacements = [...(st.replacements || []), { from: '', to: '' }]; saveProject('style'); renderReps(); } }, '+ Add replacement')));

  const os = S.p.overlay_style;
  const setOs = (k, v) => { os[k] = v; ovKey = ''; saveProject('overlay_style'); };
  out.push(grp('Text overlay style',
    field('Font', selectIn(fonts, os.font, (v) => setOs('font', v))),
    slider('Size', os.size, 30, 180, 1, (v) => setOs('size', v)),
    h('div', { class: 'colors' }, colorIn('Text', os.color, (v) => setOs('color', v)), colorIn('Box', os.bg_color, (v) => setOs('bg_color', v))),
    h('div', { style: { height: '8px' } }),
    slider('Box opacity', os.bg_opacity, 0, 1, 0.05, (v) => setOs('bg_opacity', v), (v) => Math.round(v * 100) + '%'),
    slider('Max width', os.max_width, 0.4, 0.96, 0.01, (v) => setOs('max_width', v), (v) => Math.round(v * 100) + '%'),
    toggle('UPPERCASE', os.uppercase, (v) => setOs('uppercase', v))));

  const tr = S.p.transcription;
  const setTr = (k, v) => { tr[k] = v; saveProject('transcription'); };
  out.push(grp('Speech recognition',
    field('Model', selectIn(Object.entries(S.meta.models), tr.model, (v) => { setTr('model', v); api('POST', '/api/speech/warm', { model: v }).then(renderSpeech).catch(fail); })),
    field('Language', selectIn([['auto', 'Auto-detect'], ['en', 'English'], ['es', 'Spanish'], ['pt', 'Portuguese'], ['fr', 'French'], ['de', 'German'], ['it', 'Italian']], tr.language, (v) => setTr('language', v))),
    field('Vocabulary', h('textarea', { rows: 2, placeholder: 'Brand & product names, e.g. Acme, HydraBoost, SPF 50', oninput: (e) => setTr('vocabulary', e.target.value) }, tr.vocabulary || ''), true),
    toggle('Auto-cut silence at clip start/end on import', tr.auto_trim, (v) => setTr('auto_trim', v)),
    h('p', { class: 'hint' }, 'Runs on this computer, free. Applies to new uploads and "Redo". The first run downloads the model (base ≈ 150 MB, small ≈ 500 MB, turbo ≈ 1.6 GB).')));
  return out;
}

// ------------------------------------------------------------------ Brand tab
function uploadAsset(kind, accept) {
  const inp = h('input', { type: 'file', accept });
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    const fd = new FormData();
    fd.append('kind', kind); fd.append('file', f);
    toast(`Uploading ${f.name}…`);
    try {
      await sendProject(); // land pending brand edits first so the server merges onto them
      const r = await fetch(`/api/projects/${S.p.id}/assets`, { method: 'POST', body: fd });
      const d = await r.json();
      if (!r.ok) throw new Error(d.detail);
      markDirty();
      S.p.brand[kind] = d.brand[kind];
      logoKey = null; renderPanel(); buildSequence();
    } catch (e) { fail(e); }
  };
  inp.click();
}

function assetRow(kind, label, accept, thumb) {
  const a = S.p.brand[kind];
  if (!a) return h('button', { class: 'btn', onclick: () => uploadAsset(kind, accept) }, `+ Add ${label}`);
  return h('div', { class: 'asset' }, thumb ? h('img', { src: fileUrl(a.file) }) : null, h('span', { class: 'nm' }, a.name || a.file),
    h('button', { class: 'btn sm', onclick: () => uploadAsset(kind, accept) }, 'Replace'),
    h('button', { class: 'btn sm ghost danger', onclick: () => { S.p.brand[kind] = null; saveProject('brand'); logoKey = null; renderPanel(); buildSequence(); } }, 'Remove'));
}

function panelBrand() {
  const b = S.p.brand;
  const setB = (k, v, rebuild = false) => { b[k] = v; logoKey = null; saveProject('brand'); if (rebuild) buildSequence(); };
  const out = [];
  const corner = h('div', { class: 'corner' });
  for (const pos of ['tl', 'tr', 'bl', 'br']) corner.append(h('button', { class: b.logo_pos === pos ? 'on' : '', title: pos, onclick: () => { setB('logo_pos', pos); renderPanel(); } }));
  out.push(grp('Logo watermark',
    assetRow('logo', 'logo (PNG)', 'image/png,image/jpeg,image/webp', true),
    b.logo ? h('div', {},
      field('Corner', corner),
      slider('Size', b.logo_size, 0.05, 0.4, 0.005, (v) => setB('logo_size', v), (v) => Math.round(v * 100) + '%'),
      slider('Opacity', b.logo_opacity, 0.1, 1, 0.05, (v) => setB('logo_opacity', v), (v) => Math.round(v * 100) + '%'),
      slider('Margin', b.logo_margin, 0, 0.15, 0.005, (v) => setB('logo_margin', v), (v) => Math.round(v * 100) + '%')) : null));

  out.push(grp('End card',
    h('p', { class: 'hint' }, 'Appended to every ad: an image (offer, CTA, logo) or a short video. Images that don\'t match a format get a blurred background.'),
    assetRow('endcard', 'end card', 'image/*,video/*', b.endcard && b.endcard.kind === 'image'),
    b.endcard && b.endcard.kind === 'image' ? slider('Duration', b.endcard_duration, 0.5, 6, 0.1, (v) => setB('endcard_duration', v, true), (v) => v.toFixed(1) + 's') : null));

  out.push(grp('Background music',
    assetRow('music', 'music track', 'audio/*,.mp3,.wav,.m4a'),
    b.music ? h('div', {},
      slider('Music level', b.music_volume, -40, 0, 1, (v) => { setB('music_volume', v); if (P.playing) music.volume = clamp(db2gain(v) * (b.music_duck ? 0.75 : 1), 0, 1); }, (v) => v + ' dB'),
      toggle('Auto-duck under the voice', b.music_duck, (v) => setB('music_duck', v)),
      h('p', { class: 'hint' }, 'Music loops for the whole ad and fades out at the end. Use licensed tracks only; Meta and TikTok will mute or reject copyrighted songs.')) : null));

  const pr = b.progress;
  const setP = (k, v) => { pr[k] = v; saveProject('brand'); };
  out.push(grp('Progress bar',
    toggle('Show a progress bar', pr.enabled, (v) => { setP('enabled', v); renderPanel(); }),
    pr.enabled ? h('div', {},
      h('div', { class: 'colors' }, colorIn('Colour', pr.color, (v) => setP('color', v))),
      h('div', { style: { height: '8px' } }),
      slider('Thickness', pr.height, 4, 30, 1, (v) => setP('height', v), (v) => v + 'px'),
      field('Position', segmented([['top', 'Top'], ['bottom', 'Bottom']], pr.position, (v) => setP('position', v))),
      h('p', { class: 'hint' }, 'Adds a re-encode step, so renders take longer.')) : null));

  out.push(grp('Audio',
    toggle('Clean up voice (cut rumble & background hiss, even out levels)', b.voice_enhance, (v) => setB('voice_enhance', v)),
    h('p', { class: 'hint' }, 'Good for phone-recorded UGC. Applies to renders only; use Exact preview to hear it.'),
    toggle('Normalise every clip and every finished ad to the same loudness', b.normalize, (v) => setB('normalize', v)),
    slider('Target', b.lufs_target, -20, -9, 0.5, (v) => setB('lufs_target', v), (v) => v + ' LUFS'),
    h('p', { class: 'hint' }, '-14 LUFS is a safe target for Meta, TikTok and YouTube. The final mix (voice + music) is measured and corrected.')));
  return out;
}

// ------------------------------------------------------------------ Export tab
function enabledCombos(readyOnly = false) {
  const off = new Set(S.p.matrix.off || []);
  const ok = (c) => !readyOnly || c.status === 'ready';
  const out = [];
  for (const hk of clips('hook')) for (const bd of clips('body')) if (!off.has(`${hk.id}|${bd.id}`) && ok(hk) && ok(bd)) out.push([hk.id, bd.id]);
  return out;
}

function renderMatrixCount() {
  if (!S.p) return;
  const n = enabledCombos().length, f = S.p.export.formats.length;
  $('#matrixCount').textContent = n;
  $('#btnRender').textContent = n && f ? `Render ${n * f} file${n * f > 1 ? 's' : ''}` : 'Render ads';
  $('#btnRender').title = `${n} hook×body combos × ${f} format${f > 1 ? 's' : ''}`;
}

function exampleName() {
  const hk = clips('hook')[0], bd = clips('body')[0];
  const slug = (s) => (s || '').replace(/[^A-Za-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 24);
  const vals = { project: slug(S.p.name), hook: hk ? hk.label : 'H01', body: bd ? bd.label : 'B01', hook_name: slug(hk && hk.name), body_name: slug(bd && bd.name), format: S.p.export.formats[0] || '9x16', date: new Date().toISOString().slice(0, 10).replace(/-/g, ''), n: '001' };
  return S.p.export.naming.replace(/\{(\w+)\}/g, (m, k) => vals[k] ?? m).replace(/[^A-Za-z0-9._-]+/g, '-') + '.mp4';
}

function panelExport() {
  const ex = S.p.export;
  const setEx = (k, v) => { ex[k] = v; saveProject('export'); renderMatrixCount(); };
  const out = [];
  const chips = h('div', { class: 'fmt-chips' });
  for (const [f, d] of Object.entries(S.meta.formats)) {
    const on = ex.formats.includes(f);
    const sh = 22 / Math.max(d.w, d.h);
    chips.append(h('div', { class: 'fmt-chip' + (on ? ' on' : ''), onclick: () => {
      const set = new Set(ex.formats);
      set.has(f) ? set.delete(f) : set.add(f);
      setEx('formats', Object.keys(S.meta.formats).filter((x) => set.has(x)));
      renderPanel();
    } }, h('span', { class: 'shape', style: { width: d.w * sh + 'px', height: d.h * sh + 'px' } }), h('div', {}, FMT_LABEL[f], h('small', {}, FMT_USE[f]))));
  }
  out.push(grp('Formats', chips, h('p', { class: 'hint', style: { marginTop: '8px' } }, 'Meta tip: upload 9:16 + 4:5 of the same ad and assign per placement (Stories/Reels vs Feed).')));

  out.push(grp('Framing & quality',
    field('Fit', segmented([['fill', 'Crop to fill'], ['blur', 'Fit + blur']], ex.fit, (v) => { setEx('fit', v); buildSequence(); })),
    field('Quality', segmented([['standard', 'Standard'], ['high', 'High'], ['max', 'Max']], ex.quality, (v) => setEx('quality', v))),
    field('Speed', segmented([['fast', 'Fast'], ['balanced', 'Balanced'], ['best', 'Smallest file']], ex.speed, (v) => setEx('speed', v))),
    slider('Parallel jobs', ex.parallel, 1, 6, 1, (v) => setEx('parallel', v))));

  const exEl = h('div', { class: 'example' }, exampleName());
  const nameIn = h('input', { type: 'text', value: ex.naming, oninput: (e) => { setEx('naming', e.target.value); exEl.textContent = exampleName(); } });
  const tokens = h('div', { class: 'tokens' });
  for (const t of ['project', 'hook', 'body', 'hook_name', 'body_name', 'format', 'date', 'n']) {
    tokens.append(h('button', { onclick: () => { nameIn.value += (nameIn.value && !/[_-]$/.test(nameIn.value) ? '_' : '') + `{${t}}`; nameIn.dispatchEvent(new Event('input')); } }, `{${t}}`));
  }
  out.push(grp('File names', nameIn, tokens, exEl,
    h('p', { class: 'hint' }, 'Every file name carries its hook (H01…) and body (B01…) so you can always tell the ads apart. A manifest.csv listing every ad and its hook script is saved with each batch.')));

  const n = enabledCombos().length, ready = enabledCombos(true).length, f = ex.formats.length;
  out.push(grp('Render',
    h('div', { class: 'summary' }, h('b', {}, `${ready * f} files`), h('span', { class: 'muted' }, `${ready} ads × ${f} format${f === 1 ? '' : 's'}`, n > ready ? ` · ${n - ready} waiting for clips to finish processing` : '')),
    h('div', { class: 'btn-row' }, h('button', { class: 'btn', onclick: openMatrix }, 'Choose combos'), h('button', { class: 'btn primary', onclick: startRender, disabled: !ready || !f }, 'Render now'))));

  const bl = h('div', {});
  for (const b of S.p.batches || []) {
    const d = new Date(b.created * 1000);
    bl.append(h('div', { class: 'batch' },
      h('div', { class: 'row' }, h('b', {}, d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })), h('span', { class: 'st ' + b.status }, b.status)),
      h('div', { class: 'muted', style: { margin: '4px 0 6px' } }, `${(b.outputs || []).length} / ${b.total} files${(b.errors || []).length ? ` · ${b.errors.length} failed` : ''}`),
      h('div', { class: 'btn-row' },
        h('button', { class: 'btn sm', onclick: () => openFolder(b.dir) }, 'Open folder'),
        (b.outputs || []).length ? h('a', { class: 'btn sm', href: `/api/projects/${S.p.id}/zip?path=${encodeURIComponent(b.dir)}`, style: { textDecoration: 'none' } }, 'Download .zip') : null,
        (b.outputs || []).length ? h('button', { class: 'btn sm', onclick: () => playOutput(b.outputs[0]) }, 'Watch') : null)));
  }
  if (!(S.p.batches || []).length) bl.append(h('p', { class: 'muted' }, 'No renders yet.'));
  out.push(grp('Previous renders', bl));
  return out;
}

async function openFolder(rel) {
  try {
    const r = await api('POST', `/api/projects/${S.p.id}/open`, { path: rel });
    if (!r.ok) toast(`Your files are in: ${r.path}`, false, 10000);
  } catch (e) { fail(e); }
}

// ------------------------------------------------------------------ matrix
function openMatrix() { renderMatrix(); $('#matrixModal').classList.remove('hidden'); }

function renderMatrix() {
  const off = new Set(S.p.matrix.off || []);
  const hooks = clips('hook'), bodies = clips('body');
  const t = $('#matrix');
  t.innerHTML = '';
  const save = () => { S.p.matrix.off = [...off]; saveProject('matrix'); renderMatrix(); renderMatrixCount(); if (S.tab === 'export') renderPanel(); };
  const allOn = hooks.every((hk) => bodies.every((bd) => !off.has(`${hk.id}|${bd.id}`)));
  const head = h('tr', {}, h('th', { onclick: () => { hooks.forEach((hk) => bodies.forEach((bd) => allOn ? off.add(`${hk.id}|${bd.id}`) : off.delete(`${hk.id}|${bd.id}`))); save(); } }, allOn ? 'None' : 'All'));
  for (const bd of bodies) {
    const colOn = hooks.every((hk) => !off.has(`${hk.id}|${bd.id}`));
    head.append(h('th', { title: 'Toggle column', onclick: () => { hooks.forEach((hk) => colOn ? off.add(`${hk.id}|${bd.id}`) : off.delete(`${hk.id}|${bd.id}`)); save(); } }, bd.label, h('small', {}, bd.name)));
  }
  t.append(h('thead', {}, head));
  const tb = h('tbody', {});
  for (const hk of hooks) {
    const rowOn = bodies.every((bd) => !off.has(`${hk.id}|${bd.id}`));
    const tr = h('tr', {}, h('th', { title: 'Toggle row', onclick: () => { bodies.forEach((bd) => rowOn ? off.add(`${hk.id}|${bd.id}`) : off.delete(`${hk.id}|${bd.id}`)); save(); } }, hk.label, h('small', {}, hk.name)));
    for (const bd of bodies) {
      const k = `${hk.id}|${bd.id}`, on = !off.has(k);
      const na = hk.status !== 'ready' || bd.status !== 'ready';
      tr.append(h('td', { class: (on ? 'on' : '') + (na ? ' na' : ''), title: `${hk.label} × ${bd.label}`, onclick: (e) => {
        if (e.target.classList.contains('pv')) {
          S.sel.hook = hk.id; S.sel.body = bd.id; S.sel.clip = hk.id;
          $('#matrixModal').classList.add('hidden'); renderBin(); buildSequence(); seek(0); renderPanel();
          return;
        }
        on ? off.add(k) : off.delete(k); save();
      } }, h('span', { class: 'ck' }, on ? '✓' : ''), h('span', { class: 'pv', title: 'Preview this combo' }, '▶')));
    }
    tb.append(tr);
  }
  t.append(tb);
  const tools = $('#matrixTools');
  tools.innerHTML = '';
  const setOff = (fn) => { off.clear(); for (const hk of hooks) for (const bd of bodies) if (fn(hk, bd)) off.add(`${hk.id}|${bd.id}`); save(); };
  const bodySel = h('select', { class: 'input', style: { width: 'auto', padding: '3px 6px' }, onchange: (e) => { S.mxBody = e.target.value; } }, ...bodies.map((bd) => h('option', { value: bd.id }, `${bd.label} ${bd.name}`)));
  if (S.mxBody && bodies.some((bd) => bd.id === S.mxBody)) bodySel.value = S.mxBody;
  tools.append(
    h('button', { class: 'btn sm', onclick: () => setOff(() => false) }, 'Select all'),
    h('button', { class: 'btn sm', onclick: () => setOff(() => true) }, 'Clear'),
    h('span', { class: 'muted', style: { marginLeft: '10px' } }, 'Only one body:'),
    h('button', { class: 'btn sm', title: 'Every hook paired with just the chosen body', onclick: () => setOff((hk, bd) => bd.id !== bodySel.value) }, 'All hooks ×'),
    bodySel);
  const n = enabledCombos().length, f = S.p.export.formats.length;
  $('#matrixSummary').textContent = `${n} of ${hooks.length * bodies.length} combos selected × ${f} format${f === 1 ? '' : 's'} = ${n * f} files. Click a cell to toggle it, a header for a whole row or column, ▶ to preview.`;
}

// ------------------------------------------------------------------ rendering
async function startRender() {
  const combos = enabledCombos(true);
  const n = enabledCombos().length;
  if (!combos.length) { toast('No ready combos selected. Add clips or open the matrix.', true); return; }
  if (!S.p.export.formats.length) { toast('Pick at least one format in the Export tab.', true); setTab('export'); return; }
  if (combos.length < n && !confirm(`${n - combos.length} combos are still processing and will be skipped. Render the ${combos.length} ready ones?`)) return;
  const missing = new Set();
  for (const [hk, bd] of combos) for (const id of [hk, bd]) { const c = clipById(id); if (c.tstatus === 'queued' || c.tstatus === 'running') missing.add(c.label); }
  if (missing.size && S.p.style.enabled && !confirm(`Still transcribing ${[...missing].join(', ')}, so those ads would have no captions. Render anyway?`)) return;
  try {
    pause();
    const b = await api('POST', `/api/projects/${S.p.id}/render`, { combos, formats: S.p.export.formats });
    S.batch = b;
    renderDrawer();
    pollBatch(b.id);
  } catch (e) { fail(e); }
}

async function pollBatch(bid) {
  try {
    const b = await api('GET', `/api/batches/${bid}`);
    if (S.batch && S.batch.id === bid) { S.batch = b; renderDrawer(); }
    if (b.status === 'running') setTimeout(() => pollBatch(bid), 900);
    else {
      const ix = (S.p.batches || []).findIndex((x) => x.id === b.id);
      if (ix >= 0) S.p.batches[ix] = b; else S.p.batches.unshift(b);
      if (S.tab === 'export') renderPanel();
      if (b.status === 'done') toast(`Done: ${b.outputs.length} files rendered`);
    }
  } catch (e) { console.warn(e); setTimeout(() => pollBatch(bid), 2000); }
}

function renderDrawer() {
  const d = $('#drawer');
  const b = S.batch;
  if (!b) { d.classList.add('hidden'); return; }
  d.classList.remove('hidden');
  d.innerHTML = '';
  const running = b.status === 'running';
  d.append(
    h('div', { class: 'row between' }, h('b', {}, running ? `Rendering ${b.total} files` : `Render ${b.status}`), h('span', { class: 'st ' + b.status }, `${b.done}/${b.total}`)),
    h('div', { class: 'pbar' }, h('i', { style: { width: `${Math.round(b.progress * 100)}%` } })),
    h('div', { class: 'muted' }, `${Math.round(b.progress * 100)}% · ${b.message || ''}`));
  if ((b.errors || []).length) d.append(h('div', { class: 'status-line err' }, b.errors.slice(0, 3).join('\n')));
  if ((b.outputs || []).length) {
    const outs = h('div', { class: 'outs' });
    for (const o of b.outputs) outs.append(h('div', { onclick: () => playOutput(o) }, h('span', {}, o.name), h('span', { class: 'muted' }, `${o.duration}s ▶`)));
    d.append(outs);
  }
  d.append(h('div', { class: 'row end' },
    running ? h('button', { class: 'btn danger', onclick: () => api('POST', `/api/batches/${b.id}/cancel`).catch(fail) }, 'Cancel') : null,
    !running ? h('button', { class: 'btn', onclick: () => openFolder(b.dir) }, 'Open folder') : null,
    !running && b.outputs.length ? h('a', { class: 'btn', href: `/api/projects/${S.p.id}/zip?path=${encodeURIComponent(b.dir)}`, style: { textDecoration: 'none' } }, 'Download .zip') : null,
    !running ? h('button', { class: 'btn ghost', onclick: () => { S.batch = null; renderDrawer(); } }, 'Close') : null));
}

function playOutput(o) {
  pause();
  $('#playerTitle').textContent = o.name;
  const v = $('#outVideo');
  v.src = fileUrl(o.file);
  $('#playerModal').classList.remove('hidden');
  v.play().catch(() => {});
}

async function exactPreview() {
  if (!S.sel.hook || !S.sel.body) { toast('Select a hook and a body first', true); return; }
  if (S.previewBusy) return;
  S.previewBusy = true;
  const btn = $('#btnExact');
  btn.disabled = true; btn.textContent = 'Rendering…';
  try {
    const b = await api('POST', `/api/projects/${S.p.id}/render`, { combos: [[S.sel.hook, S.sel.body]], formats: [S.fmt], preview: true });
    let st = b;
    while (st.status === 'running') { await new Promise((r) => setTimeout(r, 700)); st = await api('GET', `/api/batches/${b.id}`); }
    if (st.outputs.length) playOutput({ ...st.outputs[0], name: `Exact preview · ${st.outputs[0].name}` });
    else throw new Error(st.errors[0] || st.message || 'Preview failed');
  } catch (e) { fail(e); }
  S.previewBusy = false;
  btn.disabled = false; btn.textContent = 'Exact preview';
}

// ------------------------------------------------------------------ onboarding tour
// Phase 1 runs right after the first project is created (adding clips); phase 2 runs once the
// first clip is ready, when there is something real on screen to point at.
const TOUR = [
  { phase: 1, title: 'Welcome. Here’s the whole idea', html: `<p>You add <b>hooks</b> (the first few seconds of an ad) and <b>bodies</b> (the rest). Ad Factory pairs <b>every hook with every body</b>, adds captions and your branding, and exports every combination in every format you need.</p><p>18 hooks × 2 bodies = 36 ads from one click.</p>` },
  { phase: 1, target: '.bin-sec[data-role=hook]', place: 'right', title: '1 · Add your hooks', html: `<p>Drag videos here or click <b>+ Add</b>. They’re numbered <b>H01, H02…</b> in file-name order, so name files <i>hook01, hook02…</i>.</p><p>Each clip is prepared automatically:</p><ul><li>captions transcribed word by word</li><li>dead air cut from the start and end</li><li>volume levelled to match every other clip</li></ul>` },
  { phase: 1, target: '.bin-sec[data-role=body]', place: 'right', title: '2 · Add your bodies', html: `<p>Same here: they become <b>B01, B02…</b>. Every hook will be joined to every body.</p><p>Any phone or camera video works: MP4, MOV, iPhone HDR.</p>` },
  { phase: 1, title: 'Add your clips now', html: `<p>Drop in at least one hook and one body. When the first clip is ready, the tour continues with the editor.</p><p class="muted">You can replay this tour anytime from <b>?</b> in the top bar.</p>`, end: true },
  { phase: 2, target: '#stageWrap', place: 'left', title: 'Live preview', html: `<p>Plays the selected <b>hook → body → end card</b> exactly as the ad will export, with captions, logo and text on top.</p><p>Click any hook or body on the left to swap it in. Press <kbd>Space</kbd> to play.</p>` },
  { phase: 2, target: '#fmtTabs', place: 'bottom', title: 'Formats & safe zones', html: `<p>Switch between <b>9:16</b> (Reels, TikTok, Stories), <b>4:5</b> (Feed), <b>1:1</b> and <b>16:9</b>.</p><p>The <b>Safe zone</b> menu (right) shades the areas covered by each app’s buttons. Keep captions out of the red.</p>` },
  { phase: 2, target: '#transport', place: 'top', title: 'Timeline', html: `<p>The waveform of the whole ad. Click or drag to scrub. White ticks are spoken words; white lines are jump cuts.</p><p><kbd>←</kbd> <kbd>→</kbd> step one frame, <kbd>↑</kbd> <kbd>↓</kbd> switch hook, <kbd>B</kbd> switch body.</p>` },
  { phase: 2, target: '#inspector', place: 'left', tab: 'clip', title: 'Clip tab: edit the selected clip', html: `<ul><li><b>Trim</b>: drag the purple handles, or press <kbd>I</kbd>/<kbd>O</kbd> at the playhead</li><li><b>Cut pauses</b>: turns long pauses into jump cuts</li><li><b>Framing</b>: zoom and pan to keep faces in frame in every format</li><li><b>Text overlay</b>: an on-screen headline for the hook</li><li><b>Transcript</b>: click any word to fix it. Yellow-underlined words are worth checking.</li></ul>` },
  { phase: 2, target: '#inspector', place: 'left', tab: 'captions', title: 'Captions tab: the look', html: `<p>Pick a style (Bold Pop, Word Box, Karaoke, One Word, Clean Box, Minimal, Comic), then fine-tune font, size, colours, position and animation.</p><p><b>Find &amp; replace</b> fixes a brand name in every clip at once.</p>` },
  { phase: 2, target: '#inspector', place: 'left', tab: 'brand', title: 'Brand tab', html: `<p>Logo watermark, an <b>end card</b> added to every ad, <b>background music</b> that ducks under the voice, a progress bar, and <b>Clean up voice</b> for phone audio.</p><p>Every finished ad is levelled to the same loudness automatically.</p>` },
  { phase: 2, target: '#inspector', place: 'left', tab: 'export', title: 'Export tab', html: `<p>Tick the formats you want, choose crop or fit-with-blur, quality, and the file-name pattern.</p><p>Past renders are listed here with <b>Open folder</b> and <b>Download .zip</b>.</p>` },
  { phase: 2, target: '#btnMatrix', place: 'bottom', title: 'Matrix: choose the combos', html: `<p>A grid of every hook × body. Everything is on by default. Click cells, rows or columns to leave combos out, or press ▶ to preview one.</p>` },
  { phase: 2, target: '#btnExact', place: 'bottom', title: 'Exact preview', html: `<p>Renders the ad you’re looking at in a few seconds, so you can check the real file before rendering the whole batch.</p>` },
  { phase: 2, target: '#btnRender', place: 'bottom', title: 'Render', html: `<p>Exports every selected combo in every chosen format. Files are named like <b>Project_H03_B01_9x16.mp4</b>.</p><p>When it’s done: <b>Open folder</b> or <b>Download .zip</b>.</p>` },
  { phase: 2, target: '#btnHelp', place: 'bottom', title: 'That’s it', html: `<p>Everything saves automatically. <kbd>Ctrl/⌘</kbd>+<kbd>Z</kbd> undoes any edit.</p><p>Open <b>?</b> anytime for this tour, the full feature guide and shortcuts.</p>`, end: true },
];
const T = { steps: [], i: 0, phase: 0 };

function tourSeen(phase) { try { return localStorage.getItem('adf.tour' + phase) === '1'; } catch { return true; } }
function markTour(phase) { try { localStorage.setItem('adf.tour' + phase, '1'); } catch { /* */ } }

function startTour(phase) {
  if (!$('#tour').classList.contains('hidden')) return;
  const hasClip = clips().some((c) => c.status === 'ready');
  T.steps = TOUR.filter((s) => (phase === 'all' ? (s.phase === 1 && !s.end) || (s.phase === 2 && hasClip) || (s.phase === 1 && !hasClip) : s.phase === phase));
  if (!T.steps.length) return;
  T.phase = phase; T.i = 0;
  closeModals();
  pause();
  $('#tour').classList.remove('hidden');
  showTourStep();
}

function endTour(skipped) {
  $('#tour').classList.add('hidden');
  if (T.steps.some((st) => st.tab) && S.tab !== 'clip') setTab('clip');
  if (T.phase === 1 || T.phase === 'all') markTour(1);
  if (T.phase === 2 || T.phase === 'all' || skipped) markTour(2);
  if (skipped) markTour(1);
}

function showTourStep() {
  const st = T.steps[T.i];
  if (st.tab) setTab(st.tab);
  $('#tourStep').textContent = `Step ${T.i + 1} of ${T.steps.length}`;
  $('#tourTitle').textContent = st.title;
  $('#tourText').innerHTML = st.html;
  $('#tourBack').disabled = T.i === 0;
  $('#tourNext').textContent = T.i === T.steps.length - 1 ? (st.end && st.phase === 1 ? 'Got it' : 'Finish') : 'Next';
  requestAnimationFrame(placeTour);
}

function placeTour() {
  if ($('#tour').classList.contains('hidden')) return;
  const st = T.steps[T.i];
  const hole = $('#tourHole'), card = $('#tourCard');
  const vw = innerWidth, vh = innerHeight, cw = card.offsetWidth, chh = card.offsetHeight, pad = 6, gap = 16;
  const el = st.target && $(st.target);
  if (!el) {
    hole.classList.add('none');
    card.style.left = (vw - cw) / 2 + 'px'; card.style.top = Math.max(20, (vh - chh) / 2 - 40) + 'px';
    return;
  }
  hole.classList.remove('none');
  const r = el.getBoundingClientRect();
  Object.assign(hole.style, { left: r.left - pad + 'px', top: r.top - pad + 'px', width: r.width + pad * 2 + 'px', height: r.height + pad * 2 + 'px' });
  let x, y;
  if (st.place === 'right') { x = r.right + gap; y = r.top; }
  else if (st.place === 'left') { x = r.left - cw - gap; y = r.top + 40; }
  else if (st.place === 'top') { x = r.left + (r.width - cw) / 2; y = r.top - chh - gap; }
  else { x = r.left + (r.width - cw) / 2; y = r.bottom + gap; }
  if (x < 12 || x + cw > vw - 12) x = clamp(x, 12, vw - cw - 12);
  card.style.left = x + 'px';
  card.style.top = clamp(y, 12, vh - chh - 12) + 'px';
}

function maybeAutoTour() {
  if (!S.p || !$('#tour').classList.contains('hidden') || $$('.modal-back').some((m) => !m.classList.contains('hidden'))) return;
  if (!tourSeen(2) && clips().some((c) => c.status === 'ready') && P.segs.length) startTour(2);
}

// ------------------------------------------------------------------ help
const FEATURES = [
  ['Getting clips in', [
    ['Hooks & bodies', 'Drop videos into each list. Numbered H01, H02… and B01, B02… in file-name order. MP4, MOV and iPhone HDR all work.'],
    ['Automatic prep', 'Every clip gets a fast preview copy, word-by-word captions, dead air cut from the start and end, and its loudness measured.'],
    ['Projects', 'One project per batch. A new project can copy the last one’s captions, logo, end card, music and export settings.'],
  ]],
  ['Preview & timeline', [
    ['Live preview', 'Plays hook → body → end card exactly as exported, with captions, logo, text overlays and progress bar.'],
    ['Formats', '9:16, 4:5, 1:1 and 16:9. Caption position is saved separately for each format.'],
    ['Safe zones', 'Shades where Reels, TikTok or Stories buttons cover the video.'],
    ['Timeline', 'Waveform of the current ad. Click or drag to scrub; ticks show words, lines show jump cuts.'],
    ['Exact preview', 'Renders the current ad in seconds so you can check the real file before the full batch.'],
  ]],
  ['Clip tab', [
    ['Trim', 'Drag the handles on the waveform, type exact times, or press I / O at the playhead. Auto-tighten cuts dead air.'],
    ['Cut pauses', 'Turns pauses longer than the slider value into quick jump cuts. Captions follow. Apply to all clips in one click.'],
    ['Framing', 'Zoom and pan so faces stay in frame when a clip is cropped to another format.'],
    ['Volume trim', 'Make one clip a bit louder or quieter, on top of the automatic levelling.'],
    ['Text overlay', 'An on-screen headline for any time range. "Use spoken first line" fills it from the transcript.'],
    ['Transcript', 'Click a word to jump to it and fix it, ★ to colour it, Hide to drop it from captions. "Edit as text" for bigger rewrites. Yellow-underlined words are low-confidence.'],
  ]],
  ['Captions tab', [
    ['Styles', 'Bold Pop, Word Box, Karaoke, One Word, Clean Box, Minimal and Comic. Every setting can be tuned after picking one.'],
    ['Look', '13 bold fonts, size, position, words per caption, 1–2 lines, uppercase, colours, outline, shadow, background box, active-word highlight (colour or box), pop or fade animation.'],
    ['Clean-up', 'Remove filler words (um, uh), strip punctuation, and find & replace across every clip (brand names, "$50K").'],
    ['Speech recognition', 'Runs on this computer. Choose speed vs accuracy, set the language, and list brand/product names so they’re recognised.'],
  ]],
  ['Brand tab', [
    ['Logo', 'Watermark in any corner with size, opacity and margin.'],
    ['End card', 'An image or short video added to the end of every ad.'],
    ['Music', 'Loops under every ad, ducks automatically while someone talks, fades out at the end.'],
    ['Progress bar', 'A thin bar that fills as the ad plays (top or bottom, any colour).'],
    ['Clean up voice', 'Removes rumble and background hiss and evens out levels. Great for phone-recorded UGC.'],
    ['Loudness', 'Every clip and every finished ad is levelled to the same loudness (-14 LUFS by default), so nothing is quieter or louder than the rest.'],
  ]],
  ['Export, matrix & rendering', [
    ['Matrix', 'Grid of every hook × body. Toggle cells, rows or columns, or "All hooks × one body". ▶ previews a combo.'],
    ['Export settings', 'Formats, crop-to-fill or fit-with-blurred-background, quality, speed, parallel jobs, file-name pattern.'],
    ['Fast batches', 'Each clip is rendered once per format and then joined, so 36 ads take roughly the time of 20.'],
    ['Results', 'One MP4 per ad plus manifest.csv listing every ad. Open the folder or download a .zip. Past renders stay listed.'],
  ]],
  ['Everywhere', [
    ['Auto-save', 'Every change is saved instantly to the project.'],
    ['Undo / redo', 'Ctrl/⌘+Z and Shift+Ctrl/⌘+Z, or the arrows in the top bar.'],
    ['Private', 'No account, no sign-up. Videos and projects stay in the AdFactory folder in your home folder.'],
  ]],
];

function openHelp(tab = 'start') {
  $('#helpModal').classList.remove('hidden');
  renderHelp(tab);
}

function renderHelp(tab) {
  $$('#helpTabs button').forEach((b) => b.classList.toggle('on', b.dataset.h === tab));
  const body = $('#helpBody');
  body.innerHTML = '';
  if (tab === 'start') {
    body.append(
      h('div', { class: 'help-cta' }, h('div', { style: { flex: 1 } }, h('b', {}, 'New here?'), h('div', { class: 'muted' }, 'A 2-minute tour that points at everything on screen.')),
        h('button', { class: 'btn primary', onclick: () => startTour('all') }, 'Take the tour')),
      h('h3', {}, 'Make a batch of ads in 5 steps'),
      h('ol', {},
        h('li', {}, h('b', {}, 'Add hooks and bodies'), ' on the left. Captions, trimming and levelling happen automatically.'),
        h('li', {}, h('b', {}, 'Check the captions'), ': click a clip, then fix any yellow-underlined words in the Clip tab.'),
        h('li', {}, h('b', {}, 'Pick a caption style'), ' in the Captions tab, and add your logo, end card or music in Brand.'),
        h('li', {}, h('b', {}, 'Choose formats'), ' in Export, and which combos in the Matrix (all by default).'),
        h('li', {}, h('b', {}, 'Render'), '. Then Open folder or Download .zip.')),
      h('p', { class: 'muted' }, `Projects and exports are saved in ${S.meta.home}.`));
  } else if (tab === 'features') {
    for (const [title, items] of FEATURES) {
      body.append(h('h3', {}, title), h('dl', {}, ...items.flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])));
    }
  } else {
    const keys = [['Space', 'Play / pause'], ['I / O', 'Set the clip’s in / out point at the playhead'], ['← →', 'Step one frame (Shift: one second)'],
      ['↑ ↓', 'Previous / next hook'], ['B', 'Switch to the next body'], ['M', 'Open the matrix'], ['Ctrl/⌘ Z', 'Undo'], ['Shift Ctrl/⌘ Z', 'Redo'], ['Esc', 'Close a window']];
    body.append(h('table', { class: 'keys' }, ...keys.map(([k, v]) => h('tr', {}, h('td', {}, h('kbd', {}, k)), h('td', {}, v)))),
      h('p', { class: 'muted', style: { marginTop: '12px' } }, 'Tip: click a word in the transcript to jump to it. Fixing it there updates every ad that uses the clip.'));
  }
}

// ------------------------------------------------------------------ static bindings
function bindStatic() {
  $('#projSel').addEventListener('change', (e) => { if (e.target.value === '__new') { e.target.value = S.p ? S.p.id : ''; openNewProject(); } else loadProject(e.target.value); });
  $('#projName').addEventListener('input', (e) => { S.p.name = e.target.value; saveProject('name'); const o = $(`#projSel option[value="${S.p.id}"]`); if (o) o.textContent = S.p.name; });
  $('#btnCreate').addEventListener('click', createProject);
  $('#newProjName').addEventListener('keydown', (e) => { if (e.key === 'Enter') createProject(); });
  $('#btnCancelNew').addEventListener('click', () => $('#welcome').classList.add('hidden'));
  $('#btnMatrix').addEventListener('click', openMatrix);
  $('#btnRender').addEventListener('click', startRender);
  $('#btnHelp').addEventListener('click', () => openHelp());
  $$('#helpTabs button').forEach((b) => b.addEventListener('click', () => renderHelp(b.dataset.h)));
  $('#tourNext').addEventListener('click', () => { if (T.i < T.steps.length - 1) { T.i++; showTourStep(); } else endTour(false); });
  $('#tourBack').addEventListener('click', () => { if (T.i > 0) { T.i--; showTourStep(); } });
  $('#tourSkip').addEventListener('click', () => endTour(true));
  window.addEventListener('resize', () => requestAnimationFrame(placeTour));
  $('#btnUndo').addEventListener('click', undo);
  $('#speechChip').addEventListener('click', () => { if ($('#speechChip').classList.contains('err')) api('POST', '/api/speech/warm', { model: S.p ? S.p.transcription.model : 'small' }).then(renderSpeech).catch(fail); });
  $('#btnRedo').addEventListener('click', redo);
  $('#btnPlay').addEventListener('click', () => (P.playing ? pause() : play()));
  $('#btnExact').addEventListener('click', exactPreview);
  $('#safeSel').value = S.safe;
  $('#safeSel').addEventListener('change', (e) => { S.safe = e.target.value; localStorage.setItem('adf.safe', S.safe); renderSafe(); });
  $$('#tabs button').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));
  $$('[data-close]').forEach((b) => b.addEventListener('click', () => closeModals()));
  $$('.modal-back').forEach((m) => m.addEventListener('click', (e) => { if (e.target === m && m.id !== 'welcome') closeModals(); }));
  $('#panel').addEventListener('focusout', () => setTimeout(() => { if (S.panelDirty && !$('#panel').contains(document.activeElement)) renderPanel(); }, 50));

  let role = 'hook';
  const fi = $('#fileInput');
  $$('[data-add]').forEach((b) => b.addEventListener('click', () => { role = b.dataset.add; fi.click(); }));
  fi.addEventListener('change', () => { if (fi.files.length) uploadFiles(role, fi.files); fi.value = ''; });
  for (const sec of $$('.bin-sec')) {
    sec.addEventListener('dragover', (e) => { e.preventDefault(); sec.classList.add('drag'); });
    sec.addEventListener('dragleave', () => sec.classList.remove('drag'));
    sec.addEventListener('drop', (e) => { e.preventDefault(); sec.classList.remove('drag'); if (S.p) uploadFiles(sec.dataset.role, e.dataTransfer.files); });
    sec.querySelector('.drop-hint').addEventListener('click', () => { role = sec.dataset.role; fi.click(); });
  }
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => e.preventDefault());
  window.addEventListener('resize', debounce(() => { layoutStage(); drawTimeline(); drawTrim(); }, 80));
  new ResizeObserver(debounce(() => { layoutStage(); drawTimeline(); }, 60)).observe($('#stageWrap'));
  bindTimeline();
  document.addEventListener('keydown', onKey);
}

function closeModals() {
  $$('.modal-back').forEach((m) => { if (m.id !== 'welcome' || S.p) m.classList.add('hidden'); });
  const v = $('#outVideo'); v.pause();
}

function onKey(e) {
  const t = e.target;
  if (!$('#tour').classList.contains('hidden')) {
    if (e.key === 'Escape') endTour(true);
    else if (e.key === 'ArrowRight' || e.key === 'Enter') $('#tourNext').click();
    else if (e.key === 'ArrowLeft') $('#tourBack').click();
    e.preventDefault();
    return;
  }
  if (e.key === 'Escape') { closeModals(); return; }
  if (t.closest && t.closest('input[type=text], input[type=number], textarea, [contenteditable]')) return;
  if ((e.metaKey || e.ctrlKey) && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); e.shiftKey ? redo() : undo(); return; }
  if ((e.metaKey || e.ctrlKey) && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); redo(); return; }
  if (t.closest && t.closest('select')) return;
  if (e.metaKey || e.ctrlKey || e.altKey) return;
  const k = e.key;
  if (k === ' ') { e.preventDefault(); P.playing ? pause() : play(); }
  else if (k === 'i' || k === 'I') setInOut('in');
  else if (k === 'o' || k === 'O') setInOut('out');
  else if (k === 'ArrowLeft' || k === 'ArrowRight') { e.preventDefault(); pause(); seek(P.T + (k === 'ArrowLeft' ? -1 : 1) * (e.shiftKey ? 1 : 1 / 30)); }
  else if (k === 'ArrowUp' || k === 'ArrowDown') {
    e.preventDefault();
    const hs = clips('hook');
    const i = hs.findIndex((c) => c.id === S.sel.hook);
    const n = hs[clamp(i + (k === 'ArrowUp' ? -1 : 1), 0, hs.length - 1)];
    if (n) selectClip(n.id);
  } else if (k === 'b' || k === 'B') {
    const bs = clips('body');
    const i = bs.findIndex((c) => c.id === S.sel.body);
    if (bs.length) selectClip(bs[(i + 1) % bs.length].id);
  } else if (k === 'm' || k === 'M') openMatrix();
}

boot();
