"""Bundled caption fonts + the metric libass uses so the browser preview matches the render."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

FONT_DIR = Path(__file__).parent / "fonts"

# id, label, file
CATALOG = [
    ("montserrat-black", "Montserrat Black", "Montserrat-Black.ttf"),
    ("montserrat-extrabold", "Montserrat ExtraBold", "Montserrat-ExtraBold.ttf"),
    ("montserrat-bold", "Montserrat Bold", "Montserrat-Bold.ttf"),
    ("poppins-black", "Poppins Black", "Poppins-Black.ttf"),
    ("poppins-extrabold", "Poppins ExtraBold", "Poppins-ExtraBold.ttf"),
    ("poppins-bold", "Poppins Bold", "Poppins-Bold.ttf"),
    ("poppins-semibold", "Poppins SemiBold", "Poppins-SemiBold.ttf"),
    ("inter-black", "Inter Black", "Inter-Black.ttf"),
    ("inter-bold", "Inter Bold", "Inter-Bold.ttf"),
    ("anton", "Anton", "Anton-Regular.ttf"),
    ("bebas", "Bebas Neue", "BebasNeue-Regular.ttf"),
    ("archivo-black", "Archivo Black", "ArchivoBlack-Regular.ttf"),
    ("luckiest-guy", "Luckiest Guy", "LuckiestGuy-Regular.ttf"),
]


@lru_cache(maxsize=None)
def fonts() -> dict[str, dict]:
    from fontTools.ttLib import TTFont

    out = {}
    for fid, label, file in CATALOG:
        p = FONT_DIR / file
        if not p.exists():
            continue
        f = TTFont(p, lazy=True)
        name = f["name"]
        family = name.getDebugName(1)
        sub = (name.getDebugName(2) or "Regular").lower()
        os2 = f["OS/2"]
        upm = f["head"].unitsPerEm
        win = os2.usWinAscent + os2.usWinDescent
        out[fid] = {
            "id": fid, "label": label, "file": file,
            "family": family,            # name libass matches
            "bold": "bold" in sub,       # needs ASS Bold=1 to pick this face
            # libass sizes text so winAscent+winDescent == Fontsize; CSS sizes the em.
            "css_scale": upm / win if win else 1.0,
            "ascent_ratio": os2.usWinAscent / win if win else 0.8,
            "cap_ratio": (getattr(os2, "sCapHeight", 0) or upm * 0.7) / win if win else 0.5,
        }
    return out


@lru_cache(maxsize=None)
def _metrics(fid: str):
    from fontTools.ttLib import TTFont

    f = TTFont(FONT_DIR / get(fid)["file"], lazy=True)
    os2 = f["OS/2"]
    return f.getBestCmap(), f["hmtx"], os2.usWinAscent + os2.usWinDescent


@lru_cache(maxsize=None)
def _hb_font(fid: str):
    try:
        import uharfbuzz as hb
        return hb, hb.Font(hb.Face(hb.Blob.from_file_path(str(FONT_DIR / get(fid)["file"]))))
    except Exception:
        return None, None


def word_spans(fid: str, words: list[str], size: float) -> tuple[list[tuple[float, float]], float]:
    """Shape a line the way libass does (HarfBuzz, with kerning) and return each word's
    [start, end) x in px plus the full line width, at an ASS font size."""
    text = " ".join(words)
    _, _, win = _metrics(fid)
    hb, font = _hb_font(fid)
    if hb is None:  # fallback: plain advance widths
        cmap, hmtx, _ = _metrics(fid)
        adv = [(hmtx[cmap.get(ord(c)) or ".notdef"][0] if (cmap.get(ord(c)) or ".notdef") in hmtx.metrics else 0) for c in text]
    else:
        buf = hb.Buffer()
        buf.add_str(text)
        buf.guess_segment_properties()
        hb.shape(font, buf, {"kern": True, "liga": True})
        adv = [0] * len(text)
        for info, pos in zip(buf.glyph_infos, buf.glyph_positions):
            adv[min(info.cluster, len(text) - 1)] += pos.x_advance
    k = size / win
    xs, x, i = [], 0.0, 0
    for n, w in enumerate(words):
        if n:
            x += adv[i] * k  # the space
            i += 1
        start = x
        for _ in w:
            x += adv[i] * k
            i += 1
        xs.append((start, x))
    return xs, x


def get(fid: str) -> dict:
    fs = fonts()
    return fs.get(fid) or next(iter(fs.values()))
