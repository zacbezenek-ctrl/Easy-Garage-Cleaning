"""Word-level transcription (faster-whisper, runs locally) and transcript re-alignment."""
from __future__ import annotations

import difflib
import os
import re
import threading
from pathlib import Path

from . import media

_model = None
_model_key = None
_lock = threading.Lock()

MODELS = {
    "base": "Fast (base)",
    "small": "Balanced (small)",
    "medium": "Accurate (medium)",
    "large-v3-turbo": "Best (large-v3-turbo)",
}
SIZE_MB = {"base": 145, "small": 484, "medium": 1530, "large-v3-turbo": 1620}

# Background download + load at launch so the first clip doesn't wait on a 500 MB download.
warm_state = {"model": None, "state": "idle", "progress": 0.0, "error": None}
_warm_done = threading.Event()


def warm(model_name: str) -> None:
    if warm_state["model"] == model_name and warm_state["state"] in ("downloading", "loading", "ready"):
        return
    if os.environ.get("ADF_FAKE_TRANSCRIBE"):
        warm_state.update(model=model_name, state="ready", progress=1.0, error=None)
        return
    _warm_done.clear()
    warm_state.update(model=model_name, state="downloading", progress=0.0, error=None)
    threading.Thread(target=_warm_run, args=(model_name,), daemon=True, name="warm").start()


def _cache_bytes(model_name: str) -> int:
    try:
        from faster_whisper.utils import _MODELS
        from huggingface_hub.constants import HF_HUB_CACHE
        d = Path(HF_HUB_CACHE) / ("models--" + _MODELS.get(model_name, model_name).replace("/", "--")) / "blobs"
        return sum(f.stat().st_size for f in d.iterdir()) if d.exists() else 0
    except Exception:
        return 0


def _warm_run(model_name: str) -> None:
    stop = threading.Event()

    def watch():
        total = SIZE_MB.get(model_name, 500) * 1024 * 1024
        while not stop.wait(0.7):
            if warm_state["state"] == "downloading":
                warm_state["progress"] = min(0.99, _cache_bytes(model_name) / total)

    threading.Thread(target=watch, daemon=True).start()
    try:
        if not Path(model_name).is_dir():
            from faster_whisper.utils import download_model
            download_model(model_name)
        warm_state.update(state="loading", progress=1.0)
        with _lock:
            _load(model_name)
        warm_state.update(state="ready")
    except Exception as e:
        warm_state.update(state="error", error=str(e)[-300:])
    finally:
        stop.set()
        _warm_done.set()


def _load(model_name: str):
    global _model, _model_key
    if _model is not None and _model_key == model_name:
        return _model
    from faster_whisper import WhisperModel

    # CPU by default: CUDA needs cuBLAS/cuDNN installed and fails at first use when they're missing.
    if os.environ.get("ADF_WHISPER_DEVICE") == "cuda":
        _model = WhisperModel(model_name, device="cuda", compute_type="float16")
    else:
        _model = WhisperModel(model_name, device="cpu", compute_type="int8",
                              cpu_threads=max(1, (os.cpu_count() or 4)))
    _model_key = model_name
    return _model


def transcribe(src: Path, *, model: str = "small", language: str | None = None,
               vocabulary: str = "", duration: float = 0, env: list | None = None,
               orig_name: str = "") -> list[dict]:
    """Returns [{w, s, e, p}] word timings in source-clip seconds."""
    if os.environ.get("ADF_FAKE_TRANSCRIBE"):
        return _fake(Path(os.environ["ADF_FAKE_TRANSCRIBE"]) / orig_name, duration, env or [])
    import numpy as np

    # Decode with our ffmpeg and pass samples directly: faster-whisper's own PyAV decoder
    # breaks with newer PyAV releases.
    audio = np.frombuffer(media.pcm_f32(src, 16000), dtype=np.float32).copy()
    if audio.size < 1600:
        return []
    if warm_state["model"] == model and warm_state["state"] in ("downloading", "loading"):
        _warm_done.wait()  # let the launch download finish instead of starting a second one
    with _lock:  # one model, one transcription at a time
        m = _load(model)
        segments, _info = m.transcribe(
            audio,
            language=None if language in (None, "", "auto") else language,
            word_timestamps=True,
            vad_filter=True,
            vad_parameters={"min_silence_duration_ms": 300},
            initial_prompt=vocabulary.strip() or None,
            condition_on_previous_text=False,
            beam_size=5,
        )
        words = []
        for seg in segments:
            for w in seg.words or []:
                t = w.word.strip()
                if not t:
                    continue
                if words and not w.word.startswith(" ") and re.match(r"[,.'’%]", t):
                    # "$50" + ",000" -> "$50,000"; "brand" + "'s" -> "brand's"
                    prev = words[-1]
                    prev.update(w=prev["w"] + t, e=round(w.end, 3), p=min(prev["p"], round(w.probability, 3)))
                    continue
                words.append({"w": t, "s": round(w.start, 3), "e": round(w.end, 3),
                              "p": round(w.probability, 3)})
    return words


def _fake(src: Path, duration: float, env: list) -> list[dict]:
    """Test mode: spread the words of <clip>.txt over the loud part of the clip."""
    side = Path(str(src).rsplit(".", 1)[0] + ".txt")
    text = side.read_text().split() if side.exists() else "this is a placeholder transcript".split()
    s, e = speech_bounds(env, 100, duration)
    step = (e - s) / max(1, len(text))
    return [{"w": t, "s": round(s + i * step, 3), "e": round(s + (i + 0.85) * step, 3), "p": 0.4 if i == 2 else 0.95}
            for i, t in enumerate(text)]


def speech_bounds(env: list, fps: int, duration: float) -> tuple[float, float]:
    if not env:
        return 0.0, duration
    peak = max(env) or 1
    thr = peak * 0.12
    idx = [i for i, v in enumerate(env) if v >= thr]
    if not idx:
        return 0.0, duration
    return idx[0] / fps, min(duration, (idx[-1] + 1) / fps)


def refine_words(words: list[dict], env: list, fps: int) -> list[dict]:
    """Whisper stamps the first word after a pause too early (it absorbs the silence) and the
    last word before a pause too late. Snap those edges to where the audio actually is."""
    if not env or not words:
        return words
    thr = (max(env) or 1) * 0.06
    n = len(env)
    for w in words:
        a, b = int(w["s"] * fps), min(n, int(w["e"] * fps) + 1)
        if a >= n or b - a < 2:
            continue
        if env[a] < thr:
            k = next((i for i in range(a, b) if env[i] >= thr), None)
            if k is not None and (k / fps) < w["e"] - 0.05:
                w["s"] = round(max(w["s"], k / fps - 0.02), 3)
        if env[b - 1] < thr:
            k = next((i for i in range(b - 1, a, -1) if env[i] >= thr), None)
            if k is not None and (k + 1) / fps > w["s"] + 0.05:
                w["e"] = round(min(w["e"], (k + 1) / fps + 0.05), 3)
    return words


def auto_trim(words: list[dict], env: list, fps: int, duration: float) -> tuple[float, float]:
    """Cut dead air at the head/tail. The waveform is more precise than word timestamps;
    words are the fallback when there's no usable audio envelope."""
    if env and max(env) > 0.01:
        s, e = speech_bounds(env, fps, duration)
    else:
        vis = [w for w in words if not w.get("hide")]
        s, e = (vis[0]["s"], vis[-1]["e"]) if vis else (0.0, duration)
    return round(max(0.0, s - 0.08), 3), round(min(duration, e + 0.18), 3)


def _norm(t: str) -> str:
    return re.sub(r"[^\w$%']", "", t.lower())


def realign(old: list[dict], new_text: str) -> list[dict]:
    """Keep timings for unchanged words when the user edits the transcript as plain text."""
    tokens = new_text.split()
    if not old:
        return [{"w": t, "s": i * 0.4, "e": i * 0.4 + 0.35, "p": 1.0} for i, t in enumerate(tokens)]
    a, b = [_norm(w["w"]) for w in old], [_norm(t) for t in tokens]
    out: list[dict] = []
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                w = dict(old[i1 + k])
                w["w"] = tokens[j1 + k]
                out.append(w)
        elif tag == "replace":
            s, e = old[i1]["s"], old[i2 - 1]["e"]
            emph = any(w.get("emph") for w in old[i1:i2])
            lens = [max(1, len(t)) for t in tokens[j1:j2]]
            tot, acc = sum(lens), 0
            for t, ln in zip(tokens[j1:j2], lens):
                ws = s + (e - s) * acc / tot
                acc += ln
                out.append({"w": t, "s": round(ws, 3), "e": round(s + (e - s) * acc / tot, 3), "p": 1.0, "emph": emph})
        elif tag == "insert":
            prev_e = out[-1]["e"] if out else (old[0]["s"] if old else 0)
            next_s = old[i1]["s"] if i1 < len(old) else prev_e + 0.4 * (j2 - j1)
            if next_s - prev_e < 0.08 * (j2 - j1) and out:
                # no gap: borrow the back half of the previous word
                mid = (out[-1]["s"] + out[-1]["e"]) / 2
                prev_e, next_s = mid, out[-1]["e"]
                out[-1]["e"] = round(mid, 3)
            step = (next_s - prev_e) / (j2 - j1)
            for k, t in enumerate(tokens[j1:j2]):
                out.append({"w": t, "s": round(prev_e + k * step, 3), "e": round(prev_e + (k + 1) * step, 3), "p": 1.0})
        # delete: drop
    return out
