"""Which parts of a clip end up in the ad: trim plus optional pause removal (jump cuts)."""
from __future__ import annotations

FPS = 30
KEEP_GAP = 0.12  # natural breath left where a pause was cut


def _snap(t: float) -> float:
    return int(t * FPS + 0.5) / FPS  # round half up, same in JS


def keep_ranges(clip: dict, env: dict | None = None) -> list[list[float]]:
    """Source-time ranges [a, b) to keep, frame-aligned relative to the trim in point."""
    meta = clip.get("meta") or {}
    trim = clip.get("trim") or {"in": 0.0, "out": meta.get("duration", 0.0)}
    t_in = float(trim["in"])
    dur = _snap(max(1 / FPS, float(trim["out"]) - t_in))
    pauses = clip.get("pauses") or {}
    words = (clip.get("transcript") or {}).get("words") or []
    if not pauses.get("enabled") or len(words) < 2:
        return [[round(t_in, 4), round(t_in + dur, 4)]]
    max_gap = max(0.15, float(pauses.get("max", 0.4)))
    e = (env or {}).get("env") or []
    fps_env = (env or {}).get("env_fps", 100)
    thr = (max(e) if e else 1) * 0.08
    cuts = []
    for a, b in zip(words, words[1:]):
        gap_s, gap_e = float(a["e"]), float(b["s"])
        if gap_e - gap_s <= max_gap or gap_s < t_in or gap_e > t_in + dur:
            continue
        c0, c1 = gap_s + KEEP_GAP / 2, gap_e - KEEP_GAP / 2
        if e:  # don't cut through sound Whisper didn't transcribe (laugh, product noise)
            loud = sum(1 for i in range(int(c0 * fps_env), min(len(e), int(c1 * fps_env))) if e[i] >= thr)
            if loud > 6:
                continue
        r0, r1 = _snap(c0 - t_in), _snap(c1 - t_in)
        if r1 - r0 >= 2 / FPS:
            cuts.append((r0, r1))
    keep, cur = [], 0.0
    for r0, r1 in cuts:
        if r0 - cur >= 2 / FPS:
            keep.append([cur, r0])
        cur = r1
    if dur - cur >= 1 / FPS:
        keep.append([cur, dur])
    return [[round(t_in + a, 4), round(t_in + b, 4)] for a, b in keep] or [[round(t_in, 4), round(t_in + dur, 4)]]


def out_duration(keep: list[list[float]]) -> float:
    return round(sum(b - a for a, b in keep) * FPS) / FPS


def mapper(keep: list[list[float]]):
    """Source time -> time in the rendered segment (times inside a cut snap to the cut point)."""
    def f(t: float) -> float:
        acc = 0.0
        for a, b in keep:
            if t < a:
                return acc
            if t < b:
                return acc + (t - a)
            acc += b - a
        return acc
    return f
