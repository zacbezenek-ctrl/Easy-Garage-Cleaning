"""ffmpeg discovery, probing, proxies, thumbnails, loudness + waveform analysis."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
from array import array
from pathlib import Path

_lock = threading.Lock()
_bins: dict | None = None

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0  # CREATE_NO_WINDOW


def _has_libass(ffmpeg: str) -> bool:
    try:
        out = subprocess.run([ffmpeg, "-hide_banner", "-filters"], capture_output=True, text=True,
                             timeout=20, creationflags=NO_WINDOW).stdout
        return bool(re.search(r"\sass\s", out))
    except Exception:
        return False


def bins() -> dict:
    """Locate ffmpeg/ffprobe (with libass). Order: env override, PATH, static-ffmpeg download."""
    global _bins
    with _lock:
        if _bins:
            return _bins
        cands = []
        if os.environ.get("ADF_FFMPEG"):
            ff = os.environ["ADF_FFMPEG"]
            cands.append((ff, os.environ.get("ADF_FFPROBE") or str(Path(ff).with_name(Path(ff).name.replace("ffmpeg", "ffprobe")))))
        if shutil.which("ffmpeg") and shutil.which("ffprobe"):
            cands.append((shutil.which("ffmpeg"), shutil.which("ffprobe")))
        for ff, fp in cands:
            if _has_libass(ff):
                _bins = _finish(ff, fp)
                return _bins
        try:
            from static_ffmpeg import run
            ff, fp = run.get_or_fetch_platform_executables_else_raise()
            if _has_libass(ff):
                _bins = _finish(ff, fp)
                return _bins
        except Exception as e:  # pragma: no cover
            print("static-ffmpeg failed:", e)
        raise RuntimeError("Could not find an ffmpeg build with libass. Install ffmpeg (brew install ffmpeg / winget install ffmpeg).")


def _finish(ff: str, fp: str) -> dict:
    out = subprocess.run([ff, "-hide_banner", "-filters"], capture_output=True, text=True, creationflags=NO_WINDOW).stdout
    filters = set(re.findall(r"^\s*[T.][S.][C.]?\s+(\w+)", out, re.M))
    return {"ffmpeg": ff, "ffprobe": fp, "zscale": "zscale" in filters}


def run(args: list[str], cwd: str | None = None, timeout: float | None = None) -> subprocess.CompletedProcess:
    p = subprocess.run(args, capture_output=True, text=True, cwd=cwd, timeout=timeout,
                       creationflags=NO_WINDOW, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        raise RuntimeError(f"{Path(args[0]).name} failed ({p.returncode}): {p.stderr[-1500:]}")
    return p


def probe(path: str | Path) -> dict:
    b = bins()
    p = run([b["ffprobe"], "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)])
    data = json.loads(p.stdout)
    v = next((s for s in data.get("streams", []) if s.get("codec_type") == "video"
              and not s.get("disposition", {}).get("attached_pic")), None)
    a = next((s for s in data.get("streams", []) if s.get("codec_type") == "audio"), None)
    dur = float(data.get("format", {}).get("duration") or 0)
    info = {"duration": dur, "has_audio": a is not None, "has_video": v is not None,
            "width": 0, "height": 0, "fps": 30.0, "hdr": False, "codec": None}
    if v:
        w, h = int(v.get("width") or 0), int(v.get("height") or 0)
        rot = 0
        for sd in v.get("side_data_list", []) or []:
            if "rotation" in sd:
                rot = int(float(sd["rotation"]))
        rot = int(v.get("tags", {}).get("rotate", rot) or rot)
        if abs(rot) % 180 == 90:
            w, h = h, w
        num, _, den = (v.get("avg_frame_rate") or "30/1").partition("/")
        try:
            fps = float(num) / float(den or 1)
        except (ValueError, ZeroDivisionError):
            fps = 30.0
        info.update(width=w, height=h, fps=round(fps, 3) if fps > 0 else 30.0, codec=v.get("codec_name"),
                    hdr=v.get("color_transfer") in ("arib-std-b67", "smpte2084"))
        if not dur and v.get("duration"):
            info["duration"] = float(v["duration"])
    return info


def sdr_filter(info: dict) -> str:
    """Tone-map iPhone HDR (HLG/PQ) footage to SDR bt709 so colors don't wash out."""
    if info.get("hdr") and bins()["zscale"]:
        return ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,"
                "tonemap=hable:desat=0,zscale=t=bt709:m=bt709:r=tv,")
    return ""


def make_proxy(src: Path, dst: Path, info: dict) -> None:
    """Small H.264 copy for smooth browser preview/scrubbing."""
    b = bins()
    dst.parent.mkdir(parents=True, exist_ok=True)
    tmp = dst.with_suffix(".tmp.mp4")
    vf = sdr_filter(info) + "scale='if(gt(iw,ih),-2,min(540,iw))':'if(gt(iw,ih),min(540,ih),-2)',fps=30,format=yuv420p"
    args = [b["ffmpeg"], "-y", "-v", "error", "-i", str(src), "-vf", vf,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "26", "-g", "15",
            "-movflags", "+faststart"]
    args += ["-c:a", "aac", "-b:a", "128k", "-ac", "2"] if info["has_audio"] else ["-an"]
    run(args + [str(tmp)])
    os.replace(tmp, dst)


def make_thumb(src: Path, dst: Path, info: dict) -> None:
    b = bins()
    dst.parent.mkdir(parents=True, exist_ok=True)
    t = min(max(info["duration"] * 0.3, 0), max(info["duration"] - 0.1, 0))
    run([b["ffmpeg"], "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(src), "-frames:v", "1",
         "-vf", sdr_filter(info) + "scale=-2:320", "-q:v", "4", str(dst)])


def pcm_f32(src: Path, rate: int = 16000) -> bytes:
    """Mono float32 PCM at `rate` Hz (what Whisper wants)."""
    b = bins()
    p = subprocess.run([b["ffmpeg"], "-v", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", str(rate),
                        "-f", "f32le", "-"], capture_output=True, creationflags=NO_WINDOW)
    if p.returncode != 0:
        raise RuntimeError("ffmpeg could not read the audio: " + p.stderr.decode("utf-8", "replace")[-400:])
    return p.stdout


def analyze_audio(src: Path, info: dict) -> dict:
    """Integrated loudness (LUFS) + 100 fps peak envelope for waveform & silence trimming."""
    if not info["has_audio"]:
        return {"lufs": None, "env": [], "env_fps": 100}
    b = bins()
    p = subprocess.run([b["ffmpeg"], "-hide_banner", "-nostats", "-i", str(src), "-vn",
                        "-af", "loudnorm=print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True, creationflags=NO_WINDOW, encoding="utf-8", errors="replace")
    lufs = None
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", p.stderr, re.S)
    if m:
        try:
            v = float(json.loads(m.group(0))["input_i"])
            lufs = v if v > -70 else None
        except (ValueError, KeyError):
            pass
    rate = 8000
    raw = subprocess.run([b["ffmpeg"], "-v", "error", "-i", str(src), "-vn", "-ac", "1", "-ar", str(rate),
                          "-f", "s16le", "-"], capture_output=True, creationflags=NO_WINDOW).stdout
    samples = array("h")
    samples.frombytes(raw[: len(raw) // 2 * 2])
    step = rate // 100
    env = []
    for i in range(0, len(samples), step):
        chunk = samples[i:i + step]
        env.append(round(max(max(chunk), -min(chunk)) / 32768, 3) if chunk else 0)
    return {"lufs": lufs, "env": env, "env_fps": 100}


def open_in_os(path: Path) -> None:
    if sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])
