"""Background work: clip import (proxy, analysis, transcription) and batch rendering."""
from __future__ import annotations

import csv
import json
import re
import threading
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

from . import captions, media, render, state, transcribe

_analysis = ThreadPoolExecutor(max_workers=2, thread_name_prefix="analyze")
_whisper = ThreadPoolExecutor(max_workers=1, thread_name_prefix="whisper")
RUNNING: dict[str, dict] = {}  # batch id -> live progress


def env_path(pid: str, cid: str) -> Path:
    return state.pdir(pid) / "cache" / "env" / f"{cid}.json"


load_env = render.load_env


# ---------------------------------------------------------------- import

def process_clip(pid: str, cid: str) -> None:
    _analysis.submit(_process_clip, pid, cid)


def _set(pid, c, **kw):
    with state.lock:
        c.update(kw)
        state.bump(pid, c)


def _process_clip(pid: str, cid: str) -> None:
    try:
        c = state.clip(pid, cid)
        pd = state.pdir(pid)
        src = pd / c["file"]
        _set(pid, c, stage="probing")
        info = media.probe(src)
        if not info["has_video"]:
            raise RuntimeError("No video stream found in this file.")
        if not c.get("trim"):
            c["trim"] = {"in": 0.0, "out": round(info["duration"], 3)}
        _set(pid, c, meta=info, stage="preview")
        media.make_proxy(src, pd / "cache" / "proxy" / f"{cid}.mp4", info)
        media.make_thumb(src, pd / "cache" / "thumb" / f"{cid}.jpg", info)
        _set(pid, c, stage="audio", proxy=f"cache/proxy/{cid}.mp4", thumb=f"cache/thumb/{cid}.jpg")
        a = media.analyze_audio(src, info)
        ep = env_path(pid, cid)
        ep.parent.mkdir(parents=True, exist_ok=True)
        ep.write_text(json.dumps({"env": a["env"], "env_fps": a["env_fps"]}))
        _set(pid, c, lufs=a["lufs"], status="ready", stage=None)
        if info["has_audio"]:
            queue_transcription(pid, cid)
        else:
            _set(pid, c, tstatus="none")
    except Exception as e:
        traceback.print_exc()
        try:
            _set(pid, state.clip(pid, cid), status="error", stage=None, error=str(e)[-400:])
        except KeyError:
            pass


def queue_transcription(pid: str, cid: str) -> None:
    c = state.clip(pid, cid)
    _set(pid, c, tstatus="queued", terror=None)
    _whisper.submit(_transcribe, pid, cid)


def _transcribe(pid: str, cid: str) -> None:
    try:
        c = state.clip(pid, cid)
        p = state.get(pid)
        tr = p["transcription"]
        _set(pid, c, tstatus="running")
        env = load_env(pid, cid)
        words = transcribe.transcribe(state.pdir(pid) / c["file"], model=tr["model"], language=tr["language"],
                                      vocabulary=tr.get("vocabulary", ""), duration=c["meta"]["duration"],
                                      env=env["env"], orig_name=c.get("orig_name", ""))
        words = transcribe.refine_words(words, env["env"], env["env_fps"])
        with state.lock:
            c["transcript"] = {"words": words, "model": tr["model"], "at": time.time()}
            if tr.get("auto_trim") and not c.get("trim_touched"):
                s, e = transcribe.auto_trim(words, env["env"], env["env_fps"], c["meta"]["duration"])
                if e - s > 0.3:
                    c["trim"] = {"in": s, "out": e}
            _set(pid, c, tstatus="done")
    except Exception as e:
        traceback.print_exc()
        try:
            _set(pid, state.clip(pid, cid), tstatus="error", terror=str(e)[-400:])
        except KeyError:
            pass


def process_asset(pid: str, kind: str, rel: str) -> dict:
    src = state.pdir(pid) / rel
    if kind == "logo":
        return {"file": rel}
    info = media.probe(src)
    if kind == "music":
        return {"file": rel, "duration": info["duration"]}
    is_image = src.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")
    a = media.analyze_audio(src, info) if (not is_image and info["has_audio"]) else {"lufs": None}
    return {"file": rel, "kind": "image" if is_image else "video", "meta": info, "lufs": a["lufs"]}


# ---------------------------------------------------------------- rendering

def _opts(p: dict, preview: bool) -> dict:
    ex = p["export"]
    return {"scale": 0.5 if preview else 1.0, "quality": "standard" if preview else ex["quality"],
            "speed": "preview" if preview else ex["speed"], "fit": ex["fit"]}


def _fname(template: str, p: dict, hook: dict, body: dict, fmt: str, n: int) -> str:
    vals = {"project": state.slug(p["name"], 24), "hook": hook["label"], "body": body["label"],
            "hook_name": state.slug(hook["name"], 24), "body_name": state.slug(body["name"], 24),
            "format": fmt, "date": datetime.now().strftime("%Y%m%d"), "n": f"{n:03d}"}
    name = re.sub(r"\{(\w+)\}", lambda m: vals.get(m.group(1), m.group(0)), template or "{hook}_{body}_{format}")
    return re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-.") or f"ad_{n:03d}"


def hook_script(clip: dict) -> str:
    words = (clip.get("transcript") or {}).get("words") or []
    t = clip.get("trim") or {}
    return " ".join(w["w"] for w in words if not w.get("hide")
                    and t.get("in", 0) - 0.05 <= w["s"] <= t.get("out", 1e9))


def start_batch(pid: str, combos: list[list[str]], formats: list[str], preview: bool = False) -> dict:
    p = state.get(pid)
    clips = {c["id"]: c for c in p["clips"]}
    combos = [(h, b) for h, b in combos if h in clips and b in clips
              and clips[h]["status"] == "ready" and clips[b]["status"] == "ready"]
    formats = [f for f in formats if f in captions.FORMATS]
    if not combos or not formats:
        raise ValueError("Nothing to render: pick at least one ready hook x body and one format.")
    bid = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
    out_dir = state.pdir(pid) / "exports" / ("_previews" if preview else "") / bid
    out_dir.mkdir(parents=True, exist_ok=True)
    batch = {"id": bid, "created": time.time(), "status": "running", "preview": preview,
             "dir": str(out_dir.relative_to(state.pdir(pid)).as_posix()), "total": len(combos) * len(formats),
             "done": 0, "progress": 0.0, "message": "Preparing…", "outputs": [], "errors": []}
    live = {"batch": batch, "cancel": threading.Event()}
    RUNNING[bid] = live
    if not preview:
        with state.lock:
            p["batches"].insert(0, batch)
            p["batches"] = p["batches"][:30]
            state.save(pid)
    threading.Thread(target=_run_batch, args=(pid, live, combos, formats, preview), daemon=True).start()
    return batch


def _run_batch(pid: str, live: dict, combos, formats, preview: bool) -> None:
    batch, cancel = live["batch"], live["cancel"]
    p = state.get(pid)
    opts = _opts(p, preview)
    clips = {c["id"]: c for c in p["clips"]}
    out_dir = state.pdir(pid) / batch["dir"]
    try:
        # ---- stage 1: unique segments
        jobs: dict[str, dict] = {}
        need: dict[tuple, dict] = {}
        for fmt in formats:
            for cid in {x for hb in combos for x in hb}:
                j = render.segment_job(p, clips[cid], fmt, opts)
                jobs[j["key"]] = j
                need[(cid, fmt)] = j
            ec = render.endcard_job(p, fmt, opts)
            if ec:
                jobs[ec["key"]] = ec
                need[("endcard", fmt)] = ec
        prog_on = bool(p["brand"]["progress"].get("enabled"))
        combo_w = 0.6 if prog_on else 0.08  # relative cost vs. a full segment render
        seg_total = sum(j["dur"] for j in jobs.values() if not j["out"].exists())
        combo_total = sum((need[(h, f)]["dur"] + need[(b, f)]["dur"]) * combo_w for h, b in combos for f in formats)
        grand = max(0.001, seg_total + combo_total)
        frac: dict[str, float] = {}
        lock = threading.Lock()

        def report(key, weight, f):
            with lock:
                frac[key] = weight * f
                batch["progress"] = min(0.999, sum(frac.values()) / grand)

        todo = [j for j in jobs.values() if not j["out"].exists()]
        batch["message"] = f"Rendering {len(todo)} clip versions…" if todo else "Using cached clips…"
        workers = max(1, int(p["export"].get("parallel") or 2))
        with ThreadPoolExecutor(max_workers=workers) as ex:
            futs = {ex.submit(render.render_segment, p, j, opts,
                              (lambda f, k=j["key"], w=j["dur"]: report(k, w, f)), cancel): j for j in todo}
            for fu in as_completed(futs):
                fu.result()

        # ---- stage 2: one file per ad
        batch["message"] = "Assembling ads…"
        endcard_present = any(k[0] == "endcard" for k in need)
        names: set[str] = set()
        rows = []
        tasks = []
        n = 0
        for h, b in combos:
            for fmt in formats:
                n += 1
                name = _fname(p["export"]["naming"], p, clips[h], clips[b], fmt, n)
                base, i = name, 2
                while name in names:
                    name, i = f"{base}_{i}", i + 1
                names.add(name)
                parts = [need[(h, fmt)], need[(b, fmt)]] + ([need[("endcard", fmt)]] if endcard_present else [])
                tasks.append((h, b, fmt, name, parts))

        def do_combo(t):
            h, b, fmt, name, parts = t
            out = out_dir / f"{name}.mp4"
            w = (parts[0]["dur"] + parts[1]["dur"]) * combo_w
            dur = render.render_combo(p, [x["out"] for x in parts], [x["dur"] for x in parts], fmt, out, opts,
                                      lambda f, k="c:" + name, w=w: report(k, w, f), cancel)
            report("c:" + name, w, 1.0)
            return {"name": name, "file": f"{batch['dir']}/{name}.mp4", "hook": h, "body": b, "format": fmt,
                    "duration": round(dur, 2)}

        with ThreadPoolExecutor(max_workers=workers + 1) as ex:
            futs = {ex.submit(do_combo, t): t for t in tasks}
            for fu in as_completed(futs):
                t = futs[fu]
                try:
                    o = fu.result()
                    batch["outputs"].append(o)
                    W, H = captions.FORMATS[t[2]]
                    rows.append({"ad_name": o["name"], "file": f"{o['name']}.mp4", "hook_id": clips[t[0]]["label"],
                                 "hook_name": clips[t[0]]["name"], "hook_script": hook_script(clips[t[0]]),
                                 "body_id": clips[t[1]]["label"], "body_name": clips[t[1]]["name"],
                                 "format": t[2], "width": W, "height": H, "duration_sec": o["duration"]})
                except render.Cancelled:
                    raise
                except Exception as e:
                    batch["errors"].append(f"{t[3]}: {e}")
                batch["done"] += 1
        batch["outputs"].sort(key=lambda o: o["name"])
        if rows and not preview:
            rows.sort(key=lambda r: r["ad_name"])
            with open(out_dir / "manifest.csv", "w", newline="", encoding="utf-8") as fh:
                w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
                w.writeheader()
                w.writerows(rows)
        batch["status"] = "done" if not batch["errors"] else ("partial" if batch["outputs"] else "error")
        batch["message"] = f"{len(batch['outputs'])} ads ready"
    except render.Cancelled:
        batch["status"], batch["message"] = "cancelled", "Cancelled"
    except Exception as e:
        traceback.print_exc()
        batch["status"], batch["message"] = "error", str(e)[-500:]
        batch["errors"].append(str(e)[-500:])
    finally:
        batch["progress"] = 1.0 if batch["status"] == "done" else batch["progress"]
        batch["finished"] = time.time()
        if not preview:
            with state.lock:
                state.bump(pid)
        threading.Timer(600, lambda: RUNNING.pop(batch["id"], None)).start()
