"""Caption layout (word chunks) and ASS subtitle generation for libass burn-in."""
from __future__ import annotations

import copy
import re

from . import fonts

FORMATS = {
    "9x16": (1080, 1920),
    "4x5": (1080, 1350),
    "1x1": (1080, 1080),
    "16x9": (1920, 1080),
}

FILLERS = re.compile(r"^(u+m+|u+h+|e+r+m+|h+m+|a+h+|mm+|uh-huh)[,.!?]*$", re.I)
STRIP_PUNCT = re.compile(r"[.,;:\"“”…]|(?<!\w)'|'(?!\w)")

BASE_STYLE = {
    "enabled": True,
    "preset": "bold-pop",
    "font": "montserrat-black",
    "size": 128,
    "uppercase": True,
    "color": "#FFFFFF",
    "outline_color": "#000000",
    "outline": 8,
    "shadow": 0,
    "shadow_color": "#000000",
    "shadow_opacity": 0.6,
    "highlight": "color",          # color | box | none
    "highlight_color": "#FFE600",
    "highlight_text": "#FFFFFF",   # text color on the box (box mode)
    "emphasis_color": "#3DFF6E",
    "bg": False,
    "bg_color": "#000000",
    "bg_opacity": 0.65,
    "bg_pad": 14,
    "animation": "pop",            # pop | fade | none
    "word_pop": False,
    "words": 3,
    "max_chars": 14,
    "lines": 1,
    "pos": {"9x16": 0.60, "4x5": 0.72, "1x1": 0.74, "16x9": 0.82},
    "remove_fillers": True,
    "strip_punct": True,
    "replacements": [],
}

PRESETS = {
    "bold-pop": {"label": "Bold Pop", **{}},
    "box-word": {"label": "Word Box", "font": "montserrat-extrabold", "size": 120, "outline": 6,
                 "highlight": "box", "highlight_color": "#7C3AED", "highlight_text": "#FFFFFF"},
    "karaoke-green": {"label": "Karaoke", "font": "anton", "size": 150, "outline": 7, "max_chars": 16,
                      "highlight_color": "#3DFF6E", "emphasis_color": "#FFE600"},
    "one-word": {"label": "One Word", "size": 180, "outline": 10, "words": 1, "highlight": "none",
                 "max_chars": 20},
    "clean-box": {"label": "Clean Box", "font": "poppins-bold", "size": 88, "uppercase": False,
                  "color": "#111111", "outline": 0, "highlight": "none", "bg": True, "bg_color": "#FFFFFF",
                  "bg_opacity": 1.0, "bg_pad": 18, "words": 5, "max_chars": 22, "lines": 2,
                  "animation": "fade", "strip_punct": False},
    "minimal": {"label": "Minimal", "font": "inter-bold", "size": 88, "uppercase": False, "outline": 0,
                "shadow": 5, "shadow_opacity": 0.75, "highlight": "none", "words": 6, "max_chars": 24,
                "lines": 2, "animation": "fade", "strip_punct": False},
    "comic": {"label": "Comic", "font": "luckiest-guy", "size": 140, "outline": 9, "shadow": 6,
              "shadow_opacity": 1.0, "highlight_color": "#FFD000", "words": 2, "max_chars": 14},
}

OVERLAY_STYLE = {
    "font": "poppins-bold",
    "size": 92,
    "uppercase": False,
    "color": "#111111",
    "bg_color": "#FFFFFF",
    "bg_opacity": 1.0,
    "pad": 16,
    "max_width": 0.84,
}


def preset_style(name: str) -> dict:
    s = copy.deepcopy(BASE_STYLE)
    p = {k: v for k, v in PRESETS.get(name, {}).items() if k != "label"}
    s.update(copy.deepcopy(p))
    s["preset"] = name
    return s


def merged_style(style: dict | None) -> dict:
    s = copy.deepcopy(BASE_STYLE)
    for k, v in (style or {}).items():
        if k == "pos" and isinstance(v, dict):
            s["pos"].update(v)
        else:
            s[k] = v
    return s


def merged_overlay_style(style: dict | None) -> dict:
    s = copy.deepcopy(OVERLAY_STYLE)
    s.update(style or {})
    return s


# ---------------------------------------------------------------- layout

def _tok(t: str) -> str:
    return re.sub(r"[^\w$%']", "", t.lower())


def _replace_phrases(words: list[dict], reps: list[tuple[str, str]]) -> list[dict]:
    """Find & replace across word boundaries ("fifty thousand dollars" -> "$50K"), keeping timing."""
    rules = sorted(([_tok(t) for t in frm.split() if _tok(t)], to) for frm, to in reps)
    rules = sorted((r for r in rules if r[0]), key=lambda r: -len(r[0]))
    if not rules:
        return words
    norms = [_tok(w["w"]) for w in words]
    out, i = [], 0
    while i < len(words):
        for toks, to in rules:
            n = len(toks)
            if norms[i:i + n] == toks:
                last = words[i + n - 1]
                trail = re.search(r"[.,!?;:]+$", last["w"])
                text = to + (trail.group(0) if trail and to and not re.search(r"[.,!?;:]$", to) else "")
                out.append({**words[i], "w": text, "e": last["e"], "emph": any(w.get("emph") for w in words[i:i + n])})
                i += n
                break
        else:
            out.append(words[i])
            i += 1
    return out


def _clean_words(words: list[dict], st: dict) -> list[dict]:
    reps = [(r.get("from", "").strip(), r.get("to", "")) for r in st.get("replacements") or [] if r.get("from", "").strip()]
    kept = [w for w in words if not w.get("hide") and (w.get("w") or "").strip()
            and not (st.get("remove_fillers") and FILLERS.match(w["w"].strip()))]
    kept = _replace_phrases(kept, reps)
    singles = [(frm, to) for frm, to in reps if len(frm.split()) == 1]
    out = []
    for w in kept:
        text = (w.get("w") or "").strip()
        for frm, to in singles:  # also catches "acme's" -> "ACME's"
            text = re.sub(r"(?<!\w)" + re.escape(frm) + r"(?!\w)", to, text, flags=re.I)
        sentence_end = bool(re.search(r"[.!?]['\"”]?$", text))
        if st.get("strip_punct"):
            text = STRIP_PUNCT.sub("", text)
        if st.get("uppercase"):
            text = text.upper()
        text = text.replace("{", "(").replace("}", ")").replace("\\", "/").strip()
        if not text:
            continue
        s, e = float(w.get("s", 0)), float(w.get("e", 0))
        if out and s < out[-1]["s"]:
            s = out[-1]["s"]
        e = max(e, s + 0.05)
        parts = text.split()
        # a replacement can expand one word into several: share its time
        span = (e - s) / len(parts)
        for i, part in enumerate(parts):
            out.append({"t": part, "s": round(s + i * span, 3), "e": round(s + (i + 1) * span, 3),
                        "emph": bool(w.get("emph")), "end": sentence_end and i == len(parts) - 1})
    return out


def _split_lines(chunk: list[dict], max_chars: int, lines: int) -> list[list[dict]]:
    total = sum(len(w["t"]) for w in chunk) + len(chunk) - 1
    if lines < 2 or len(chunk) < 2 or total <= max_chars:
        return [chunk]
    best, best_i = None, 1
    for i in range(1, len(chunk)):
        a = sum(len(w["t"]) for w in chunk[:i]) + i - 1
        b = sum(len(w["t"]) for w in chunk[i:]) + len(chunk) - i - 1
        score = max(a, b)
        if best is None or score < best:
            best, best_i = score, i
    return [chunk[:best_i], chunk[best_i:]]


def layout(words: list[dict], style: dict) -> list[dict]:
    st = merged_style(style)
    ws = _clean_words(words or [], st)
    max_words = max(1, int(st.get("words") or 3))
    max_chars = max(4, int(st.get("max_chars") or 14))
    lines = 2 if int(st.get("lines") or 1) >= 2 else 1
    budget = max_chars * lines
    chunks: list[list[dict]] = []
    cur: list[dict] = []
    for w in ws:
        if cur:
            chars = sum(len(x["t"]) for x in cur) + len(cur) + len(w["t"])
            if (len(cur) >= max_words or chars > budget or w["s"] - cur[-1]["e"] > 0.6 or cur[-1]["end"]):
                chunks.append(cur)
                cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)

    out = []
    for i, ch in enumerate(chunks):
        s, e = ch[0]["s"], ch[-1]["e"]
        nxt = chunks[i + 1][0]["s"] if i + 1 < len(chunks) else None
        if nxt is not None and nxt - e < 0.7:
            e = nxt
        else:
            e = e + 0.3 if nxt is None else min(e + 0.3, nxt)
        if e - s < 0.25:
            e = s + 0.25 if nxt is None else min(s + 0.25, max(nxt, e))
        out.append({"s": round(s, 3), "e": round(e, 3),
                    "lines": [[{k: w[k] for k in ("t", "s", "e", "emph")} for w in ln]
                              for ln in _split_lines(ch, max_chars, lines)]})
    return out


# ---------------------------------------------------------------- ASS

def ass_color(hex_color: str, opacity: float = 1.0) -> str:
    h = (hex_color or "#FFFFFF").lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    r, g, b = h[0:2], h[2:4], h[4:6]
    a = max(0, min(255, round(255 * (1 - float(opacity)))))
    return f"&H{a:02X}{b}{g}{r}".upper()


def _c(hex_color: str) -> str:  # inline colour tag value (no alpha)
    return ass_color(hex_color)[0:2] + ass_color(hex_color)[4:] + "&"


def _ts(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    h, cs = divmod(cs, 360000)
    m, cs = divmod(cs, 6000)
    s, cs = divmod(cs, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _style_line(name, font, size, primary, outline_c, back, bold, border_style, outline, shadow,
                align=5, ml=0, mr=0, mv=0):
    return (f"Style: {name},{font['family']},{size:.0f},{primary},{primary},{outline_c},{back},"
            f"{-1 if bold else 0},0,0,0,100,100,0,0,{border_style},{outline:.1f},{shadow:.1f},{align},"
            f"{ml:.0f},{mr:.0f},{mv:.0f},1")


def box_metrics(st: dict, f: dict, k: float = 1.0) -> dict:
    """Highlight-box geometry shared with the browser preview (see placeHlBox in app.js)."""
    size = st["size"] * k
    return {"pad_x": size * 0.14 + st.get("outline", 0) * k * 0.5, "pad_y": size * 0.10,
            "below": size * 0.10 + (0 if st.get("uppercase") else 0.2 * size * f["css_scale"]),
            "radius": size * 0.12}


def _word_boxes(lines: list[list[dict]], st: dict, f: dict, cx: float, cy: float, k: float) -> list[tuple]:
    size = st["size"] * k
    m = box_metrics(st, f, k)
    top0 = cy - len(lines) * size / 2  # libass centres the whole block on \pos with \an5
    out = []
    for li, ln in enumerate(lines):
        spans, total = fonts.word_spans(f["id"], [w["t"] for w in ln], size)
        x0 = cx - total / 2
        base = top0 + li * size + f["ascent_ratio"] * size
        top = base - f["cap_ratio"] * size - m["pad_y"]
        bh = base + m["below"] - top
        for a, b in spans:
            out.append((x0 + a - m["pad_x"], top, b - a + 2 * m["pad_x"], bh, min(m["radius"], bh / 2)))
    return out


def _rrect(w: float, h: float, r: float) -> str:
    c = r * 0.5523  # bezier circle constant
    n = lambda v: f"{v:.1f}"
    return (f"m {n(r)} 0 l {n(w - r)} 0 b {n(w - r + c)} 0 {n(w)} {n(r - c)} {n(w)} {n(r)} "
            f"l {n(w)} {n(h - r)} b {n(w)} {n(h - r + c)} {n(w - r + c)} {n(h)} {n(w - r)} {n(h)} "
            f"l {n(r)} {n(h)} b {n(r - c)} {n(h)} 0 {n(h - r + c)} 0 {n(h - r)} "
            f"l 0 {n(r)} b 0 {n(r - c)} {n(r - c)} 0 {n(r)} 0")


def build_ass(*, words: list[dict], style: dict, overlay_style: dict, overlays: list[dict],
              fmt: str, tmap, duration: float, scale: float = 1.0) -> str:
    """tmap: source-clip seconds -> seconds in the rendered segment (trim + jump cuts)."""
    W, H = FORMATS[fmt]
    W, H = round(W * scale), round(H * scale)
    st = merged_style(style)
    ost = merged_overlay_style(overlay_style)
    k = scale  # px values are authored at full res
    f = fonts.get(st["font"])
    of = fonts.get(ost["font"])

    styles = []
    box_mode = st["highlight"] == "box"
    bg = bool(st.get("bg")) and not box_mode
    shadow_back = ass_color(st["shadow_color"], st["shadow_opacity"])
    if bg:
        styles.append(_style_line("Cap", f, st["size"] * k, ass_color(st["color"]),
                                  ass_color(st["bg_color"], st["bg_opacity"]), shadow_back, f["bold"], 3,
                                  st["bg_pad"] * k, st["shadow"] * k))
    else:
        styles.append(_style_line("Cap", f, st["size"] * k, ass_color(st["color"]),
                                  ass_color(st["outline_color"]), shadow_back, f["bold"], 1,
                                  st["outline"] * k, st["shadow"] * k))
    marg = (1 - float(ost.get("max_width", 0.84))) / 2 * W
    styles.append(_style_line("Head", of, ost["size"] * k, ass_color(ost["color"]),
                              ass_color(ost["bg_color"], ost["bg_opacity"]), ass_color("#000000", 0),
                              of["bold"], 3, ost["pad"] * k, 0, align=8, ml=marg, mr=marg))

    events = []
    end_t = duration

    local = tmap

    if st.get("enabled", True):
        y = float(st["pos"].get(fmt, 0.6)) * H
        x = W / 2
        base_c, hl_c, emph_c = _c(st["color"]), _c(st["highlight_color"]), _c(st["emphasis_color"])
        hl_text_c = _c(st["highlight_text"]) if box_mode else hl_c
        for ch in layout(words, st):
            cs, ce = local(ch["s"]), local(ch["e"])
            if ce <= 0.02 or cs >= end_t - 0.02:
                continue
            flat, breaks = [], set()
            for li, ln in enumerate(ch["lines"]):
                if li:
                    breaks.add(len(flat))
                flat.extend(ln)
            n = len(flat)
            boxes = _word_boxes(ch["lines"], st, f, x, y, k) if box_mode else []
            per_word = st["highlight"] in ("color", "box") and n > 0
            steps = range(n) if per_word else [None]
            for si, active in enumerate(steps):
                es = cs if si == 0 else local(flat[active]["s"])
                ee = ce if (active is None or active + 1 >= n) else local(flat[active + 1]["s"])
                es, ee = max(0.0, es), min(end_t, ee)
                if ee - es < 0.01:
                    continue
                anim = ""
                if si == 0 and st["animation"] == "pop":
                    anim = r"\fscx78\fscy78\t(0,110,\fscx100\fscy100)"
                elif si == 0 and st["animation"] == "fade":
                    anim = r"\fad(110,0)"
                head = "{" + rf"\an5\pos({x:.0f},{y:.0f})\q2" + anim + "}"
                text_parts = []
                for j, w in enumerate(flat):
                    sep = "" if j == 0 else (r"\N" if j in breaks else " ")
                    is_active = active == j
                    if is_active:
                        pop = r"\fscx112\fscy112" if (st.get("word_pop") and not box_mode) else ""
                        text_parts.append(sep + "{" + rf"\c{hl_text_c}{pop}" + "}" + w["t"] +
                                          "{" + rf"\c{base_c}" + (r"\fscx100\fscy100" if pop else "") + "}")
                    elif w["emph"]:
                        text_parts.append(sep + "{" + rf"\c{emph_c}" + "}" + w["t"] + "{" + rf"\c{base_c}" + "}")
                    else:
                        text_parts.append(sep + w["t"])
                if box_mode and active is not None:
                    bx, by, bw, bh, br = boxes[active]
                    events.append(f"Dialogue: 0,{_ts(es)},{_ts(ee)},Cap,,0,0,0,,"
                                  + "{" + rf"\an7\pos({bx:.1f},{by:.1f})\p1\bord0\shad0\1c{hl_c}\1a&H00&" + "}"
                                  + _rrect(bw, bh, br) + "{" + r"\p0" + "}")
                events.append(f"Dialogue: 1,{_ts(es)},{_ts(ee)},Cap,,0,0,0,,{head}{''.join(text_parts)}")

    for ov in overlays or []:
        text = (ov.get("text") or "").strip()
        if not text:
            continue
        if ost.get("uppercase"):
            text = text.upper()
        text = text.replace("{", "(").replace("}", ")").replace("\\", "/").replace("\r", "").replace("\n", r"\N")
        s = max(0.0, float(ov.get("start") or 0))
        e = float(ov.get("end") or 0)
        e = end_t if e <= 0 else min(end_t, e)
        if e - s < 0.05:
            continue
        y = float(ov.get("y", 0.16)) * H
        events.append(f"Dialogue: 2,{_ts(s)},{_ts(e)},Head,,0,0,0,,"
                      + "{" + rf"\an8\pos({W / 2:.0f},{y:.0f})" + "}" + text)

    return "\n".join([
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}", "WrapStyle: 0",
        "ScaledBorderAndShadow: yes", "YCbCr Matrix: TV.709", "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, "
        "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, "
        "MarginL, MarginR, MarginV, Encoding",
        *styles, "",
        "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
        *events, "",
    ])
