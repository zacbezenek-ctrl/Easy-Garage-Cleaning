"""Project storage: one folder per project with project.json, media, cache and exports."""
from __future__ import annotations

import copy
import json
import os
import re
import shutil
import threading
import time
import uuid
from pathlib import Path

from . import captions

HOME = Path(os.environ.get("ADF_HOME") or (Path.home() / "AdFactory"))
PROJECTS = HOME / "projects"

DEFAULT_BRAND = {
    "logo": None, "logo_pos": "tr", "logo_size": 0.16, "logo_opacity": 0.9, "logo_margin": 0.045,
    "endcard": None, "endcard_duration": 2.5,
    "music": None, "music_volume": -20, "music_duck": True,
    "progress": {"enabled": False, "color": "#FFE600", "height": 10, "position": "top"},
    "normalize": True, "lufs_target": -14, "voice_enhance": False,
}
DEFAULT_EXPORT = {
    "formats": ["9x16", "4x5"], "fit": "fill", "quality": "high", "speed": "balanced",
    "naming": "{project}_{hook}_{body}_{format}", "parallel": 2,
}
DEFAULT_TRANSCRIPTION = {"model": "small", "language": "auto", "vocabulary": "", "auto_trim": True}

lock = threading.RLock()
_cache: dict[str, dict] = {}


def slug(s: str, maxlen: int = 40) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", s or "").strip("-")
    return (s[:maxlen].strip("-") or "untitled")


def pdir(pid: str) -> Path:
    return PROJECTS / pid


def _path(pid: str) -> Path:
    return pdir(pid) / "project.json"


def _upgrade(p: dict) -> dict:
    p.setdefault("clips", [])
    p.setdefault("batches", [])
    p["style"] = captions.merged_style(p.get("style"))
    p["overlay_style"] = captions.merged_overlay_style(p.get("overlay_style"))
    b = copy.deepcopy(DEFAULT_BRAND)
    b.update(p.get("brand") or {})
    b["progress"] = {**DEFAULT_BRAND["progress"], **((p.get("brand") or {}).get("progress") or {})}
    p["brand"] = b
    p["export"] = {**DEFAULT_EXPORT, **(p.get("export") or {})}
    p["transcription"] = {**DEFAULT_TRANSCRIPTION, **(p.get("transcription") or {})}
    p.setdefault("matrix", {"off": []})
    p.pop("results", None)
    p.setdefault("rev", 0)
    return p


def list_projects() -> list[dict]:
    PROJECTS.mkdir(parents=True, exist_ok=True)
    out = []
    for d in PROJECTS.iterdir():
        f = d / "project.json"
        if f.exists():
            try:
                p = get(d.name)
                out.append({"id": p["id"], "name": p["name"], "updated": f.stat().st_mtime,
                            "hooks": sum(c["role"] == "hook" for c in p["clips"]),
                            "bodies": sum(c["role"] == "body" for c in p["clips"])})
            except Exception:
                continue
    return sorted(out, key=lambda x: -x["updated"])


def create(name: str, copy_from: str | None = None) -> dict:
    with lock:
        base = slug(name).lower()
        pid, n = base, 2
        while pdir(pid).exists():
            pid, n = f"{base}-{n}", n + 1
        for sub in ("media", "assets", "cache", "exports"):
            (pdir(pid) / sub).mkdir(parents=True, exist_ok=True)
        p = _upgrade({"id": pid, "name": name.strip() or "Untitled", "created": time.time()})
        if copy_from:
            src = get(copy_from)
            for k in ("style", "overlay_style", "brand", "export", "transcription"):
                p[k] = copy.deepcopy(src[k])
            for kind in ("logo", "endcard", "music"):  # brand assets live inside the project folder
                a = p["brand"].get(kind)
                if a and (pdir(copy_from) / a["file"]).exists():
                    shutil.copy2(pdir(copy_from) / a["file"], pdir(pid) / a["file"])
                elif a:
                    p["brand"][kind] = None
        _cache[pid] = p
        save(pid)
        return p


def get(pid: str) -> dict:
    with lock:
        if pid not in _cache:
            f = _path(pid)
            if not f.exists():
                raise KeyError(pid)
            p = _upgrade(json.loads(f.read_text(encoding="utf-8")))
            for b in p["batches"]:
                if b.get("status") in ("queued", "running"):
                    b["status"] = "interrupted"
            _cache[pid] = p
        return _cache[pid]


def save(pid: str) -> None:
    with lock:
        p = _cache[pid]
        f = _path(pid)
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps(p, indent=1), encoding="utf-8")
        os.replace(tmp, f)


def bump(pid: str, clip: dict | None = None) -> None:
    """Record a change the browser should pick up on its next poll."""
    with lock:
        p = get(pid)
        p["rev"] = p.get("rev", 0) + 1
        if clip is not None:
            clip["rev"] = p["rev"]
        save(pid)


def clip(pid: str, cid: str) -> dict:
    p = get(pid)
    for c in p["clips"]:
        if c["id"] == cid:
            return c
    raise KeyError(cid)


def new_clip(pid: str, role: str, orig_name: str, ext: str) -> dict:
    with lock:
        p = get(pid)
        prefix = "H" if role == "hook" else "B"
        nums = [int(c["label"][1:]) for c in p["clips"] if c["role"] == role and c["label"][1:].isdigit()]
        label = f"{prefix}{(max(nums) + 1) if nums else 1:02d}"
        cid = uuid.uuid4().hex[:10]
        c = {
            "id": cid, "role": role, "label": label,
            "name": Path(orig_name).stem[:60], "orig_name": orig_name,
            "file": f"media/{cid}{ext.lower()}",
            "status": "processing", "stage": "uploading", "error": None,
            "meta": None, "lufs": None,
            "transcript": None, "tstatus": "pending", "terror": None,
            "trim": None, "crop": {"zoom": 1.0, "x": 0.5, "y": 0.5}, "gain_db": 0.0,
            "overlays": [], "created": time.time(), "rev": 0,
        }
        p["clips"].append(c)
        bump(pid, c)
        return c


EDITABLE_CLIP = {"name", "trim", "crop", "gain_db", "overlays", "pauses"}


def patch_clip(pid: str, cid: str, data: dict) -> dict:
    with lock:
        c = clip(pid, cid)
        for k, v in data.items():
            if k in EDITABLE_CLIP:
                c[k] = v
                if k == "trim":
                    c["trim_touched"] = True
            elif k == "words" and c.get("transcript") is not None:
                c["transcript"]["words"] = v
        bump(pid, c)
        return c


EDITABLE_PROJECT = {"name", "style", "overlay_style", "brand", "export", "matrix", "transcription"}


def patch_project(pid: str, data: dict) -> dict:
    with lock:
        p = get(pid)
        for k, v in data.items():
            if k in EDITABLE_PROJECT:
                p[k] = v
        _upgrade(p)
        save(pid)
        return p


def delete_clip(pid: str, cid: str) -> None:
    with lock:
        p = get(pid)
        c = clip(pid, cid)
        p["clips"].remove(c)
        try:
            (pdir(pid) / c["file"]).unlink(missing_ok=True)
        except OSError:
            pass
        bump(pid)
